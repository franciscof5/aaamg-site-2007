<?

######################################################
#                                                    #
#                                                    #
#       Desenvolvido por: papito - Erickson -        #
#           erickson@laranjaldojari.net              #
#              MSN: papito@tvsom.com.br              #
#                                                    #
#                                                    #
######################################################

?>
<html>
<body>
<form method="post" action="gravar.php">
<table width="33%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="31%">Nome: </td>
    <td width="69%"><input name="nome" type="text" size="20" maxlength="20"></td>
  </tr>
  <tr>
    <td>Mensagem:</td>
    <td>
      <textarea name="msg" cols="20" rows="3">
    </textarea>
    </td>
  </tr>
  <tr>
    <td><input type="submit" value="Enviar"></td>
  </tr>
</table>
</form>
</body>
</html>



