<?php
include "lg/se.php";
if ($_GET['acao'] == "cad" or empty($_GET['acao'])) {
echo "<form action='?viewby=grupos&acao=cad' method='post'>";	
}
if($_GET['acao'] == "altok" or $_GET['acao'] == "alt"){
echo "<form action='?viewby=grupos&acao=alt&id=".$_GET['id']."' method='post'>";	
}

/////////////////
// CONECTAR DB //
/////////////////
// Conectando com o banco de dados.
@$conexao = mysql_connect($dbserver, $dbuser, $dbpass)
// Menssagen de erro.
or die ("<font color=$colortex size=$sizetex2>Configura��o de Banco de Dados Errada!</font>
<a href=http://$esite/admin.php><font size=$sizetex><B>Voltar!</B></font>");
// Selecionando a base de dados.
@$db = mysql_select_db($dbname)
// Menssagen de erro.
or die ("<font face=$face size=$sizetex color='$colortex'>Banco de Dados Inexistente!</font>
<a href=http://$esite/admin.php><font face=$face size=$sizetex1 color='$colortex'><B>Voltar!</B></font>");

///////////////
// CADASTRAR //
///////////////
//Caso a acao seja cad, cadastrar grupo
if($_GET['acao'] == "cad"){
if(empty($_POST['nome']) or empty($_POST['descricao'])){
	echo "<font color=red><B>ERRO!</B></font><br>Voc� deixou um dos campos em branco.<P>".$_POST['nome'].$_POST['descricao'];}else{
		
$_POST['descricao1'] = str_replace("\\\"", "\"", $_POST['descricao']);
		
@$sql = "INSERT INTO $dbtbg (nome, descricao, ver) VALUES ('".$_POST['nome']."',
'".$_POST['descricao1']."', '".$_POST['ver']."')";

//Inserindo os dados
@$sql = mysql_query($sql)
// Menssagen de erro.
or die ("Houve erro na grava��o dos dados, por favor, clique em voltar e verifique os campos obrigat�rios!");
// Menssagem de exito.
echo "<font face=$face size=$sizetex color='$colortex'><b>Cadastro efetuado com sucesso!</b></font><P>";
}}

/////////////
// ALTERAR //
/////////////
if($_GET['acao'] == "altok"){
if(empty($_POST['nome']) or empty($_POST['descricao'])){
	echo "<font color=red><B>ERRO!</B></font><br>Voc� deixou um dos campos em branco.<P>".$_POST['nome'].$_POST['descricao'];}else{
$_POST['descricao1'] = str_replace("\\\"", "\"", $_POST['descricao']);
// Atualizando os dados.
$sql = "UPDATE $dbtbg SET nome='".$_POST['nome']."',descricao='".$_POST['descricao1']."', ver='".$_POST['ver']."' WHERE id='".$_GET['id']."'";
// Executando $sql e verificando se tudo ocorreu certo.
@$resultado = mysql_query($sql)
// Menssagen de erro.
or die ("N�o foi poss�vel atualizar banco de dados");
// Menssagem de exito.
echo "<font face=$face size=$sizetex color='$colortex'><B>Not�cia alterada com sucesso!</B></font> <br><br>
<center><font face=$face size=$sizetex1 color='$colortex'><a href=http://$esite/admin.php?viewby=alterar><B>VOLTAR</b></a></font></center>";
	}}
if($_GET['acao'] == "altok" or $_GET['acao'] == "alt"){
// Selecionando na tablela os dados necessarios.
@$sql = "SELECT * FROM $dbtbg WHERE id='".$_GET['id']."'";
// Executando $sql e verificando se tudo ocorreu certo.
@$resultado = mysql_query($sql)
// Menssagen de erro.
or die ("<font color=$colortex size=$sizetex2><B>N�o foi poss�vel realizar a consulta ao banco de dados</B></font><font size=$sizetex><BR><BR><a href=http://$esite/admin.php?viewby=alterar>VOLTAR</a></font>");
// Pegando os dados.
$linha=mysql_fetch_array($resultado);	
}
	
	
/////////////
// EXCLUIR //
/////////////
if($_GET['acao'] == "excluir"){
// Deletando os dados selecionados
@$sql = "DELETE FROM $dbtbg WHERE id='".$_GET['id']."'";
// Executando $sql e verificando se tudo correu certo.
@$resultado = mysql_query($sql)
// Menssagen de erro.
or die ("N�o foi poss�vel realizar a exclus�o dos dados.");
// Menssagem de exito.
echo "<font face=$face size=$sizetex color='$colortex'>O GRUPO foi exclu�do com �xito!</font><br><br>
<center><font face=$face size=$sizetex1 color='$colortex'><a href=?viewby=alterar><B>VOLTAR</B></a></font></center>";
}


// Pegando data e hora.
$data = date("Y-m-d");
$hora = date("H:i:s");
//Formatando data e hora para formatos Brasileiros.
$novadata = substr($data,8,2) . "/" .substr($data,5,2) . "/" . substr($data,0,4);
$novahora = substr($hora,0,2) . "h" .substr($hora,3,2) . "min";

// Formulario de cadastro de grupos
echo "<font face=$face size=$sizetex2 color='$colortex'><b>CADASTRO DE GRUPOS</b></font><BR>
<table border=0 cellpadding=1 cellspacing=1>";


echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Nome:</font></td><td><input name='nome' type='text' size=30 value=".$linha["nome"]."><td></tr>";

echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Descri��o:</font></td><td>
<textarea id='body' name='descricao' rows=20 cols=60>".$linha["descricao"]."</textarea>";
?>
<script type="text/javascript">

         var editor1 = new tinyRTE('body', rteCSSfile,true);
         editor1.replaceTextarea(400,300);

        </script>
<?php
echo "</td></tr><tr><td><font face=$face size=$sizetex color='$colortex'>Exibir?</td>";

echo "<td><SELECT NAME='ver' SIZE='1'>
<OPTION VALUE='on' SELECTED>SIM
<OPTION VALUE='off'>N�O</SELECT></td></tr>";

echo "<tr><td><font face=$face size=$sizetex color='$colortex'><I>Se selecionar a op��o N�O o grupo n�o ser� exibido. </font>
</td></tr>";
echo "<input name='data' type='hidden' value='$data'><input name='hora' type='hidden' value='$hora'>";
echo "<tr><td></td><td align='right'><input type='submit' value='CADASTRAR'></td></tr>";
echo "</form>";
echo "<br></table>";
echo "<font face=$face size=$sizetex1 color='$colortex'><i>Todos os campos s�o obrigat�rios no cadastro.</font><br><P>";


////////////////////////
// LISTAGEM DE GRUPOS //
////////////////////////

// Selecionando os dados da tabela em ordem decrescente
$sql = "SELECT * FROM $dbtbg ORDER BY nome";

// Executando $sql e verificando se tudo ocorreu certo.
$resultado = mysql_query($sql);

/*
Aqui vai a primeira parte do segredo da pagina��o, vc deve colocar a sua QUERY neste local
colocando as condi��es para a busca
*/
$pagina = empty($HTTP_GET_VARS['pagina'])? 1 : $HTTP_GET_VARS['pagina']; // qual p�gina estamos visualizando?
$registros_por_pagina = "10";
$pagina_anterior = $pagina - 1;
$pagina_posterior = $pagina + 1;
$registro_inicio = ($registros_por_pagina * $pagina) - $registros_por_pagina;
/*
   Vamos calcular a p�gina anterior e posterior que estamos
   Em seguida devemos calcular qual o ponto nos registros retornados na QUERY, acima,
   atualmente devemos RECOME�AR a ler.

*/






$total_de_registros = mysql_num_rows($resultado);

if ($total_de_registros <= $registros_por_pagina) {
    $total_de_paginas = 1;
}elseif (($total_de_registros % $registros_por_pagina) == 0) {
    $total_de_paginas = ($total_de_registros / $registros_por_pagina);
}else{
    $total_de_paginas = ($total_de_registros / $registros_por_pagina) + 1;
}
/*
   Neste peda�o se faz o c�lculo de n�mero de p�ginas que ser� preciso
   dividir o resultado
*/


$total_de_paginas = (int) $total_de_paginas;
/*
   Caso o n�mero seja quebrado, transformar em n�mero inteiro
*/

if (($pagina > $total_de_paginas) || ($pagina < 0))
{
    echo 'n�mero da p�gina inv�lido';
    exit;
}


$sql = $sql . " LIMIT $registro_inicio, $registros_por_pagina";

$resultado = mysql_query($sql);
$total_de_registros_da_pagina = mysql_num_rows($resultado);
if ($total_de_registros_da_pagina == 0)
{
    echo 'sem registros nesta p�gina';
    
}
else
{

// Tabela de para exibi��o dos dados selecionados.
echo "
<table width=400 border=1 cellpadding=1 cellspacing=1>";
echo "<tr>";
echo "<td width=100><font color=$colortex size='$sizetex'><B>ID:</B></font></td>";
echo "<td width=100><font color=$colortex size='$sizetex'><B>Nome:</B></font></td>";
echo "<td width=50><font color=$colortex size='$sizetex'><B>Publicada:</B></font></td>";
echo "<td width=30><font color=$colortex size='$sizetex'><B>Alterar:</B></font></td>";
echo "<td width=40><font color=$colortex size='$sizetex'><B>Excluir:</B></font></td>";
echo "</tr>
";

//Realizando um loop para exibi��o de todos os dados 
while ($linha=mysql_fetch_array($resultado)) {

//Tabela com cores alternadas
if ($colorcount % 2) { $color = $colorbg; } else { $color = $colortb; }
echo "<tr align=top bgcolor=\"$color\">
";

echo "<td width=35><font color=$colortex size='$sizetex1'>".$linha["id"]."</font></td>";
echo "<td width=35><font color=$colortex size='$sizetex1'>".$linha["nome"]."</font></td>";

echo "<td width=15><font color=$colortex size='$sizetex1'>";
if ($linha["ver"] == 'on'){echo "<font color=blue>SIM 8)";} else {echo "<font color=red>N�O :(";}
echo "</font><br></td>
";

echo "<td width=50><font color=$colortex size='$sizetex1'><a href='admin.php?viewby=grupos&id=".$linha['id']."&acao=alt'>Alterar</a></font></td>
";

echo "<td width=20><font color=$colortex size='$sizetex1'><a href='admin.php?viewby=grupos&id=".$linha['id']."&acao=excluir'>Excluir<font color=red>-X</font></a></font></td>";
echo "</tr>";
$colorcount++;
}
echo "</table>";  }

$link_de_navegacao = '';
/* link "anterior" */
if($pagina_anterior)
{
    $link_de_navegacao .= " <a href='admin.php?viewby=alterar&idnome=$idnome&pagina=$pagina_anterior'>Anterior</a> ";
}
for($i = 1; $i <= $total_de_paginas; $i++)
{
    if($i != $pagina)
    {
        /* link individual para as outras p�ginas */
        $link_de_navegacao .= " <a href='admin.php?viewby=alterar&idnome=$idnome&pagina=$i'>$i</a> ";
    }else{
        $link_de_navegacao .= " <b>[$i]</b> ";
    }
}
/* link "proximo" */
if($pagina != $total_de_paginas)
{
    $link_de_navegacao .= "<a href='admin.php?viewby=alterar&idnome=$idnome&pagina=$pagina_posterior'>Pr�ximo</a>";
}

echo "<p>" . $link_de_navegacao;
?>

</html>
