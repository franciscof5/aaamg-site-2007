<?
include "stl.php";
include "config.php";
?>
<html>

<title><? echo $tituloshz; ?></title>

<body bgcolor="<? echo $colorbg; ?>" onload="setTimeout ('window.location.reload(true)',900000)">
<?
include "stl.php";
?>



<center><big><b>SHZ-Not�cias v1.0 FINAL</b></big><br>
<img src='img/shz.gif'>
</center>
<hr>
Quem faz o SHZ-Not�cias? <br><br>
<b><a href="http://www.shz.com.br">SHZ - Solu��es e Tecnologias</a></b>, desde 2001 desenvolvendo solu��es livres e servi�os de qualidade.<br><br>

<hr>
<font color=<? echo $colortex; ?> size=<? echo $sizetex; ?>>Ol�...<br>
Essa � a v1.0 FINAL do SHZ-Not�cias, � a primeira vers�o oficial do SHZ-Not�cias, com suporte a categorias e inser��o de imagens usando um editor de texto html.<br>
<b>Erros, sugest�es, crit�cas e ajudas: shz@shz.com.br</b><br><br>

Gostaria de agradecer meus parentes, amigos e todos aqueles que
me mandaram e-mail pedindo ajuda, dando dicas e sugest�es.
Agrade�o tamb�m aos investidores que der�o apoio financeiro como a MD- Solu��es Digitais<BR><BR>
Se voc� acabou de extrair o SHZ-Not�cias do ZIP siga as instru��es:<BR><BR>
<center>########################################-=Instala��o=-#######################################<BR><BR></center>

Para instalar o SHZ-Not�cias � necess�rio ter instalado:
<BR><BR>
Um servidor de Web com suporte a PHP 4<BR>
PHP 4<BR>
MySQL Server<BR><BR>

Abra um navegador de sua prefer�ncia e digite:<BR><BR>

http://endedre�o_do_seu_site/pasta_onde_est�_o_SHZ-Not�cias/instalar/index.php
<BR><BR>
E siga as instru��es.<BR>
Feito isso abra o arquivo config.php e configure os dados do servidor onde est� seu site
e tamb�m pode configurar o design do SHZ-Not�cias para se adaptar ao seu site.
<BR><BR><BR>

<center>########################################-=Utiliza��o=-#######################################</center>
<BR><BR>
Depois de instalado o sistema digite:<BR><BR>

http://endedre�o_do_seu_site/pasta_onde_est�_o_SHZ-Not�cias/admin.php
<BR>
Nessa parte ser� lhe pedido um nome e uma senha.  <br><br>
O nome voc� coloca <b>shz</b> e deixe a senha em branco. <br><br>
O usu�rio <b>shz</b> � um usu�rio indestrut�vel, para que voc� n�o
corra o risco de acidentalmente apagar todos os usu�rios e n�o
poder entrar no sistema. <br><br>
Assim que entrar no sistema entre na �rea usu�rios e clique em
<b>ALTERAR</b> na frente de <b>shz</b> na lista de usu�rios e na tela seguinte coloque uma senha.

<BR><BR><BR>
<center>########################################-=Publica��o=-#######################################</center>
<BR><BR>
O arquivo que exibe as noticias cadastradas � "noticias.php".
Voc� deve incluir o noticias.php no seu site, ex:<BR>
<textarea cols="50" rows="5"><?php echo '<?php include "shznot/noticias.php; ?>'; ?></textarea><BR>
Se o arquivo "noticias.php" n�o for ficar no mesmo diretotio dos outros arquivos edite
a linha que contem:<BR>
include("config.php");<BR>
e acrescente o caminho para o diret�rio<BR>
Exemplo:<BR><BR>
include("teste/shznoticias/config.php");<BR>
obs. troque o caminho "teste/shznoticias/config.php" para o caminho que leva ao config.php.
<BR><BR>
Para acessar um not�cias de grupo voc� deve usar o seguinte link:<BR>
<b>http://www.seusite.com.br/arquivo_onde_incluiu_o_shznoticias.php?grupo=1</b><BR>
ou<BR>
<b>http://www.seusite.com.br/shznot/noticias.php?grupo=1</b><BR>
Assim ser� listado apenas not�cias do grupo 1, para saber o numero do grupo que criou voc� deve ir no admin do sistema e clicar no bot�o GRUPOS, l� ter� uma lista de todos os grupos que vc cadastrou. Para exibir de outro grupo basta alterar o numero <B>1</B> pelo numero do grupo que deseja ver.
<BR><BR>
<B>Se n�o escolher um grupo ser� exibido as �ltimas 15 not�cias cadastradas independente do grupo.</B>


<BR><BR><BR>
<center>############################################-=EDITOR-IMG=-###########################################</center><BR>
Se voc� estiver instalando esse sistema em um ambiente windows, lembre-se de dar permi��o de grava��o para a pasta:<BR>
<B>shznot/editor/img</B><BR>
Voc� pode fazer isso com o comando: <B>chmod 777 -Rf shznot/editor/img</B><BR>
Se tiver d�vida sobre isso entre em contato com o suporte do seu servidor.



<BR><BR><BR>
<center>############################################-=INTEGRA��O=-###########################################</center><BR>
Existe um arquivo de nome <B>menu.php</B> que lista os grupos criados, sua finalidade � gerar um menu din�mico, ele j� gera os links necess�rios para acessar as not�cias.<BR>
Obs. � necess�rio que o include de menu.php e noticias.php esteja no mesmo documento.

<BR><BR><BR>
<center>############################################-=SEGURAN�A=-###########################################</center><BR>
<big><b>Depois de ter instalado o SHZ-Not�cias, apague a pasta instalar.</b></big><BR><BR>
<BR><BR><BR>

<center>############################################-=SUPORTE=-###########################################</center><BR>
<B>Entre em nosso site: www.shz.com.br</B>

<BR><BR><BR>
<center>############################################-=FIM=-###########################################</center>
<BR><BR>

David F. A. B. Fante
</font>
<br><br><br>
<center><img src='img/shz2.gif'><br>
<font size='1'>Solu&ccedil;&otilde;es e Tecnologias</font></center>
</body>
</html>
