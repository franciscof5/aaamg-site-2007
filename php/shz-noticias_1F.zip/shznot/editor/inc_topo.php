<table width="750" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="136"><img src="img/lg_aga.jpg" width="136" height="95"></td>
    <td width="614" background="img/fnd_topo_laranja.jpg" class="tituloGRANDE">http://www.agabrasil.com.br</td>
  </tr>
</table>