<?
session_start();
//Nivel minimo para acessar essa area
$nivelus = "2";
include "../fotoz/lg/se.php";
?>
<html>
<head>


<script type="text/javascript" src="editor/ImageManager/assets/dialog.js"></script>
<script language="session_start();

JavaScript" type="text/javascript">
 var myRTEconfig = { editor_lang : 'en',
                      editor_url  : 'editor/',
                      isFullEditor: true
                    };
 var rteCSSfile = 'france.css';
</script>
<script language="JavaScript" type="text/javascript" src="editor/tinyRTE_setup.js"></script>


<title>AGA Sys - Sistema de Conte&uacute;do Web</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo_agasys.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="EFEFEF">

<?echo"<form action='";
if($_GET['formalt'] == "sim"){
echo"cadastrando_conteudo.php?ir=sim&formalt=sim&alteraf=sim&";}else{
echo"cadastrando_conteudo.php?ir=sim&";}
echo"id=".$_GET['id']."&catgf=".$_GET['catgf']."&id2=".$_GET['id2']."' method='post'>";?>


<table width="775" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr> 
    <td width="136"><img src="img/lg_aga.jpg" width="136" height="95"></td>
    <td width="639" background="img/fnd_topo_laranja.jpg" class="tituloGRANDE">http://www.agabrasil.com.br</td>
  </tr>
  <tr background="img/fnd_editor.jpg"> 
    <td colspan="2" align="left" valign="top" bgcolor="#FFFFFF"><table width="750" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr> 
          <td width="50" height="55"><img src="img/ico_plug.gif" width="40" height="40"></td>
          <td width="700" colspan="2" class="tituloGERAL">Powered by AGA<font color="#FF9900"><em>Publish 
            </em></font>1.4</td>
        </tr>
        <tr> 
          <td width="50" height="20" class="textoGERAL">&nbsp;</td>
          <td width="650" height="20" class="textoGERAL"> 
            <?include "ola.php";?>
          </td>
          <td width="50" class="textoGERAL"><div align="center"><a href="index.php">HOME</a></div></td>
        </tr>
      </table>
      <table width="750" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr> 
          <td width="50" height="55"><img src="img/ico_conteudo.gif" width="40" height="40"></td>
          <td width="700" height="55" class="tituloGERAL"> 
            <?
if($_GET['formalt'] == "sim"){echo"Alterando";}else{ echo"Cadastrando";} ?>
            conte&uacute;do.</td>
        </tr>
        <tr> 
          <td></td>
          <td width="700" class="textoGERAL"> 
            <?
//Quando o usuario clicar em alterar � incluido o
//arquivo que puxa as informa��es j� gravadas
if($_GET['formalt'] == "sim" and empty($_GET['alteraf'])){
include "../fotoz/alterar.php";
}
//Quando o usuario clicar confirmar o formulario o
//sistema ira adicionar no banco de dados por esse arquivo
//que s� � incluso quando o usuario envia as informa��es
if($_GET['ir'] == "sim"){
include "../fotoz/valida.php";
}

?>
          </td>
        </tr>
        <tr> 
          <td colspan="2"><table width="750" border="0" cellspacing="2" cellpadding="0">
              <tr> 
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Item 
                    de menu:</div></td>
                <td width="600" height="30" bgcolor="#eeeeee" class="textoGERAL"> 
                  <strong><? echo strtoupper($_GET['catgf'])?></strong></td>
              </tr>
              <?
// Pegando data e hora.
$data = date("Y-m-d");
$hora = date("H:i:s");

//Form com os campos necessarios

echo "<input name='data' type='hidden' value='$data'><input name='hora' type='hidden' value='$hora'>";
echo "<input name='ver' type='hidden' value='on'>";
echo "<input name='categoria' type='hidden' value='".$_GET['id']."'>";
?>
              <tr> 
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Titulo:</div></td>
                <td width="600" height="30" bgcolor="#eeeeee"><input name="titulo" type="text" class="textoGERAL" value="
<?
if($_GET['formalt'] == "sim"){
echo $titulo;}else{
echo $titulopr;}?>
" size="40"></td>
              </tr>
            </table></td>
        </tr>
      </table> 
    </td>
  </tr>
</table>

<textarea id="body" name="texto" cols="60" rows="20" tabindex="90">
 </textarea>
   <script type="text/javascript">

         var editor1 = new tinyRTE('body', rteCSSfile,true);
         editor1.replaceTextarea(400,300);

        </script>

<p align="left"> 
  <input name="Submit2" type="submit" class="botao" value="Salvar">
</p>
<table width="775" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr> 
    <td colspan="2"><img src="img/img_base_01.jpg" width="775" height="23"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_02.jpg" width="775" height="16"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_03.jpg" width="775" height="20"></td>
  </tr>
  <tr bgcolor="EFEFEF"> 
    <td height="25" colspan="2" class="textoGERAL"><div align="center">AGA Brasil 
        Comunica&ccedil;&atilde;o Interativa. Todos os direitos reservados. Fones: 
        (34) 3223-9884 / 3086-0092.</div></td>
  </tr>
</table>
<p align="center">&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
