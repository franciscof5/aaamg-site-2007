<?
session_start();
//Nivel minimo para acessar essa area
$nivelus = "2";
include "../fotoz/lg/se.php";
?>
<html>
<head>
<title>AGA Sys - Sistema de Conte&uacute;do Web</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo_agasys.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="EFEFEF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="775" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="136"><img src="img/lg_aga.jpg" width="136" height="95"></td>
    <td width="639" background="img/fnd_topo_laranja.jpg" class="tituloGRANDE">http://www.franciscojunior.com.br</td>
  </tr>
  <tr> 
    <td width="136" height="83" align="left" valign="top" background="img/fnd_lateral.jpg"><table width="136" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="136" height="25"><img src="img/img_topo_lateral.jpg" width="136" height="25"></td>
        </tr>
        <tr> 
          <td width="136" height="58"><table width="120" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr> 
                <td class="textoGERAL"><strong>Hoje &eacute;:<br>
<?include "data.php";?></strong></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
    <td width="639" height="83" background="img/fnd_topo_branco.jpg"><table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="50" height="55"><img src="img/ico_plug.gif" width="40" height="40"></td>
          <td width="570" colspan="2" class="tituloGERAL">Powered by AGA<font color="#FF9900"><em>Publish 
            </em></font>1.4</td>
        </tr>
        <tr> 
          <td width="50" height="20" class="textoGERAL">&nbsp;</td>
          <td width="500" height="20" class="textoGERAL"><?include "ola.php";?></td>
          <td width="70" class="textoGERAL"><div align="center"><a href="index.php">HOME</a></div></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="136" height="400" align="left" valign="top" background="img/fnd_lateral.jpg"><table width="136" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class="tituloGERAL"><div align="center">Novidades AGA</div></td>
        </tr>
        <tr> 
          <td width="136" height="80" class="textoGERAL"><div align="center">As 
              &uacute;ltimas novidades<br>
              em tecnologia e<br>
              produtos AGA Brasil<br>
              estar&atilde;o bem aqui!<br>
              N&atilde;o perca!</div></td>
        </tr>
        <tr> 
          <td width="136" height="22" class="textoGERAL"><div align="center">Publicidade</div></td>
        </tr>
        <tr>
          <td height="22" class="textoGERAL"><div align="center"></div></td>
        </tr>
      </table></td>
    <td width="639" align="left" valign="top" bgcolor="#FFFFFF"><table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="50" height="55"><img src="img/ico_conteudo.gif" width="40" height="40"></td>
          <td width="570" height="55" class="tituloGERAL">Criando sistema de eventos: <font color="#006699"></font></td>
        </tr>

		<tr><td></td><td class="textoGERAL">
<?
//Quando o usuario clicar confirmar o formulario o
//sistema ira adicionar no banco de dados por esse arquivo
//que s� � incluso quando o usuario envia as informa��es
if($_GET['ir'] == "sim"){
include "../fotoz/inst/inserir.php";
//Exemplo
echo '  <textarea cols="65" rows="5">
<?
//Arquivo para onde o link vai apontar (voc� deve incluir o
//fotoz/not.phpinfo no arquivo que vai apontar).
$arquivox = "eventos_conteudo.php";
//ID do sistema de eventos a ser exibido
$idsis = "'.$verid.'";
//Aqui voc� pode colocar algo antes do titulo
$antesdot = "<strong>&#8226; <font size=2><b>";
//Aqui voc� pode colocar algo depois do titulo
$depoisdot = "</b></strong></font>";
//Mostrar Data e Hora que p evento foi incluido - sim ou nao
$datahora = "sim";
//Aqui voc� pode colocar algo antes da data e hora
$antesdadh = "<font color=000000>";
//Aqui voc� pode colocar algo depois da data e hora
$depoisdadh = "</font>";
//Incluindo arquivo que lista os eventos
include "fotoz/list.php";
?></textarea>';
}
?>
		</td></tr>
        <tr>
          <td width="50">&nbsp;</td>
          <td width="570"><table width="562" border="0" cellspacing="2" cellpadding="0">
              <tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Tipo:</div></td>
                <td width="400" height="30" class="textoGERAL"> <strong>SISTEMA</strong></td>
              </tr>
              <tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Item
                    do menu:</div></td>
                <td height="30" class="textoGERAL"><strong>
                Sistema de eventos
                </strong></td>
              </tr>

<?
//Adicionando o arquivo que contem os dados j� cadastrados
//include "../fotoz/fot/institu.php";
//Form com os campos necessarios
echo"<form action='adic_even_sis.php?ir=sim&refi=eventos' method='post' enctype='multipart/form-data'>";

echo "<input name='ativagr' type='hidden' value='on'>
      <input name='tipogr' type='hidden' value='p'>";
?>

              <tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Nome:</div></td>
                <td width="400" height="30"><input name="nomegr" type="text" class="textoGERAL" value="<?echo"$nomeglr";//nome ja gravado?>" size="40"></td>
              </tr>
		<tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Grupo:</div></td>
                <td width="400" height="30"><select name="grupo" class="textoCAIXA">
		<option value=''>- Sem grupo</option>
		<?php include "../fotoz/grupo/select.php";?>
		</select></td>
              </tr>
              <tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="top" bgcolor="#dddddd" class="textoGERAL"><div align="right"></div></td>
                <td width="400" height="30"><input name="Submit2" type="submit" class="botao" value="Criar"></form></td>
              </tr>
              <tr class='textoGERAL'>
<td height='25'>
<a href='lista_even_sis.php?refi=eventos'>Editar Sistema de eventos</a></td>
<td height='25'>&nbsp;</td>
<td height='25'>&nbsp;</td>
</tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
        <tr> 
          <td width="50">&nbsp;</td>
          <td width="570">&nbsp;</td>
        </tr>
        <tr> 
          <td width="50">&nbsp;</td>
          <td width="570">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_01.jpg" width="775" height="23"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_02.jpg" width="775" height="16"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_03.jpg" width="775" height="20"></td>
  </tr>
  <tr> 
    <td height="25" colspan="2" class="textoGERAL"><div align="center">AGA Brasil 
        Comunica&ccedil;&atilde;o Interativa. Todos os direitos reservados. Fones: 
        (34) 3223-9884 / 3086-0092.</div></td>
  </tr>
</table>
</body>
</html>
