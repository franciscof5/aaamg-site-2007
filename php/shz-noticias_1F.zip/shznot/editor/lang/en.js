// I18N Translation english

tinyRTE.I18N = {

      // toolbar
		bold:                 "Negrito",
		italic:               "Italico",
		underline:            "Sublinhado",
		strikethrough:        "Strikethrough",
		subscript:            "Subscript",
		superscript:          "Superscript",
		justifyleft:          "Justify Left",
		justifycenter:        "Justify Center",
		justifyright:         "Justify Right",
		justifyfull:          "Justify Full",
		insertorderedlist:    "Ordered List",
		insertunorderedlist:  "Bulleted List",
		outdent:              "Decrease Indent",
		indent:               "Increase Indent",
		forecolor:            "Cor Fonte",
		hilitecolor:          "Cor Fundo",
		inserthorizontalrule: "Linha Horizontal",
		createlink:           "Inserir Web Link",
		insertimage:          "Inserir/Modificar Imagem",
		inserttable:          "Inserir Tabela",
		htmlmode:             "Ver codigo HTML",
		about:                "Sobre esse editor",
		undo:                 "Desfazer ultima a��o",
		redo:                 "Refazer ultima a��o",
      removeformat:         "Remover formata��o HTML",
      forecolor:            "Change Textcolor",
      hilitecolor:          "Change Backgroundcolor",
      div_left:             "Insert Left Box",
      div_right:            "Insert Right Box",
      mediamanager:         "Insert Media / Popup Image",

      // prompts
      promptLink:           "Por favor coloque a URL:",
      promptImage:          "Por favor coloque URL da imagem:",

      // Warning messages
      empty_link_range:     "Selecione um texto para criar um link!",
      empty_font_range:     "Selecione um texto para formata��o de fonte!",

      // Popup windows
      ok:                   "OK",
      cancel:               "Cancelar",

      about_info:           "tinyRTE Vers�o-SHZ " + "\n" +
                            "Esse editor � baseado no RTE\n" +
                            "Foi modificado para um webblog(nucleos) e novamente alterado para o sistema SHZ\n" +
                            "Abaixo segue o about original.\n" +
			    "This work is licensed under the terms of BSD-license\n" +
                            "Copyright(c) - Alfred 'Alf mit i' Scheibl (alfmiti.net)\n" +
                            "2004 Vienna - All Rights Reserved\n\n\n"+
                            "Credits:\n"+
                            "MediaManager based on Wei Zhuo\'s ImageManager + Editor\n"+
                            "http://www.zhuo.org/htmlarea/docs/\n\n"+
                            "Idea and some code snippets taken from Kevin Roth's RTE-Editor\n" +
                            "http://www.kevinroth.com/rte/demo.htm\n\n"+
                            "Inspired from mishoos great HTMLarea\n"+
                            "http://www.interactivetools.com/"

};

