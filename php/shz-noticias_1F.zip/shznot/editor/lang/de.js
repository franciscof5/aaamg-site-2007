// I18N Translation german

tinyRTE.I18N = {
      // toolbar
		bold:                 "Fett",
		italic:               "Kursiv",
		underline:            "Unterstrichen",
		strikethrough:        "Durchgestrichen",
		subscript:            "Hochgestelltt",
		superscript:          "Tiefgestellt",
		justifyleft:          "Linksb�ndig",
		justifycenter:        "Zentriert",
		justifyright:         "Rechtsb�ndig",
		justifyfull:          "Blocksatz",
		insertorderedlist:    "Nummerierte Liste",
		insertunorderedlist:  "Liste mit Aufzaehlungszeichen",
		outdent:              "Einzug verkleinern",
		indent:               "Einzug vergroessern",
		forecolor:            "Schriftfarbe",
		hilitecolor:          "Hintergrundfarbe",
		inserthorizontalrule: "Horizontale Linie",
		createlink:           "Hyperlink einf�gen",
		insertimage:          "Bild einfuegen",
		htmlmode:             "Im HTMLmodus wechseln",
		about:                "Ueber diesen Edior",
		undo:                 "Letzten Vorgang rueckgaengig",
		redo:                 "Letzten Vorgang wiederherstellen",
      removeformat:         "HTML Formatierung entfernen",
      div_left:             "Insert Left Box",
      div_right:            "Insert Right Box",
      mediamanager:         "Bild oder andere Medien einfuegen",

      // prompts
      promptLink:           "Bitte eine URL eingeben:",
      promptImage:          "Bitte eine URL zu einem Bild eingeben",

      // Warning messages
      empty_link_range:     "Zum Link einfuegen muessen sie zuerst einen Text selektieren !",
      empty_fonr_range:     "Um eine Schrift zu formatieren muessen sie zuerst einen Text selektieren!",

      // Popup windows
      ok:                   "OK",
      cancel:               "Abbrechen",

      about_info:           "tinyRTE Release " + tinyRTE.cfg.version + "\n" +
                            "special BLOG:CMS / Nucleus Edition\n" +
                            "A free lightweight Cross-Browser Rich Text Editor\n" +
                            "This work is licensed under the terms of BSD-license\n" +
                            "Copyright(c) - Alfred 'Alf mit i' Scheibl (alfmiti.net)\n" +
                            "2004 Vienna - All Rights Reserved\n\n\n"+
                            "Credits:\n"+
                            "MediaManager based on Wei Zhuo\'s ImageManager + Editor\n"+
                            "http://www.zhuo.org/htmlarea/docs/\n\n"+
                            "Idea and some code snippets taken from Kevin Roth's RTE-Editor\n" +
                            "http://www.kevinroth.com/rte/demo.htm\n\n"+
                            "Inspired from mishoos great HTMLarea\n"+
                            "http://www.interactivetools.com/"


};
