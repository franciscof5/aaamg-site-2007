// tinyRTE - Copyright (c)2004  Alfred 'Alf mit i' Scheibl // www.alfmiti.net
// This copyright notice MUST stay intact for use (see license.txt).

// Microsoft Internet Explorer Browser specific code
// $Id: tinyRTE_ie.js,v 1.2 2004/08/21 17:47:35 Alfmiti Exp $

document.onmouseover = document.onmouseup = raiseButton;
document.onmouseout  = normalButton;
document.onmousedown = lowerButton;

function raiseButton(e) {
  var eventEle = window.event.srcElement;
  var className = eventEle.className;
  if (className == 'rteImage' || className == 'rteImageLowered') eventEle.className = 'rteImageRaised';
};

function normalButton(e) {
  var eventEle = window.event.srcElement;
  var className = eventEle.className;
  if (className == 'rteImageRaised' || className == 'rteImageLowered') eventEle.className = 'rteImage';
};

function lowerButton(e) {
  var eventEle = window.event.srcElement;
  var className = eventEle.className;
  if (className == 'rteImage' || className == 'rteImageRaised') eventEle.className = 'rteImageLowered';
};


function rteSetCurrentEditor(e) {
  var targetElement = event.srcElement;
  currentRTE = targetElement.id;
}


tinyRTE.addEventListener = function(eleObj, eventType, listener, useCature) {
   eventType = 'on' + eventType;
   var res = eleObj.attachEvent(eventType,listener);
   return res;
}

tinyRTE.addEventListener(window,'load', rteMakeUnSelectable, false);

// function to solve IE lost selection problem
function rteMakeUnSelectable() {
    var all = document.all;
    var l = all.length;
    for (var i = 0; i < l; i++) {
      	if (all[i].tagName != "INPUT" && all[i].tagName != "TEXTAREA" && all[i].tagName != "IFRAME")
      		 all[i].unselectable = "on";
    }
}


// the global Button functions
function rteExecCmd(rte, command, cmdParams) {

  var rteObj = rteInstance[rte];
  if (command == 'italic') {  // MSIE use em tag instead of i !!
      surroundHTML(rte,'<i>','</i>');
      return;
  }
  rteObj.executeCmd(command,null);
}


function surroundHTML(rteId,startTag,endTag) {

  var rteObj = rteInstance[rteId];
  rteObj.iFrameRoot.focus();
  var range = typeof cachedRange == 'object' ? cachedRange : rteObj.getEditorRange();
  var newHtml = range.htmlText;
  newHtml = startTag + newHtml + endTag;
  range.pasteHTML(newHtml);
  if (rteObj.selectionType == 'Text') range.select();
}


//Function to set color
function rteSetColor(color) {
  var rteObj = rteInstance[currentRTE];
  rteObj.iFrameRoot.focus();
  tinyRTE.togglePopup(rteColorPickerObj);

  if (currentCommand == "hilitecolor")  currentCommand = "backcolor";
  rteObj.executeCmd(currentCommand, color);
  if ((typeof cachedRange == 'object') && rteObj.selectionType == 'Text') {
     cachedRange.select();
     cachedRange = null;
  }

}


function rteGetElementByTagName(tagName) {
  return document.all.tags(tagName);
}

tinyRTE.getIframeObject = function(iFrameId) {
  return  document.frames[iFrameId].document;
}

tinyRTE.getContentWindow = function(iFrameId) {
  var ref = document.getElementById(iFrameId);
  if (typeof ref.contentWindow != 'undefined') return  ref.contentWindow.document;
  return null;
}

tinyRTE.prototype.enableDesignMode = function(rteId) {
  var frameHtml = this.getIframeHTML();
  var contentObj = tinyRTE.getContentWindow('iFrame_' + rteId);
  contentObj.open();
  contentObj.write(frameHtml);
  contentObj.close();
  contentObj.designMode = "on";
  // contentObj.body.contentEditable = true;
  this.iFrameRoot = document.frames[rteId];  // cache this object for focus
  var el = this.iFrameRoot;

  // make linebreaks instead of paragraph similar gecko
  if (tinyRTE.cfg.msie_use_br) {
      this.iFrameRoot.document.onkeydown = function () {
        	if (el.event.keyCode == 13) {	// ENTER
        		var sel = el.document.selection;
        		if (sel.type == "Control")	return;
        		// FIXME!! add same parent element checks, we shouldn't alway a br
        		var rng = sel.createRange();

        		rng.pasteHTML("<BR>");
        		el.event.cancelBubble = true;
        		el.event.returnValue = false;
        		rng.select();
        		rng.collapse(false);
        		return false;
        	}
      };
  };

  return true;
}

tinyRTE.prototype.switchDesignMode = function (rteId,mode) {
  // for MSIE we must do nothing here..
}

tinyRTE.prototype.setHtml = function() {
  return tinyRTE.cfg.trickDiv + '<p style="margin:0px">' + this.objTextarea.value + '</p></div>';
}

// getHtml with special convertings for gecko
tinyRTE.prototype.getHtml = function() {

  // MSIE needs paragraph on first position otherwise he would make div instead of p on return - crazy
  var trickDiv = tinyRTE.cfg.trickDiv + '<p style="margin:0px">';

  var str = this.contentObj.body.innerHTML;
  str = str.trim();
  if (str.length == 0 || str == '&nbsp;') return '';

  // tag names to lowercase (also xhtml conform) and quote attributes
  str = str.replace(/(<\/|<)\s*([^ \t\n>]+)/ig, function(matchStr, p1, p2) {
  	    return p1 + p2.toLowerCase();
  });
  // str = str.replace(/(\w+=)[*"'](.+?)[*"']/ig,'$1"$2"');

  // check of our real wysiwyg trickdiv and remove
  // is all little tricky while IE rewrites the tags (whitespaces, quots)
  var dynRegex = new RegExp('^'+ trickDiv.prepareCompare());
  if (dynRegex.test(str.prepareCompare()) == true) {
      // remove trickDiv
      str = str.replace(/^<div(.*?)>([\s]+)<p/,'<div remove><p');
      str = str.replace(/^<div(.*?)><p([^>]*)>/,'');
      str = str.replace(/<\/p>(\s+)<\/div>$/,'</p></div>');
      str = str.replace(/<\/p><\/div>$/,'');
      str = str.trim();
  }


  // remove empty span and font tags
  str = str.replace(/<(span|font)([^>\/>]*)(><|>[&nbsp;|\s]+<)\/(span|font)>/ig,'');

  // basic convert to xhtml
  if (tinyRTE.cfg.xhtml_output) {
     str = str.replace(/<(br|input|meta|link|img)([^>\/>]*)>/ig,'<$1$2 />');
     str = str.replace(/<(br|input|meta|link|img)([^>]*[^\/])>/,'<$1$2 />');

     if (tinyRTE.cfg.xhtml_strict) {
        // will be extended in future versions
        str = str.replace(/<i>([^>].*?)<\/i>/igm,'<span style="font-style: italic;">$1<\/span>');
        str = str.replace(/<u>([^>].*?)<\/u>/igm,'<span style="text-decoration: underline;">$1<\/span>');
        str = str.replace(/<strike>([^>].*?)<\/strike>/igm,'<span style="text-decoration: line-through;">$1<\/span>');
     }

     str = str.replace(/<a href="([^java].*?)"(.*?)>([^>].*?)<\/a>/,
                       function (matchStr,linkUrl,more,text) {
                          return '<a href="' + encodeHtml(linkUrl)+ '" '+ more +'>'+text+'</a>';
                       });
     str = str.convertFontToSpan();
  }

  // strange msie -- makes sometimes div instaed of p -> see first comment
  str = str.replace(/<div>([^>\/>].*?)<\/div>/i, '<p>$1</p>');

  // cleanup unnecessary <br/> and selfclosing <p/>
  str = str.replace(/<br \/>([\n|\r\n]+)<\/p>/mgi, '</p>');
  str = str.replace(/<br \/><\/p>/mgi, '</p>');
  str = str.replace(/<p\/>/i, '');

  // Todo encode Textdata

  function encodeHtml(str) {
    // some usefull encondings into HTMLentities
    str = str.replace(/&[^amp]/ig, "&amp;");
    str = str.replace(/\x22/ig, "&quot;");
    str = str.replace(/'/i, "&quot;");
	 str = str.replace(/</ig, "&lt;");
	 str = str.replace(/>/ig, "&gt;");
    return str;
  }

  return str.trim();
}


tinyRTE.prototype.setTextareaAttribute = function(rteWidth, rteHeight) {
   this.objTextarea.style.width = (rteWidth - 2) + 'px';
   this.objTextarea.style.height = rteHeight + 'px';
}


tinyRTE.prototype.executeCmd = function (cmd, commandValue){
  if (this.contentObj) {
     if (cmd == 'formatblock') commandValue = '<'+commandValue+'>';
     this.iFrameRoot.focus();
     try {
        this.contentObj.execCommand(cmd, false, commandValue);
     } catch (e) { if (rteCfgDebug) alert(e); }
     this.iFrameRoot.focus();
  }
}

tinyRTE.prototype.getEditorRange = function() {
  this.iFrameRoot.focus();
  var selection = this.iFrameObj.selection;
  this.selectionType = selection.type;
  return selection.createRange(selection);
}

tinyRTE.prototype.createRange = function(selection) {
  if (selection != 'undefined')
     return selection.createRange();
  return null;
}

tinyRTE.prototype.getEditorRangeText = function() {
  var range = this.getEditorRange();
  cachedRange = range;
  return range.htmlText;
}

tinyRTE.prototype.emptyRangeCheck = function(range,i18nKey) {
   range = range.htmlText;
   if (range == '' || range == null) {
      alert(tinyRTE.I18N[i18nKey]);
      return false;
   }
   return true;
}

