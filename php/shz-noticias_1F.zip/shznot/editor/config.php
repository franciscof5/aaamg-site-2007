<?
@include "../config.php";

if(!empty($econfig)){
//$esite="localhost/shz/sys/admin/";
$esite = str_replace("fotoz", "admin", $esite);

//Caminho
$caminho= $caminho."/";
}
?>
