// tinyRTE  - Copyright (c)2004  Alfred 'Alf mit i' Scheibl // www.alfmiti.net
// This copyright notice MUST stay intact for use (see license.txt).

// tinyRTE Media Manager Plugin
// $Id: text_mediamanager.js,v 1.2 2004/08/21 17:50:31 Alfmiti Exp $

var manager = new ImageManager(myEditorUrl + 'ImageManager','en');

ImageManager.I18N = {
  	"Image Manager" : "Image Manager"
};
var I18N = ImageManager.I18N;

function ImageManager(manager_url,lang) {
	var plugin_lang = manager_url + "/lang/" + lang + ".js";
	this.url = manager_url + '/manager.php';
   // deactivated as long translations not ready
	// document.write("<script type='text/javascript' src='" + plugin_lang + "'></script>");
}


// overrule simple the standard nucleus function
function addMedia() {

  Dialog(manager.url, function(param) {
    if (!param) {  // user must have pressed Cancel
      return false;
    } else {
       nucleusInsertMediaLink(param);
       return true;
    }
  }, null);

  return;
}


function nucleusInsertMediaLink(param) {

  var HTMLstr = '';

  if (param.f_link_url > '') {
      if (param.f_link_target == 'js') {
         var prop = 'status=no, toolbar=no, scrollbars=no, resizable=yes, width='+param.f_link_width+', height='+param.f_link_height;
         HTMLstr = '<a href="javascript:window.open(\'' + param.f_link_url + '\', \'imagepopup\', \'' + prop + '\');">';
      } else {
         HTMLstr = rteBuildLinkString('', param.f_link_url, param.f_link_target,param.f_link_alt);
      }
      if (param.f_file.length == 0)
         HTMLstr += param.f_link_file;
  }

  if (param.f_file.length > 0) {

     // check for style settings
     var styles= '';
     var border = '';var margin = ''; var align='';
     if (param.f_borderwidth > '') {
        var b_color = param.f_bordercolor > '' ? param.f_bordercolor : '#000';
        border = 'border:'+ param.f_borderwidth +'px solid '+ b_color +';';
     }

     var vs = param.f_vert; var hs = param.f_horiz;
     if (vs > '' && hs > '') margin  = 'margin:'+ vs +'px '+ hs +' px '+ vs +'px '+ hs +'px;';
     if (vs > '' && hs == '') margin = 'margin:'+ vs +'px 0 '+ vs +'px 0;';
     if (vs == '' && hs > '') margin = 'margin: 0 '+ hs +' px '+ '0 '+ hs +'px;';

     if (param.f_align > '') {
        switch (param.f_align) {
           case 'left'  : align = 'float:left'; break;
           case 'right' : align = 'float:right'; break;
           case 'top'   : align = 'vertical-align:top;';break;
           case 'bottom': align = 'vertical-align:bottom;';break;
           case 'base'  : align = 'vertical-align:baseline;';break;
           case 'middle': align = 'vertical-align:middle;';break;
        }
     }

     if (border > '' || margin > '' || align > '') {
        styles = ' style="'+ border + margin + align +'"';
     }

     HTMLstr += '<img src="'+param.f_url+'" width="'+ param.f_width +'" height="'+param.f_height+'" '
                  + 'alt="' + param.f_file + '" title="'+param.f_alt+'"'+ styles +' />';
  }

  if (param.f_link_url > '') {
      HTMLstr += '</a>';
  }

  insertAtCaret(HTMLstr);
  updAllPreviews();
}

function rteBuildLinkString(protocol, linkUrl, target, title) {
  target = typeof target != 'undefined' && target > '' ? ' target="' + target + '" ' : '';
  title  = typeof title != 'undefined' && title > '' ? title = ' title="' + title + '"' : '';
  var newLink = '<a href="' + protocol + linkUrl +'"'+ target + title + '>';
  return newLink;
};
