<?
session_start();
//Nivel minimo para acessar essa area
$nivelus = "2";
include "../fotoz/lg/se.php";
?>
<html>
<head>
<title>AGA Sys - Sistema de Conte&uacute;do Web</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo_agasys.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="EFEFEF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="775" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="136"><img src="img/lg_aga.jpg" width="136" height="95"></td>
    <td width="639" background="img/fnd_topo_laranja.jpg" class="tituloGRANDE">http://www.franciscojunior.com.br</td>
  </tr>
  <tr> 
    <td width="136" height="83" align="left" valign="top" background="img/fnd_lateral.jpg"><table width="136" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="136" height="25"><img src="img/img_topo_lateral.jpg" width="136" height="25"></td>
        </tr>
        <tr> 
          <td width="136" height="58"><table width="120" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr> 
                <td class="textoGERAL"><strong>Hoje &eacute;:<br>
<?include "data.php";?></strong></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
    <td width="639" height="83" background="img/fnd_topo_branco.jpg"><table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="50" height="55"><img src="img/ico_plug.gif" width="40" height="40"></td>
          <td width="570" colspan="2" class="tituloGERAL">Powered by AGA<font color="#FF9900"><em>Publish 
            </em></font>1.4</td>
        </tr>
        <tr> 
          <td width="50" height="20" class="textoGERAL">&nbsp;</td>
          <td width="500" height="20" class="textoGERAL"><?include "ola.php";?></td>
          <td width="70" class="textoGERAL"><div align="center"><a href="index.php">HOME</a></div></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="136" height="400" align="left" valign="top" background="img/fnd_lateral.jpg"><table width="136" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class="tituloGERAL"><div align="center">Novidades AGA</div></td>
        </tr>
        <tr> 
          <td width="136" height="80" class="textoGERAL"><div align="center">As 
              &uacute;ltimas novidades<br>
              em tecnologia e<br>
              produtos AGA Brasil<br>
              estar&atilde;o bem aqui!<br>
              N&atilde;o perca!</div></td>
        </tr>
        <tr> 
          <td width="136" height="22" class="textoGERAL"><div align="center">Publicidade</div></td>
        </tr>
        <tr>
          <td height="22" class="textoGERAL"><div align="center"></div></td>
        </tr>
      </table></td>
    <td width="639" align="left" valign="top" bgcolor="#FFFFFF"><table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="50" height="55"><img src="img/ico_conteudo.gif" width="40" height="40"></td>
          <td width="570" height="55" class="tituloGERAL">Alterando CLIENTE:
          </td></tr>
            		<tr><td></td><td class="textoGERAL">
<?
//Quando o usuario clicar confirmar o formulario o
//sistema ira adicionar no banco de dados por esse arquivo
//que s� � incluso quando o usuario envia as informa��es
if($_GET['ir'] == "sim"){
include "../fotoz/us/validaus.php";
}

?>
		</td></tr>
        <tr> 
          <td width="50">&nbsp;</td>
          <td width="570"><table width="500" border="0" cellspacing="0" cellpadding="0">
<?
if(empty($erro)){
include "../fotoz/us/alterarus.php";
}
//Form com os campos necessarios
echo"<form action='alterando_cliente.php?ir=sim&uss=alte&id=".$_GET['id']."' method='post'>";
echo "<input name='nivel' type='hidden' value='c'>
      <input name='nomecf' type='hidden' value='$nomecf'>";
if($nivelusuario != 3 and $nivel != 3){
echo"<input name='nivel' type='hidden' value='c'>";
}
if($nivel == 3){
echo"<input name='nivel' type='hidden' value='3'>";
}
?>
              <tr> 
                <td width="150" height="25" class="textoGERAL"><div align="right">Nome*:</div></td>
                <td width="350" height="25"><input name="nomeca" type="text" class="textoGERAL" size="50" value='<?if($erroc != 1){echo$_POST['nomeca'];}else{echo $nomeu;}?>'></td>
              </tr>
              <tr> 
                <td width="150" height="25" class="textoGERAL"><div align="right">E-mail*:</div></td>
                <td width="350" height="25"><input name="email" type="text" class="textoGERAL" size="50" value='<?if($erroc != 1){echo$_POST['email'];}else{echo $emailu;}?>'></td>
              </tr>
              <tr> 
                <td width="150" height="25" class="textoGERAL"><div align="right">Telefone:</div></td>
                <td width="350" height="25"><input name="telefone" type="text" class="textoGERAL" size="50" value='<?if($erroc != 1){echo$_POST['telefone'];}else{echo $telefone;}?>'></td>
              </tr>
              <tr> 
                <td width="150" height="25" class="textoGERAL"><div align="right">Empresa:</div></td>
                <td width="350" height="25"><input name="empresa" type="text" class="textoGERAL" size="50" value='<?if($erroc != 1){echo$_POST['empresa'];}else{echo $empresa;}?>'></td>
              </tr>
              <tr> 
                <td width="150" height="25" class="textoGERAL"><div align="right">Cidade:</div></td>
                <td width="350" height="25"><input name="cidade" type="text" class="textoGERAL" size="50" value='<?if($erroc != 1){echo$_POST['cidade'];}else{echo $cidade;}?>'></td>
              </tr>
              <tr> 
                <td width="150" height="25" class="textoGERAL"><div align="right">Estado:</div></td>
                <td width="350" height="25"><input name="estado" type="text" class="textoGERAL" size="50" value='<?if($erroc != 1){echo$_POST['estado'];}else{echo $estado;}?>'></td>
              </tr>
<?if($nivelusuario == 3 and $nivel != 3){ ?>
              <tr>
                <td width="150" height="25" class="textoGERAL"><div align="right">Conta ADMIN:</div></td>
                <td width="350" height="25" class="textoGERAL">
                <input type="radio" name="nivel" value="2" <?if($nivel=="2"){echo"CHECKED";}?>>
                </td></tr>
              <tr>
                <td width="150" height="25" class="textoGERAL"><div align="right">Conta Cliente:</div></td>
                <td width="350" height="25" class="textoGERAL">
                <input type="radio" name="nivel" value="c" <?if($nivel!="2"){echo"CHECKED";}?>>
                </td>
              </tr>
<?}?>
              <tr> 
                <td width="150" height="25" class="textoGERAL"><div align="right">Senha*:</div></td>
                <td width="350" height="25"><input name="senhaca" type="password" class="textoGERAL" size="20"></td>
              </tr>
              <tr> 
                <td height="25" class="textoGERAL"><div align="right">Confirma senha*:</div></td>
                <td height="25"><input name="senhaco" type="password" class="textoGERAL" size="20"></td>
              </tr>
              <tr> 
                <td height="25">&nbsp;</td>
                <td height="25"><input name="Submit" type="submit" class="botao" value="Cadastrar"></td>
              </tr>
            </table></td>
        </tr>
        <tr class='textoGERAL'>
<td height='25'>&nbsp;</td><td height='25'>
<a href='adicionando_cliente_lista.php'>Lista de clientes</a></td>
<td height='25'>&nbsp;</td>
</tr>
      </table></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_01.jpg" width="775" height="23"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_02.jpg" width="775" height="16"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_03.jpg" width="775" height="20"></td>
  </tr>
  <tr> 
    <td height="25" colspan="2" class="textoGERAL"><div align="center">AGA Brasil 
        Comunica&ccedil;&atilde;o Interativa. Todos os direitos reservados. Fones: 
        (34) 3223-9884 / 3086-0092.</div></td>
  </tr>
</table>
</body>
</html>
