<?
session_start();
//Nivel minimo para acessar essa area
$nivelus = "2";
include "../fotoz/lg/se.php";
?>
<html>
<head>
<title>AGA Sys - Sistema de Conte&uacute;do Web</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo_agasys.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="EFEFEF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="775" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="136"><img src="img/lg_aga.jpg" width="136" height="95"></td>
    <td width="639" background="img/fnd_topo_laranja.jpg" class="tituloGRANDE">http://www.franciscojunior.com.br</td>
  </tr>
  <tr> 
    <td width="136" height="83" align="left" valign="top" background="img/fnd_lateral.jpg"><table width="136" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="136" height="25"><img src="img/img_topo_lateral.jpg" width="136" height="25"></td>
        </tr>
        <tr> 
          <td width="136" height="58"><table width="120" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr> 
                <td class="textoGERAL"><strong>Hoje &eacute;:<br>
<?include "data.php";?></strong></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
    <td width="639" height="83" background="img/fnd_topo_branco.jpg"><table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="50" height="55"><img src="img/ico_plug.gif" width="40" height="40"></td>
          <td width="570" colspan="2" class="tituloGERAL">Powered by AGA<font color="#FF9900"><em>Publish 
            </em></font>1.4</td>
        </tr>
        <tr> 
          <td width="50" height="20" class="textoGERAL">&nbsp;</td>
          <td width="500" height="20" class="textoGERAL"><?include "ola.php";?></td>
          <td width="70" class="textoGERAL"><div align="center"><a href="index.php">HOME</a></div></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="136" height="400" align="left" valign="top" background="img/fnd_lateral.jpg"><table width="136" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class="tituloGERAL"><div align="center">Novidades AGA</div></td>
        </tr>
        <tr> 
          <td width="136" height="80" class="textoGERAL"><div align="center">As 
              &uacute;ltimas novidades<br>
              em tecnologia e<br>
              produtos AGA Brasil<br>
              estar&atilde;o bem aqui!<br>
              N&atilde;o perca!</div></td>
        </tr>
        <tr> 
          <td width="136" height="22" class="textoGERAL"><div align="center">Publicidade</div></td>
        </tr>
        <tr>
          <td height="22" class="textoGERAL"><div align="center"></div></td>
        </tr>
      </table></td>
    <td width="639" align="left" valign="top" bgcolor="#FFFFFF"><table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="50" height="55"><img src="img/ico_conteudo.gif" width="40" height="40"></td>
          <td width="570" height="55" class="tituloGERAL">Listando galerias p�blicas cadastradas</td>
        </tr>

        <tr><td></td><td class="textoGERAL">
<?
//Tipo de galeria
$tipogal = "p";

//Quando o usuario clicar confirmar o formulario o
//sistema ira excluir do banco de dados por esse arquivo
//que s� � incluso quando o usuario envia as informa��es
if($_GET['ex'] == "sim"){
include "../fotoz/ctg/excluirctgr.php";
}
?>
		</td></tr>
        <tr> 
          <td width="50">&nbsp;</td>
          <td width="570"><table width="468" border="0" cellspacing="2" cellpadding="0">
              <tr class="textoGERAL">
                <td width="300" height="25" bgcolor="#dddddd"><div align="center"><strong>Galerias(P)</strong></div></td>
                <td height="25" colspan="1" bgcolor="#dddddd"><div align="center"><strong>Op&ccedil;&otilde;es</strong></div></td>
              </tr>

<?

//Antes do nome do cliente, dentro do Loop
$antestb = "<tr class='textoGERAL'><td width='300' height='25' bgcolor='#eeeeee'>";
//Depois do nome do cliente, dentro do Loop
$depoistt = "</td>";
$depoistt2 = "
<td width='100' height='25' bgcolor='#eeeeee'><div align='center'><a href='assoc_galeria_r.php?id=";
$depoisida = "'>Assoc. Cliente</a></div></td>
<td width='100' height='25' bgcolor='#eeeeee'><div align='center'><a href='adicionando_imagens.php?id=";
$depoisidf = "&tpgl=r'>Adic. Foto</a></div></td>";
$depoisidf2 = "<td width='100' height='25' bgcolor='#eeeeee'><div align='center'><a href='lista_galeria_";
$depoiside = "&ex=sim'>Excluir</a></div></td></tr>";
//Depois do Loop dos nomes dos clientes
$depoisloop = "<tr class='textoGERAL'>
<td height='25'>
<a href='adicionando_galeria_p.php'>Adicionar galeria p�blica</a></td>
<td height='25'>&nbsp;</td>
<td height='25'>&nbsp;</td>
</tr>
</table>";
//Exibir quantos registros por pagina?
$registropp = "10";
include "../fotoz/ctg/listctgr.php";
?></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_01.jpg" width="775" height="23"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_02.jpg" width="775" height="16"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_03.jpg" width="775" height="20"></td>
  </tr>
  <tr> 
    <td height="25" colspan="2" class="textoGERAL"><div align="center">AGA Brasil 
        Comunica&ccedil;&atilde;o Interativa. Todos os direitos reservados. Fones: 
        (34) 3223-9884 / 3086-0092.</div></td>
  </tr>
</table>
</body>
</html>
