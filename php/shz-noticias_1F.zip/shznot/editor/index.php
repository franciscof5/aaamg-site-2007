<?
session_start();
//Nivel minimo para acessar essa area
$nivelus = "2";
include "../fotoz/lg/se.php";	
?>
<html>
<head>
<title>AGA Sys - Sistema de Conte&uacute;do Web</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo.css" rel="stylesheet" type="text/css">
<link href="estilo_agasys.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="EFEFEF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="775" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="136"><img src="img/lg_aga.jpg" width="136" height="95"></td>
    <td width="639" background="img/fnd_topo_laranja.jpg" class="tituloGRANDE">http://www.agabrasil.com.br</td>
  </tr>
  <tr> 
    <td width="136" height="83" align="left" valign="top" background="img/fnd_lateral.jpg"><table width="136" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="136" height="25"><img src="img/img_topo_lateral.jpg" width="136" height="25"></td>
        </tr>
        <tr> 
          <td width="136" height="58"><table width="120" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr> 
                <td class="textoGERAL"><strong>Hoje &eacute;:<br>
                  <?include "data.php";?>
                  </strong></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
    <td width="639" height="83" background="img/fnd_topo_branco.jpg"><table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="50" height="55"><img src="img/ico_plug.gif" width="40" height="40"></td>
          <td width="570" colspan="2" class="tituloGERAL">Powered by AGA<font color="#FF9900"><em>Publish 
            </em></font>1.4</td>
        </tr>
        <tr> 
          <td width="50" height="20" class="textoGERAL">&nbsp;</td>
          <td width="500" height="20" class="textoGERAL"><?include "ola.php";?></td>
          <td width="70" class="textoGERAL"><div align="center"></div></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="136" height="400" align="left" valign="top" background="img/fnd_lateral.jpg"><table width="136" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class="tituloGERAL"><div align="center">Novidades AGA</div></td>
        </tr>
        <tr> 
          <td width="136" height="80" class="textoGERAL"><div align="center">As 
              &uacute;ltimas novidades<br>
              em tecnologia e<br>
              produtos AGA Brasil<br>
              estar&atilde;o bem aqui!<br>
              N&atilde;o perca!</div></td>
        </tr>
        <tr> 
          <td width="136" height="22" class="textoGERAL"><div align="center">Publicidade</div></td>
        </tr>
        <tr>
          <td height="22" class="textoGERAL"><div align="center"></div></td>
        </tr>
      </table></td>
    <td width="639" align="left" valign="top" bgcolor="#FFFFFF"><table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="50" height="55"><img src="img/ico_conteudo.gif" width="40" height="40"></td>
          <td width="570" height="55" class="tituloGERAL">Conte&uacute;do do seu 
            site</td>

	  <TD><strong><a href="login.php?erro=1">
	  Sair</a></strong></TD></tr>
        <tr> 
          <td width="50">&nbsp;</td>
          <td width="570"><table width="560" border="0" cellspacing="2" cellpadding="0">

              <tr> 
                <td height="40" colspan="5" class="textoGERAL">Estes s&atilde;o 
                  os m&oacute;dulos de conte&uacute;do do seu site.</td>
              </tr>
              <tr> 
                <td width="60" height="25" bgcolor="#ffffff">&nbsp;</td>
                <td width="280" height="25" bgcolor="#dddddd" class="textoGERAL"><div align="center"><strong>T&iacute;tulo 
                    de menu</strong></div></td>
                <td width="60" height="25" bgcolor="#dddddd" class="textoGERAL"><div align="center"><strong>Tipo</strong></div></td>
                <td height="25" colspan="2" bgcolor="#dddddd" class="textoGERAL"><div align="center"><strong>Op&ccedil;&otilde;es</strong></div></td>
              </tr>
              <?
//Sistema de ARTIGOS
//	Arquivo para onde o link vai apontar
$arquivoex = "editar_conteudo_artigo.php";
$arquivoex2 = "cadastrando_conteudo.php";
//	Coloque aqui o que voc� quer que fique antes do nome cada item
$anteslg = "<tr>
                <td width='22' height='40' bgcolor='#ffffff'>
		<div align='center'><img src='img/mod_artigo.jpg' width='30' height='30'></div></td>
                <td width='260' height='40' bgcolor='#eeeeee' class='textoGERAL'>";
//	Coloque aqui o que voc� quer que fique depois do nome do item
$depoislg = "</td>
                <td width='60' height='40' bgcolor='#eeeeee' class='textoGERAL'><div align='center'>ARTIGO</div></td>
                <td width='60' height='40' bgcolor='#eeeeee' class='textoGERAL'><div align='center'>";
//Aqui voc� coloca uma palavra para servir de bot�o para
//edi��o do conteudo institucional
$textoed = "Editar";
//Aqui voc� coloca o que quer que fique no final do loop
$textoed2 = "</a></div></td>
                <td width='60' height='40' bgcolor='#eeeeee' class='textoGERAL'><div align='center'>";
$textoed3 = "Adicionar";
$fimde = "</div></a></td>
              </tr>";
//	Voc� pode escolher se quer a primeira letra da palavra
//em maiuscula ou a palavra toda em minuscula, se optar por minuscula
//	coloque "min", se optar por tudo maiuscula coloque "mai" e
//se preferir a primeira op��o coloque "pmai".
$maiusculas = "pmai";
//	Aqui vem o include que lista as categorias
include "../fotoz/inst/listcontev.php";

//Conteudo institucional
//	Arquivo para onde o link vai apontar
$arquivox = "edit_conteudo_institucional.php";

//	Coloque aqui o que voc� quer que fique antes do nome cada item
$anteslg = "<tr> 
                <td width='22' height='40' bgcolor='#ffffff'>
		<div align='center'><img src='img/mod_fixo.jpg' width='30' height='30'></div></td>
                <td width='260' height='40' bgcolor='#eeeeee' class='textoGERAL'>";
//	Coloque aqui o que voc� quer que fique depois do nome do item
$depoislg = "</td>
					<td width='60' height='40' bgcolor='#eeeeee' class='textoGERAL'><div align='center'>INSTITUCIONAL</div></td>
                <td width='60' height='40' bgcolor='#eeeeee' class='textoGERAL'><div align='center'>";
//Aqui voc� coloca uma palavra para servir de bot�o para 
//edi��o do conteudo institucional
$textoed = "Editar";
//Aqui voc� coloca o que quer que fique no final do loop
$fimde = "</a></div></td>
                <td width='60' height='40' bgcolor='#eeeeee' class='textoGERAL'><div align='center'></div></td>
              </tr>";
//	Voc� pode escolher se quer a primeira letra da palavra
//em maiuscula ou a palavra toda em minuscula, se optar por minuscula
//	coloque "min", se optar por tudo maiuscula coloque "mai" e
//se preferir a primeira op��o coloque "pmai".
$maiusculas = "pmai";
//	Aqui vem o include que lista as categorias
include "../fotoz/inst/listcont.php";

//LISTA GALERIAS PUBLICAS

//	Arquivo para onde o link vai apontar quando o usuario clicar em $textodc (editar)
$arquivocx = "edit_conteudo_galeria.php";
//	Arquivo para onde o link vai apontar quando o usuario clicar em $adbtct (adicionar)
$arquivocx2 = "adicionando_imagens.php";
//	Coloque aqui o que voc� quer que fique antes do nome cada item
function detecta_ico($tipo="p"){
if($tipo == "r"){
$antescg = "<tr>
                <td width='22' height='40' bgcolor='#ffffff'>
		<div align='center'><img src='img/mod_galeria_r.jpg' width='30' height='30'></div></td>
                <td width='260' height='40' bgcolor='#eeeeee' class='textoGERAL'>";}else{
$antescg = "<tr>
                <td width='22' height='40' bgcolor='#ffffff'>
		<div align='center'><img src='img/mod_galeria.jpg' width='30' height='30'></div></td>
                <td width='260' height='40' bgcolor='#eeeeee' class='textoGERAL'>";		
		}echo $antescg; }
//	Coloque aqui o que voc� quer que fique depois do nome do item
$depoiscg = "</td>
                <td width='60' height='40' bgcolor='#eeeeee' class='textoGERAL'><div align='center'>Galeria(P)";
$depoisdtd = "</div></td>
                <td width='60' height='40' bgcolor='#eeeeee' class='textoGERAL'><div align='center'>";
//Aqui voc� coloca uma palavra para servir de bot�o para
//edi��o do conteudo institucional
$textoedc = "Editar";
//Aqui voc� coloca o que quer que fique depois da palavra acima
$antesadct = "</a></div></td>
                <td width='60' height='40' bgcolor='#eeeeee' class='textoGERAL'><div align='center'>";
//Texto ou imagem para o link que leva a tela de cadastro de novas fotos na galeria
$adbtct = "Adicionar";
//Aqui voc� coloca o que quer que fique no final do loop
$fimdetdc = "</div></td></tr>";
//	Voc� pode escolher qual a forma de exibi��o da lista
//	se � em maiuscula ou minuscula, se optar por minuscula
//	coloque "nao".
$maiusculasc = "nao";
//	Aqui vem o include que lista as categorias
include "../fotoz/ctg/listctg.php";
?>
              
              <tr> 
                <td width="60" height="40" class="borda" bgcolor="#ffffff"><div align="center"></div></td>
                <td width="280" height="40" bgcolor="#eeeeee" class="textoGERAL"><center><b>Modulos</b></center></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><strong><font color="#FFFFFF"></font></strong></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href=""></a></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href=""></a></div></td>
              </tr>
	      
	      <tr> 
                <td width="60" height="40" class="borda"><div align="center"><img src="img/mod_sistemauser.jpg" width="30" height="30"></div></td>
                <td width="280" height="40" bgcolor="#eeeeee" class="textoGERAL">M&oacute;dulo 
                  - CLIENTES</td>
                <td width="60" height="40" bgcolor="#FF9900" class="textoGERAL"><div align="center"><strong><font color="#FFFFFF">M&oacute;dulo</font></strong></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="adicionando_cliente_lista.php">Editar</a></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="adicionando_cliente_novo.php">Adicionar</a></div></td>
              </tr>
              <tr> 
	      
	      

              <tr> 	      
	      
	      
                <td width="60" height="40" class="borda"><div align="center"><img src="img/mod_galeria_r.jpg" width="30" height="30"></div></td>
                <td width="280" height="40" bgcolor="#eeeeee" class="textoGERAL">M&oacute;dulo 
                  - GALERIA (R)</td>
                <td width="60" height="40" bgcolor="#FF9900" class="textoGERAL"><div align="center"><strong><font color="#FFFFFF">M&oacute;dulo</font></strong></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="lista_galeria_r.php">Editar</a></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="adicionando_galeria_r.php">Adicionar</a></div></td>
              </tr>
              <?
if ($nivelusuario == 3){?>
              <tr> 
                <td width="60" height="40" class="borda"><div align="center"><img src="img/mod_galeria.jpg" width="30" height="30"></div></td>
                <td width="280" height="40" bgcolor="#eeeeee" class="textoGERAL">M&oacute;dulo 
                  - GALERIA (P)</td>
                <td width="60" height="40" bgcolor="#FF9900" class="textoGERAL"><div align="center"><strong><font color="#FFFFFF">M&oacute;dulo</font></strong></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="lista_galeria_p.php">Editar</a></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="adicionando_galeria_p.php">Adicionar</a></div></td>
              </tr>
              <tr> 
                <td width="60" height="40" class="borda"><div align="center"><img src="img/mod_fixo.jpg" width="30" height="30"></div></td>
                <td width="280" height="40" bgcolor="#eeeeee" class="textoGERAL">M&oacute;dulo 
                  - INSTITUCIONAL</td>
                <td width="60" height="40" bgcolor="#FF9900" class="textoGERAL"><div align="center"><strong><font color="#FFFFFF">M&oacute;dulo</font></strong></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="lista_cont_inst.php">Editar</a></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="adic_cont_inst.php">Adicionar</a></div></td>
              </tr>
              <tr> 
                <td width="60" height="40" class="borda"><div align="center"><img src="img/mod_artigo.jpg" width="30" height="30"></div></td>
                <td width="280" height="40" bgcolor="#eeeeee" class="textoGERAL">M&oacute;dulo 
                  - ARTIGO</td>
                <td width="60" height="40" bgcolor="#FF9900" class="textoGERAL"><div align="center"><strong><font color="#FFFFFF">M&oacute;dulo</font></strong></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="lista_even_sis.php?refi=eventos">Editar</a></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="adic_even_sis.php">Adicionar</a></div></td>
              </tr>
	      <tr> 
                <td width="60" height="40" class="borda" bgcolor="#ffffff"><div align="center"><img src="img/newsletter.jpg" width="30" height="30"></div></td>
                <td width="280" height="40" bgcolor="#eeeeee" class="textoGERAL">M�dulo - NEWSLETTER</td>
                <td width="60" height="40" bgcolor="#FF9900" class="textoGERAL"><div align="center"><strong><font color="#FFFFFF">M�dulo</font></strong></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="base_admin.php?admin=newsletter">Administrar</a></div></td>
              </tr>
              
<? if($nomec == "shz"){?>
	      <tr> 
                <td width="60" height="40" class="borda" bgcolor="#ffffff"><div align="center"><img src="img/mod_botao.jpg" width="30" height="30"></div></td>
                <td width="280" height="40" bgcolor="#eeeeee" class="textoGERAL">M�dulo-Grupos</td>
                <td width="60" height="40" bgcolor="#FF9900" class="textoGERAL"><div align="center"><strong><font color="#FFFFFF">M�dulo</font></strong></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="lista_grupo.php">Editar</a></div></td>
                <td width="60" height="40" bgcolor="#eeeeee" class="textoGERAL"><div align="center"><a href="adic_grupo.php">Adicionar</a></div></td>
              </tr>
              </tr>
              <?}
}
?>
              <tr> 
                <td height="22" colspan="5">&nbsp;</td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td width="50">&nbsp;</td>
          <td width="570">&nbsp;</td>
        </tr>
        <tr> 
          <td width="50">&nbsp;</td>
          <td width="570">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_01.jpg" width="775" height="23"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_02.jpg" width="775" height="16"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_03.jpg" width="775" height="20"></td>
  </tr>
  <tr> 
    <td height="25" colspan="2" class="textoGERAL"><div align="center">AGA Brasil 
        Comunica&ccedil;&atilde;o Interativa. Todos os direitos reservados. Fones: 
        (34) 3223-9884 / 3086-0092.</div></td>
  </tr>
</table>
</body>
</html>
