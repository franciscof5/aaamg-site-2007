// tinyRTE - Copyright (c)2004  Alfred 'Alf mit i' Scheibl // www.alfmiti.net
// This copyright notice MUST stay intact for use (see license.txt).

// A free tiny Crossbrowser WYSIWYG editor and replacement for <textarea> fields.
// idea and some small code snippets based on Kevin Roth's RTE-Editor
// http://www.kevinroth.com/rte/demo.htm
// $Id: tinyRTE_setup.js,v 1.3 2004/08/22 18:01:11 Alfmiti Exp $

// Browser dedection
var isRichText = false;
var ua = navigator.userAgent.toLowerCase();

// var tinyRTE = new Object();
tinyRTE.isGecko     = (ua.indexOf("gecko") != -1) ;
tinyRTE.isSafari    = (ua.indexOf("safari") != -1);
tinyRTE.isKonqueror = (ua.indexOf("konqueror") != -1);
tinyRTE.haveAllObj  = !tinyRTE.isGecko && document.all ? true : false;
tinyRTE.isIE        = (ua.indexOf("msie") != -1) && (ua.indexOf("opera") == -1) &&
                      (ua.indexOf("webtv") == -1) && !tinyRTE.isGecko && tinyRTE.haveAllObj;

//check to see if designMode mode is available
if (document.getElementById && document.designMode && !tinyRTE.isSafari && !tinyRTE.isKonqueror) {
    isRichText = true;
}

// some special configuration for BLOG:CMS / Nuclues
// ===========================================================================
if (tinyRTE.isIE) window.attachEvent('onload', hideElements);
else window.addEventListener('load', hideElements, true);

function hideElements() {

   if (document.getElementById("submit_btn"))
       document.getElementById("submit_btn").style.display = 'visible';// BLOG:CMS

 	if (document.getElementById("btn_more") && hideBlockMore)
       document.getElementById("btn_more").style.display = 'none';

 	if (document.getElementById("btn_preview"))
       document.getElementById("btn_preview").style.display = 'none';  // hide bookmarklet preview

   if (document.getElementById('inputtitle'))
       document.getElementById('inputtitle').focus(); // move focus to first field
}

// overrule nucleus bookmarklet function - gecko loose always the designmode
function showBlock(id) {
	document.getElementById(id).style.display = "block";
	if (tinyRTE.isGecko && (id == 'body' || id == 'more')) {
	    var rteObj = rteInstance['input' + id];
       rteObj.switchDesignMode('on');
	}

	if (typeof bmActiveBlock != 'undefined') {
	   // is extended bookmarklet -> script make additional settings
	   bmActiveBlock = id;
	   document.getElementById('btn_'+ id).className = 'button_activ';
	}

}


// ============================================================================


// Configuration and Mainfunctions

tinyRTE.config = function() {

  this.version = '0.2 - 22.8.2004';

  this.combobox = new Array();
  this.combobox['fontname'] = {
        "[ Font ]"        : "",
        "Arial"           : "arial,helvetica,sans-serif",
        "Courier New"     : "courier new,courier,monospace",
        "Times New Roman" : "times new roman,times,serif",
        "Verdana"         : "verdana,arial,helvetica,sans-serif"
  };

  this.combobox['fontsize'] = {
        "[ Fontsize ]"  : "",
        "1 (8 pt)"   : "1",
        "2 (10 pt)"  : "2",
        "3 (12 pt)"  : "3",
        "4 (14 pt)"  : "4",
        "5 (18 pt)"  : "5",
        "6 (24 pt)"  : "6",
        "7 (36 pt)"  : "7"
  };

  this.combobox['formatblock'] = {
        "[ Formatblock ]"  : "",
        "Paragraph"  : "p",
        "Heading 1"  : "h1",
        "Heading 2"  : "h2",
        "Heading 3"  : "h3",
        "Heading 4"  : "h4",
        "Heading 5"  : "h5",
        "Heading 6"  : "h6",
        "Formatted"  : "pre",
        "Adress"     : "address",
        "Blockquote" : "blockquote"
  };

  this.combobox['fontstyles'] = {
        "[ Styles ]"  : "",
        "Small"      : "small",
        "Strong"     : "strong",
        "Strike"     : "strikethrough",
        "Subscript"  : "subscript",
        "Superscript": "superscript",
        "Emphasis"   : "em",
        "Citation"   : "cite",
        "Code"       : "code",
        "Sample"     : "samp",
        "Definition" : "dfn"
  };

  this.combobox['linktarget'] = {
        "[ not set ]"    : "",
        "New Window"     : "_blank",
        "Topmost Window" : "_top"
  };

  this.combobox['linkprotocol'] = {
        "http://"    : "http://",
        "https://"   : "https://",
        "ftp://"     : "ftp://",
        "mailto:"    : "mailto:"
  };

  this.palette = [
   [ 'FFFFFF','FFCCCC','FCE6C9','FCFFF0','ADFF2F','F0FFF0','E0FFFF','F0FFFF','E6E6FA','FFF0F5' ],
   [ 'CCCCCC','FF6103','FFDAB9','FFFFCC','7CFC00','BDFCC9','AFEEEE','CCF5FF','CCCCFF','FFCCFF' ],
   [ 'C0C0C0','FF0000','FF9900','FFFF00','32CD32','33FF33','00FFFF','87CEFA','9999FF','FF99FF' ],
	[ '999999','D41A1F','ED9121','FFD700','61B329','33CC00','40E0D0','00BFFF','7B68EE','CC66CC' ],
	[ '666666','D43D1A','E38217','FFCC33','009900','009900','00CED1','1E90FF','6A5ACD','CC33CC' ],
	[ '333333','B0171F','CC6600','CC9833','308014','006600','03A89E','0000FF','333399','91219E' ],
	[ '000000','990033','964514','B8860B','006600','003300','5F9EA0','0000CD','8F5E99','5C246E' ]
   ];

   this.editor_lang  = 'en';
   this.editor_url   = './';
   this.rteSkin      = 'grey';
   this.skinPath     = 'skins/';
   this.minToolbarWidth = 550;
   this.gecko_usecss = 0;
   this.isFullEditor = true;
   this.mediamanager = true;
   this.xhtml_output = true;
   this.xhtml_strict = true;
   this.msie_use_br  = true;
   this.trickDiv     = '<div class="tinyRTE">';
   this.linkIcon     = '';
   this.plugins      = [ 'mediamanager' ];
}


// customize toolbar - [ make // for unused buttons or adjust the button order ]
tinyRTE.prototype.drawToolbar = function (rte,width,isFullEditor) {

  rteWrite('<div id="rteTB_' + rte + '" class="rteToolbar" style="width:' + width + 'px;">');
  rteWrite('<div id="srcSwitch_' + rte + '" class="rteSourceSwitch" onClick="toggleHTMLSrc(\'' + rte + '\')">View Source</div>');
  rteWrite('<table class="rteBtn1" cellpadding="0" cellspacing="0" id="Buttons1_' + rte + '">');
  rteWrite('<tr>');
  if (isFullEditor) {
      rteWrite('<td>');
      rteDrwCombo("formatblock");
      rteDrwCombo("fontstyles");
      rteDrwCombo("fontname");
      rteDrwCombo("fontsize");
      rteWrite('</td><td>');
      rteDrwExtraBtn("forecolor","rteExecExtCmd('" + rte + "','forecolor','')");
      rteDrwExtraBtn("hilitecolor","rteExecExtCmd('" + rte + "','hilitecolor','')");
      rteWrite('</tr></table>');
      rteWrite('<table class="rteBtn2" cellpadding="0" cellspacing="0" id="Buttons2_' + rte + '">');
      rteWrite('<tr>');
  }
  rteDrwExeBtn("bold");
  rteDrwExeBtn("italic");
  rteDrwExeBtn("underline");
  rteDrwSeperator();
  rteDrwExeBtn("justifyleft");
  rteDrwExeBtn("justifycenter");
  rteDrwExeBtn("justifyright");
  rteDrwExeBtn("justifyfull");
  rteDrwSeperator();
  rteDrwExeBtn("insertorderedlist");
  rteDrwExeBtn("insertunorderedlist");
  if (isFullEditor) {
      rteDrwSeperator();
      rteDrwExeBtn("outdent");
      rteDrwExeBtn("indent");
      rteDrwBtn("div_left","surroundHTML('" + rte + "','<div id=leftbox>','</div>')");
      rteDrwBtn("div_right","surroundHTML('" + rte + "','<div id=rightbox>','</div>')");
      rteDrwSeperator();
      rteDrwExeBtn("inserthorizontalrule");
      rteDrwExtraBtn("createlink","rteExecExtCmd('" + rte + "','createlink','')");
      if (tinyRTE.cfg.mediamanager)
           rteDrwExtraBtn("mediamanager","rteAddMedia('" + rte + "')");
      else rteDrwExtraBtn("insertimage","rteAddImage('" + rte + "')");
  }
  rteDrwSeperator();
  rteDrwExeBtn("removeformat");
  rteDrwExeBtn("undo");
  rteDrwExeBtn("redo");
  rteDrwSeperator();
  rteDrwBtn("about","about()");
  rteWrite('</tr></table></div>');
}


// Please don't change anything below this line
// ==============================================

tinyRTE.cfg = new tinyRTE.config();

for (var objCfg in myRTEconfig) {
     tinyRTE.cfg[objCfg] = myRTEconfig[objCfg];
}


var rteCfgDebug = false;
var currentRTE;
var currentCommand;
var cachedRange;
var rteInstance = new Array();
var rteCountEditor = 0;
// global Objects
var rteColorPickerObj;
var rteLinkPopupObj;

//set paths vars
tinyRTE.cfg.skinPath = tinyRTE.cfg.skinPath + tinyRTE.cfg.rteSkin + '/';
tinyRTE.imagesPath   = tinyRTE.cfg.editor_url + tinyRTE.cfg.skinPath;
tinyRTE.includesPath = tinyRTE.cfg.editor_url;

if (isRichText) {
   var rte_jsfile = tinyRTE.isIE ? 'tinyRTE_ie.js' : 'tinyRTE_gecko.js';
   rteWrite('<style type="text/css">@import "' + tinyRTE.includesPath  + tinyRTE.cfg.skinPath + 'tinyRTE.css";</style>');
   rteIncludeScript('tinyRTE.js');
   rteIncludeScript(rte_jsfile);
   rteIncludeScript('lang/' + tinyRTE.cfg.editor_lang + '.js');
   rteLoadPlugins();
}


function rteWrite(str) {
  document.writeln(str);
}

function rteIncludeScript(js_file) {
  document.writeln('<script language="JavaScript" type="text/javascript" src="'+ tinyRTE.includesPath + js_file + '"></script>');
}

// returns a new editor Object
function tinyRTE(textareaID, cssStyleSheet, isFullEditor) {
  rteCountEditor++;
  this.rteID         = textareaID;
  this.cssStyleSheet = cssStyleSheet;
  this.isFullEditor  = isFullEditor;
  this.editMode      = 'wysiwyg';
  this.designMode    = 'off';
  this.rteObj        = null;
  this.contentObj    = null;
  this.objTextarea   = null;
  this.toolbar1      = null;
  this.toolbar2      = null;
}


function rteLoadPlugins() {
   var pluginName;
   if (tinyRTE.cfg.plugins.length > 0) {
       for (var i=0; i < tinyRTE.cfg.plugins.length; i++){
            pluginName = tinyRTE.cfg.plugins[i].toLowerCase();
            rteIncludeScript('tinyRTE_' + pluginName + '.js');
       }
   }
}





