<?
session_start();
//Nivel minimo para acessar essa area
$nivelus = "2";
include "../fotoz/lg/se.php";
?>
<html>
<head>
<title>AGA Sys - Sistema de Conte&uacute;do Web</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo_agasys.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="EFEFEF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="775" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="136"><img src="img/lg_aga.jpg" width="136" height="95"></td>
    <td width="639" background="img/fnd_topo_laranja.jpg" class="tituloGRANDE">http://www.franciscojunior.com.br</td>
  </tr>
  <tr> 
    <td width="136" height="83" align="left" valign="top" background="img/fnd_lateral.jpg"><table width="136" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="136" height="25"><img src="img/img_topo_lateral.jpg" width="136" height="25"></td>
        </tr>
        <tr> 
          <td width="136" height="58"><table width="120" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr> 
                <td class="textoGERAL"><strong>Hoje &eacute;:<br>
<?include "data.php";?></strong></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
    <td width="639" height="83" background="img/fnd_topo_branco.jpg"><table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="50" height="55"><img src="img/ico_plug.gif" width="40" height="40"></td>
          <td width="570" colspan="2" class="tituloGERAL">Powered by AGA<font color="#FF9900"><em>Publish 
            </em></font>1.4</td>
        </tr>
        <tr> 
          <td width="50" height="20" class="textoGERAL">&nbsp;</td>
          <td width="500" height="20" class="textoGERAL"><?include "ola.php";?></td>
          <td width="70" class="textoGERAL"><div align="center"><a href="index.php">HOME</a></div></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="136" height="400" align="left" valign="top" background="img/fnd_lateral.jpg"><table width="136" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td class="tituloGERAL"><div align="center">Novidades AGA</div></td>
        </tr>
        <tr> 
          <td width="136" height="80" class="textoGERAL"><div align="center">As 
              &uacute;ltimas novidades<br>
              em tecnologia e<br>
              produtos AGA Brasil<br>
              estar&atilde;o bem aqui!<br>
              N&atilde;o perca!</div></td>
        </tr>
        <tr> 
          <td width="136" height="22" class="textoGERAL"><div align="center">Publicidade</div></td>
        </tr>
        <tr>
          <td height="22" class="textoGERAL"><div align="center"></div></td>
        </tr>
      </table></td>
    <td width="639" align="left" valign="top" bgcolor="#FFFFFF"><table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="50" height="55"><img src="img/ico_conteudo.gif" width="40" height="40"></td>
          <td width="570" height="55" class="tituloGERAL">Criando galeria: <font color="#006699"><em>RESTRITA
          </em></font></td>
        </tr>

		<tr><td></td><td class="textoGERAL">

<?php
//Tipo de galeria
$tipogal = "p";

//Abilitar foto de capa de galeria? Caso queira deixe em branco, o contrario digite n�o
$capac = "n�o";

//Abilitar data da galeria? Caso queira deixe em branco, o contrario digite n�o
$datac = "n�o";

//Quando o usuario clicar confirmar o formulario o
//sistema ira adicionar no banco de dados por esse arquivo
//que s� � incluso quando o usuario envia as informa��es
if($_GET['ir'] == "sim"){
include "../fotoz/ctg/inserirgal.php";
//Exemplo
if(empty($erro)){
echo '  <textarea cols="65" rows="5">
--==*ATEN��O*==--
***Aqui come�a o script para a pagina de login***
<?
//Coloque aonde o endere�o da pagina onde
//tem a galeria restrita
$destiarq = "http://localhost/testes2/portfolio.php?refl=v";
?>
<form method="post" action="fotoz/lg/md5.php?refl=v&destinosi=<?echo=$destiarq;?>">
<input name="nomec" type="text" value="usu&aacute;rio" size="12"></td>
<input name="senhac" type="password" size="12"></td>
<input name="Submit" value="Entrar"></td>
***Aqui termina o script para a pagina de login***


--==*ATEN��O*==--
***Aqui come�a o script para a pagina que lista galeria restrita***
**Isso voc� coloca na primeira linha da pagina
<?
session_start();
//Nivel minimo para acessar essa area
$nivelus = "0";
if(!empty($_GET[\'refl\'])){
include "fotoz/lg/se.php";
}
?>
**Isso vc coloca onde quizer listar as galerias
<?
//Arquivo para onde o link vai apontar
$arquivox = "portfolio_moda.php";
//Coloque aqui o que voc� quer que fique antes de cada item
$anteslg = "&#8226; ";
//Coloque aqui o que voc� quer que fique depois de cada item
$depoislg = "<br>";
//Voc� pode escolher qual a forma de exibi��o da lista
//se � em maiuscula ou minuscula, se optar por minuscula
//coloque "nao".
$maiusculas = "sim";
//Aqui vem o include que lista as categorias
include "fotoz/lgaleria.php";
?>
***Aqui termina o script para a pagina que lista galeria restrita***


--==*ATEN��O*==--
***Aqui come�a o script para a pagina que exibe galeria***
**Isso voc� coloca na primeira linha da pagina
<?
session_start();
//Nivel minimo para acessar essa area
$nivelus = "0";
if(!empty($_GET[\'refl\'])){
include "fotoz/lg/se.php";
}
?>
**Isso vc coloca onde quizer listar as fotos
<?
//Arquivo para onde o link vai apontar
//nesse caso � recomendavel que mantenha
//o mesmo arquivo, mais caso queira mudar
//n�o esque�a de incluir o arquivo /fotoz/efotos.php.
// Caso o cliente esteja logado ele acessa a segunda o contrario a primeira.
if(empty($_GET[\'refl\'])){
$arquivox = "portfolio_moda.php";
}else{
$arquivox = "area_clientes.php";
}
//Aqui voc� escolhe quantas fotos quer exibir por linha
$qtfot = 4;
//Aqui voc� pode adicionar um atributo para <tr>
$atbtr = "class=textoGERAL";
//Aqui voc� pode adicionar um atributo para <td>
$atbtd = "width=116 height=80";
//Aqui voc� pode adicionar um atributo para <table>
$atbtb = "cellpadding=2 cellspacing=2 border=0 style=text-align: center; width: 100%;";
//Tamanho do thumb
$tthumb = "130";
//Tamanho da borda do thumb
$bdth = "1";
//Cor da borda do thumb
$bdthc = "065486";
//Inclui arquivo que exibe fotos da
//galeria ou uma foto selecionada
include "fotoz/efotos.php";
?>
***Aqui termina o script para a pagina que exibe galeria***
</textarea>';


}
?>
		</td></tr>
        <tr>
          <td width="50">&nbsp;</td>
          <td width="570"><table width="562" border="0" cellspacing="2" cellpadding="0">
              <tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Tipo:</div></td>
                <td width="400" height="30" class="textoGERAL"> <strong>SISTEMA</strong></td>
              </tr>
              <tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Item
                    do menu:</div></td>
                <td height="30" class="textoGERAL"><strong>
                Galerias restritas
                </strong></td>
              </tr>

<?
//Adicionando o arquivo que contem os dados j� cadastrados
//include "../fotoz/fot/institu.php";
//Form com os campos necessarios
echo "<form action='adicionando_galeria_r.php?ir=sim' method='post' enctype='multipart/form-data'>";

<form action='adicionando_galeria_r.php?ir=sim&tipogr=p' method='post' enctype='multipart/form-data'>

echo "<input name='ativagr' type='hidden' value='on'>
      <input name='tipogr' type='hidden' value='r'>";
?>

              <tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Nome:</div></td>
                <td width="400" height="30"><input name="nomegr" type="text" class="textoGERAL" value="<?
if(empty($nomeglr)){
echo $_POST['nomegr'];
}else{
echo"$nomeglr";//nome ja gravado
}


		?>" size="40"></td>
              </tr>
<?php if(empty($datac)){        ?>      
	      <tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Data:</div></td>
                <td width="400" height="30">
		<input name="dia" type="text" class="textoGERAL" value="" size="1">/
		<input name="mes" type="text" class="textoGERAL" value="" size="1">/20
		<input name="ano" type="text" class="textoGERAL" value="" size="1"></td>
              </tr>      <?php }?>
      
              <tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Grupo:</div></td>
                <td width="400" height="30"><select name="grupo" class="textoCAIXA">
		<option value=''>- Sem grupo</option>
		<?php include "../fotoz/grupo/select.php";?>
		</select></td>
              </tr>

<?php if(empty($capac)){?>
              <tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="middle" bgcolor="#dddddd" class="textoGERAL"><div align="right">Imagem:</div></td>
                <td width="400" height="30"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">
                  <input name="afoto" type="FILE" class="botao">
                  </font> </td>
              </tr>
	      <?php }?>

      <tr bgcolor="#eeeeee">
                <td width="152" height="30" align="left" valign="top" bgcolor="#dddddd" class="textoGERAL"><div align="right"></div></td>
                <td width="400" height="30"><input name="Submit2" type="submit" class="botao" value="Criar"></form></td>
              </tr>
              <tr class='textoGERAL'>
<td height='25'>
<a href='lista_galeria_r.php'>Editar galerias restritas</a></td>
<td height='25'>&nbsp;</td>
<td height='25'>&nbsp;</td>
</tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
        <tr> 
          <td width="50">&nbsp;</td>
          <td width="570">&nbsp;</td>
        </tr>
        <tr> 
          <td width="50">&nbsp;</td>
          <td width="570">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_01.jpg" width="775" height="23"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_02.jpg" width="775" height="16"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_03.jpg" width="775" height="20"></td>
  </tr>
  <tr> 
    <td height="25" colspan="2" class="textoGERAL"><div align="center">AGA Brasil 
        Comunica&ccedil;&atilde;o Interativa. Todos os direitos reservados. Fones: 
        (34) 3223-9884 / 3086-0092.</div></td>
  </tr>
</table>
</body>
</html>
