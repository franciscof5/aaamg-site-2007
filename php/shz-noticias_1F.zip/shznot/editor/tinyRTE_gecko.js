// tinyRTE - Copyright (c)2004  Alfred 'Alf mit i' Scheibl // www.alfmiti.net
// This copyright notice MUST stay intact for use (see license.txt).

// Gecko Browser (Firefox/Mozilla) specific code
// $Id: tinyRTE_gecko.js,v 1.2 2004/08/21 17:47:34 Alfmiti Exp $

document.captureEvents(Event.MOUSEOVER | Event.MOUSEOUT | Event.MOUSEDOWN | Event.MOUSEUP);
document.onmouseover = document.onmouseup = rteRaiseButton;
document.onmouseout  = rteNormalButton;
document.onmousedown = rteLowerButton;

function rteRaiseButton(e) {
  if (typeof e.target.className == 'undefined') return;
  var className = e.target.className;
  if (className == 'rteImage' || className == 'rteImageLowered') e.target.className = 'rteImageRaised';
};

function rteNormalButton(e) {
  if (typeof e.target.className == 'undefined') return;
  var className = e.target.className;
  if (className == 'rteImageRaised' || className == 'rteImageLowered') e.target.className = 'rteImage';
};


function rteLowerButton(e) {
  if (typeof e.target.className == 'undefined') return;
  var className = e.target.className;
  if (className == 'rteImage' || className == 'rteImageRaised') e.target.className = 'rteImageLowered';
};

function rteGetElementByTagName(tagName) {
   return document.getElementsByTagName(tagName);
};


tinyRTE.addEventListener = function(eleObj, type, listener, useCature) {
   eleObj.addEventListener(type,listener,useCature);
   return true;
};

// enable one more time the designmode to avoid conflicts with multiple editors
// addEventListener('load', rteEnableDesignmodeAll, true);
tinyRTE.addEventListener(window,'load', rteEnableDesignmodeAll, true);


function rteEnableDesignmodeAll() {
  var rteObj;
  for (var rteId in rteInstance) {
       rteObj = rteInstance[rteId];
       rteObj.switchDesignMode('on');
       // rteObj.executeCmd('useCSS', tinyRTE.cfg.gecko_usecss);
  }
};


function rteSetCurrentEditor(e) {
   var targetElement = e.currentTarget;
   currentRTE = targetElement.name;
};

function rteExecCmd(rte, command, cmdParams) {

  var rteObj = rteInstance[rte];
  currentRTE = rte;
  try {
    rteObj.executeCmd(command,null);
  } catch (e) {
    rteObj.switchDesignMode('on'); // normaly can only failed if designmode is loosed
    if (rteCfgDebug) alert(e);
  }
};


function surroundHTML(rte,startTag,endTag) {

  var rteObj = rteInstance[rte];
  var range = rteObj.getEditorRange();

  var fragment   = rteObj.iFrameObj.document.createDocumentFragment();
  var div 	     = rteObj.iFrameObj.document.createElement( "div" );
  div.innerHTML  = startTag + range + endTag;

  while ( div.firstChild ) {
  	  fragment.appendChild(div.firstChild);
  }
  rteObj.insertNodeAtSelection(fragment);
  rteObj.iFrameObj.focus();
};

//Function to set color
function rteSetColor(color) {

  var rteObj = rteInstance[currentRTE];
  tinyRTE.togglePopup(rteColorPickerObj);
  rteObj.executeCmd(currentCommand, color);
};

tinyRTE.getIframeObject = function(iFrameId) {
  return document.getElementById(iFrameId).contentWindow;
};

tinyRTE.getContentWindow = function(iFrameId) {
  var ref = document.getElementById(iFrameId);
  if (typeof ref.contentDocument != 'undefined') {
     return  ref.contentDocument;
   } else if (typeof ref.contentWindow != 'undefined') {
     return  ref.contentWindow.document;
   }
   return null;
};

tinyRTE.prototype.enableDesignMode = function(rteId) {

  //Gecko may take some time to enable design mode for multiple editors
  function geckoTimeout() {};
  if (rteCountEditor > 1) setTimeout(geckoTimeout,500);

  var designMode = false;

  var frameHtml = this.getIframeHTML();
  var contentObj = tinyRTE.getContentWindow('iFrame_' + this.rteID);
  try {
      contentObj.designMode = "on";
      designMode = true;
      try {
        contentObj.open();
        contentObj.write(frameHtml);
        contentObj.close();
        //attach a handler to make keyboard shortcuts work
        contentObj.addEventListener("keypress", tinyRTE.kb_handler, true);
      } catch (ex) {
        alert("Error preloading content.");
        if (rteCfgDebug) alert(ex);
      }
  } catch (ex) {
      // do nothing here, give gecko a second chance in onloadhandler to enable designmode
      // if failed in onload there something badly wrong - is better then endles loop
  }

  return designMode;
};


tinyRTE.prototype.switchDesignMode = function (mode) {
  try {
    this.contentObj.designMode = mode;
  } catch (e) {
    // if (rteCfgDebug) alert(e);
    var res = this.enableDesignMode(this.rteID);
    if (res)  this.contentObj = tinyRTE.getContentWindow('iFrame_' + this.rteID);
  }
};

tinyRTE.prototype.setHtml = function() {
  return tinyRTE.cfg.trickDiv + this.objTextarea.value + '\n</div>';
}

// getHtml with special convertings for gecko
tinyRTE.prototype.getHtml = function() {

  var trickDiv = tinyRTE.cfg.trickDiv; // '<p style="margin:0pt;">';

  var str = this.contentObj.body.innerHTML;
  str = str.trim();
  if (str.length == 0 || str == '<br>') return '';

  // tag names to lowercase (also xhtml conform) and quote attributes
  str = str.replace(/(<\/|<)\s*([^ \t\n>]+)/ig, function(matchStr, p1, p2) {
  	    return p1 + p2.toLowerCase();
  });
  // str = str.replace(/(\w+=)[*"'](.+?)[*"']/ig,'$1"$2"');

  // check of our real wysiwyg trickdiv and remove
  // is all little tricky while gecko rewrites the tags (whitespaces, linebreaks)
  var dynRegex = new RegExp('^'+ trickDiv.prepareCompare());
  if (dynRegex.test(str.prepareCompare()) == true) {
      // remove trickDiv
      str = str.replace(/^<div([^>]*)>/,'');
      str = str.replace(/<\/div>$/,'');
      str = str.trim();
  }

  // remove ugly gecko codes
  str = str.replace(/ \_moz(.*?)\=\"(.*?)\"/i,'');
  str = str.replace(/ type\=\"\_moz\"/i,'');

  // change gecko span formattings into shorter way - remove empty span
  str = str.replace(/<span style="font-weight: bold;">([^>].*?)<\/span>/igm,'<b>$1</b>');
  if (!tinyRTE.cfg.xhtml_strict) {
     str = str.replace(/<span style="font-style: italic;">([^>].*?)<\/span>/igm,'<i>$1</i>');
     str = str.replace(/<span style="text-decoration: underline;">([^>].*?)<\/span>/igm,'<u>$1</u>');
  }
  str = str.replace(/<(span|font)([^>\/>]*)(><|>[&nbsp;|\s]+<)\/(span|font)>/ig,'');

  // basic convert to xhtml
  if (tinyRTE.cfg.xhtml_output) {
     str = str.replace(/<(br|input|meta|link|img)([^>\/>]*)>/ig,'<$1$2 />');
     str = str.replace(/<(br|input|meta|link|img)([^>]*[^\/])>/,'<$1$2 />');

     str = str.replace(/<a href="([^java].*?)"(.*?)>([^>].*?)<\/a>/,
                       function (matchStr,linkUrl,more,text) {
                          return '<a href="' + encodeHtml(linkUrl)+ '" '+ more +'>'+text+'</a>';
                       });

     str = str.convertFontToSpan();
  }

  // cleanup unnecessary <br/> and selfclosing <p />
  str = str.replace(/<br \/>([\n|\r\n]+)<\/p>/mgi, '</p>');
  str = str.replace(/<br \/><\/p>/mgi, '</p>');
  str = str.replace(/<p\/>/gi, '');

  // Todo encode Textdata

  function encodeHtml(str) {
    // some usefull encondings into HTMLentities
    str = str.replace(/&[^amp]/ig, "&amp;");
    str = str.replace(/\x22/ig, "&quot;");
    str = str.replace(/'/i, "&quot;");
	 str = str.replace(/</ig, "&lt;");
	 str = str.replace(/>/ig, "&gt;");
    return str;
  }

  return str;
};


// strange -- gecko accepts only in this way
tinyRTE.prototype.setTextareaAttribute = function(rteWidth, rteHeight) {
   this.objTextarea.setAttribute('style','width:' + (rteWidth - 2) +'px; height:'+ rteHeight + 'px; display:none;');
};


tinyRTE.prototype.executeCmd = function (cmd, commandValue){
  if (this.contentObj) {
     this.iFrameObj.focus();
     this.contentObj.execCommand(cmd, false, commandValue);
     this.iFrameObj.focus();
  }
};


tinyRTE.prototype.getEditorRange = function() {
  var selection = this.iFrameObj.getSelection();
  return this.createRange(selection);
};

tinyRTE.prototype.createRange = function(selection){
  this.iFrameObj.focus();
  if (selection == 'undefined') return this.contentObj.createRange();
  try {
    return selection.getRangeAt(0);
  } catch(e) {
    return this.contentObj.createRange();
  }
};

tinyRTE.prototype.getEditorRangeText = function() {
  return this.getEditorRange();
};

tinyRTE.prototype.emptyRangeCheck = function(range, i18nKey) {
   if (range == '' || range == null) {
       alert(tinyRTE.I18N[i18nKey]);
       return false;
   }
   return true;
};


// most of the code is taken form mishoos htmlarea
tinyRTE.prototype.insertNodeAtSelection = function( toInserted ) {

  var selection = this.iFrameObj.getSelection();
  var range = this.createRange(selection);

  selection.removeAllRanges();
  range.deleteContents();

  var node 	= range.startContainer;
  var pos 	= range.startOffset;
  var selnode;

  switch (node.nodeType)  {
    case 1: // Element Node
      selnode = toInserted.nodeType == 11 ? toInserted.firstChild : firstChild;
  		node.insertBefore(toInserted, node.childNodes[pos]);
  		break;
    case 3: // Text Node
      if (toInserted.nodeType == 3) {
      	node.insertData(pos, toInserted.data);
      	range = this.createRange();
      	range.setEnd(node, pos + toInserted.length);
      	range.setStart(node, pos + toInserted.length);
      	selection.addRange(range);

      } else {
      	node = node.splitText(pos);
      	selnode = toInserted.nodeType == 11 ? toInserted.firstChild : firstChild;
      	node.parentNode.insertBefore(toInserted, node);
      }
  		break;
  }

};


tinyRTE.kb_handler = function(evt) {

  //contributed by Anti Veeranna (thanks Anti!)
  if (evt.ctrlKey) {
    var key = String.fromCharCode(evt.charCode).toLowerCase();
    var cmd = '';
    switch (key) {
      case 'b': cmd = "bold"; break;
      case 'i': cmd = "italic"; break;
      case 'u': cmd = "underline"; break;
    };

    if (cmd) {
      rteExecCmd(currentRTE, cmd, null);
      // stop the event bubble
      evt.preventDefault();
      evt.stopPropagation();
    }
   }
};
