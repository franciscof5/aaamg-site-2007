<?php
#By Alcione Giovanella
# Modificado por Spychaser

$diasemana[0] = "Domingo";
$diasemana[1] = "Segunda-feira";
$diasemana[2] = "Ter�a-feira";
$diasemana[3] = "Quarta-feira";
$diasemana[4] = "Quinta-feira";
$diasemana[5] = "Sexta-feira";
$diasemana[6] = "S�bado";

$mesnome[1] = "janeiro";
$mesnome[2] = "fevereiro";
$mesnome[3] = "mar�o";
$mesnome[4] = "abril";
$mesnome[5] = "maio";
$mesnome[6] = "junho";
$mesnome[7] = "julho";
$mesnome[8] = "agosto";
$mesnome[9] = "setembro";
$mesnome[10] = "outubro";
$mesnome[11] = "novembro";
$mesnome[12] = "dezembro";

$ano = date('Y');
$mes = date('n');
$dia = date('d');
$diasem = date('w');
$hora=getdate();
//inicio da Modifica��o
if ($hora['minutes']<10)
{
       $hora['minutes']="0".$hora['minutes']  ;
}
// fim da Modifica��o
$horacerta=($hora['hours'].':'.$hora['minutes']);

$data = $dia.' de '.$mesnome[$mes].' de '.$ano.'<br>'.$diasemana[$diasem];
echo($data);
?>
