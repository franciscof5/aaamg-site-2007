<?
session_start();
@session_destroy();
?>
<html>
<head>
<title>AGA Sys - Sistema de Conte&uacute;do Web</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo_agasys.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="EFEFEF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="775" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="136"><a href="http://www.agabrasil.com.br" target="_blank"><img src="img/lg_aga.jpg" width="136" height="95" border="0"></a></td>
    <td width="639" background="img/fnd_topo_laranja.jpg" class="tituloGRANDE">&nbsp;</td>
  </tr>
  <tr> 
    <td width="136" height="83" align="left" valign="top" background="img/fnd_lateral.jpg"><table width="136" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="136" height="25"><img src="img/img_topo_lateral.jpg" width="136" height="25"></td>
        </tr>
        <tr> 
          <td width="136" height="58">&nbsp;</td>
        </tr>
      </table></td>
    <td width="639" height="83" background="img/fnd_topo_branco.jpg"><table width="620" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="50" height="55"><img src="img/ico_plug.gif" width="40" height="40"></td>
          <td width="570" class="tituloGERAL">AGA<font color="#FF9900"><em>Publish 
            </em></font>1.4 - Sistema de Gest&atilde;o para Conte&uacute;do Web</td>
        </tr>
        <tr> 
          <td height="20" colspan="2" class="textoGERAL">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td width="136" align="left" valign="top" background="img/fnd_lateral.jpg">&nbsp;</td>
    <td width="639" align="left" valign="middle" bgcolor="#FFFFFF"><table width="525" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td height="25" colspan="3" class="textoGERAL">&nbsp;</td>
        </tr>
        <tr> 
          <td height="35" colspan="3" class="textoGERAL"> <strong><font color="#FF9900">Entre 
            com seu nome de usu&aacute;rio e senha para acessar o sistema.</font></strong></td>
        </tr><form method='post' action='../fotoz/lg/md5.php'>
        <tr> 
          <td width="60" height="30" class="textoGERAL"><div align="left">Usu&aacute;rio:</div></td>
          <td width="340" height="30"><input name="nomec" type="text" class="textoGERAL" id="user3" size="20"></td>
          <td width="125" height="30">&nbsp;</td>
        </tr>
        <tr> 
          <td width="60" height="30" class="textoGERAL"><div align="left">Senha:</div></td>
          <td width="340" height="30"><input name="senhac" type="password" class="textoGERAL" id="pass2" size="20"></td>
          <td width="125" height="30">&nbsp;</td>
        </tr>
        <tr> 
          <td width="60" height="30">&nbsp;</td>
          <td width="340" height="30"><input name="Submit" type="submit" class="botao" value="Conectar"></td>
          <td width="125" height="30">&nbsp;</td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_01.jpg" width="775" height="23"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_02.jpg" width="775" height="16"></td>
  </tr>
  <tr> 
    <td colspan="2"><img src="img/img_base_03.jpg" width="775" height="20"></td>
  </tr>
  <tr> 
    <td height="25" colspan="2" class="textoGERAL"><div align="center">AGA Brasil 
        Comunica&ccedil;&atilde;o Interativa. Todos os direitos reservados. Fones: 
        (34) 3223-9884 / 3086-0092.</div></td>
  </tr>
</table>
</body>
</html>
