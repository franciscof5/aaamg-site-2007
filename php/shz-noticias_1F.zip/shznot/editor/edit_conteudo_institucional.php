<?
session_start();
//Nivel minimo para acessar essa area
$nivelus = "2";
include "../fotoz/lg/se.php";	
$econfig = "ok";
?>
<html>
<head>


<script type="text/javascript" src="editor/ImageManager/assets/dialog.js"></script>
<script language="session_start();

JavaScript" type="text/javascript">
 var myRTEconfig = { editor_lang : 'en',
                      editor_url  : 'editor/',
                      isFullEditor: true
                    };
 var rteCSSfile = 'france.css';
</script>
<script language="JavaScript" type="text/javascript" src="editor/tinyRTE_setup.js"></script>

<title>AGA Sys - Sistema de Conte&uacute;do Web <?echo $nivelusuario;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo_agasys.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

          <?

//Form com os campos necessarios
echo"<form action='edit_conteudo_institucional.php?ir=sim&id=".$_GET['id']."' method='post'>";
?>


<table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td bgcolor="#FFFFFF"><strong> 
      <?include "inc_topo.php";?>
      </strong></td>
  </tr>
  <tr> 
    <td class="borda-V"><table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td width="75" height="55"><div align="center"><img src="img/ico_plug.gif" width="40" height="40"></div></td>
          <td width="570" colspan="2" class="tituloGERAL">Powered by AGA<font color="#FF9900"><em>Publish 
            </em></font>1.4<strong> </strong></td>
        </tr>
        <tr> 
          <td width="75" height="20" class="textoGERAL">&nbsp;</td>
          <td width="650" height="20" class="textoGERAL"> 
            <?include "ola.php";?>
          </td>
          <td width="50" class="textoGERAL"><div align="center"><a href="index.php">HOME</a></div></td>
        </tr>
        <tr> 
          <td height="20" class="textoGERAL">&nbsp;</td>
          <td height="20" class="textoGERAL"><strong> 
            <?include "data.php";?>
            </strong></td>
          <td class="textoGERAL">&nbsp;</td>
        </tr>
      </table> 
      <table width="750" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr bgcolor="#FFFFFF"> 
          <td width="75" height="55"><div align="center"><img src="img/ico_conteudo.gif" width="40" height="40"></div></td>
          <td width="700" height="55" class="tituloGERAL">Editando conte&uacute;do 
            - 
            <?
//Quando o usuario clicar confirmar o formulario o 
//sistema ira adicionar no banco de dados por esse arquivo
//que s� � incluso quando o usuario envia as informa��es
if($_GET['ir'] == "sim"){
include "../fotoz/fot/inserir.php";
}
//Adicionando o arquivo que contem os dados j� cadastrados
include "../fotoz/fot/institu.php";
?>
          </td>
        </tr>
      </table>
      
    </td>
  </tr>
  <tr> 
    <td class="borda-V"><table width="750" border="0" align="center" cellpadding="0" cellspacing="2">
        <tr> 
          <td width="152" height="30" align="left" valign="middle" class="textoGERAL" bgcolor="#dddddd"><div align="right">Tipo:</div></td>
          <td width="650" height="30" bgcolor="#eeeeee" class="textoGERAL"> <strong>INSTITUCIONAL</strong></td>
        </tr>
        <tr> 
          <td width="152" height="30" align="left" valign="middle" class="textoGERAL" bgcolor="#dddddd"><div align="right">Item 
              do menu:</div></td>

          <td width="650" height="30" bgcolor="#eeeeee" class="textoGERAL"><strong><?echo"$nomem";//nome do conteudo?></strong></td>
        </tr>
        <tr> 
          <td width="152" height="30" align="left" valign="middle" class="textoGERAL" bgcolor="#dddddd"><div align="right">Titulo:</div></td>
          <td width="650" height="30" bgcolor="#eeeeee"><input name="titulo" type="text" class="textoGERAL" value="<?echo"$titulo";//valor de titulo ja gravado?>" size="40"></td>
        </tr>
        <tr align="left"> 
	<td width="152" height="30" align="left" valign="middle" class="textoGERAL" bgcolor="#dddddd"><div align="right">Texto:</div></td>
          <td height="10" colspan="2" valign="top" class="textoGERAL" bgcolor="#eeeeee"> 
 <textarea id="body" name="textoinst" cols="60" rows="20" tabindex="90">
<?
echo $texto;
?>
</textarea>
        <script type="text/javascript">

         var editor1 = new tinyRTE('body', rteCSSfile,true);
         editor1.replaceTextarea(400,300);

        </script>	    
	    
	    <?
//$teste['spaw6'] = "$texto";
//include "../editor/teste.php";
//              <textarea name="texto" cols="80" rows="15" wrap="VIRTUAL" class="textoGERAL">

//echo"$texto";//valor de texto ja gravado
//</textarea>?>
          </td>
        </tr>
        <tr align="center" valign="middle"> 
          <td height="30" colspan="2" class="textoGERAL"><div align="right"></div>
            <div align="center"> 
              <input name="Submit2" type="submit" class="botao" value="Salvar conte&uacute;do">
            </div></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="775" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="750" height="25" align="left" valign="middle" class="borda-V"><div align="center">AGA 
              Brasil Solu&ccedil;&otilde;es. Todos os direitos reservados. Fones: 
              (34) 3223-9884/3086-0092.</div></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>