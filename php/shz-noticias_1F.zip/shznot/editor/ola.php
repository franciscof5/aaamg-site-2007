<?
echo "<strong>Ol� ".strtoupper($dadosc[nome]).", seja bem vindo,</strong> voc&ecirc; est&aacute; logado como administrador do site.</td>"
?>
