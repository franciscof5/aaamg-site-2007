// tinyRTE - Copyright (c)2004  Alfred 'Alf mit i' Scheibl // www.alfmiti.net
// This copyright notice MUST stay intact for use (see license.txt).

// A free tiny Crossbrowser WYSIWYG editor and replacement for <textarea> fields.
// idea and some small snippets based on Kevin Roth's RTE-Editor
// http://www.kevinroth.com/rte/demo.htm
// $Id: tinyRTE.js,v 1.3 2004/08/22 17:36:19 Alfmiti Exp $

// Mainfunctions

tinyRTE.prototype.replaceTextarea = function(rteWidth, rteHeight) {

  if (isRichText) {
      var objTextarea = document.getElementById(this.rteID);
      objTextarea.style.display = "none";
      this.generateEditor(objTextarea, this.rteID, rteWidth, rteHeight);

      var iFrame = document.getElementById('iFrame_' + this.rteID);
      objTextarea.parentNode.removeChild(objTextarea);
      document.getElementById('rteTB_' + this.rteID).appendChild(objTextarea);
      this.setTextareaAttribute(rteWidth, rteHeight);
  }
};

tinyRTE.prototype.generateEditor = function (objTextarea, rte, rteWidth, rteHeight) {

  //adjust minimum table widths
  rteWidth = rteWidth < tinyRTE.cfg.minToolbarWidth ? tinyRTE.cfg.minToolbarWidth : rteWidth;
  var frameWidth = tinyRTE.isIE ? rteWidth - 2 : rteWidth;
  currentRTE = rte;

  this.objTextarea = objTextarea;
  this.objTextarea.className = "rteIframe";

  this.drawToolbar(rte,rteWidth,this.isFullEditor);
  var blankFile = tinyRTE.includesPath + 'blank.html';
  rteWrite('<iframe class="rteIframe" src="' + blankFile + '" id="iFrame_' + rte + '" name="'+ rte + '" width="' + frameWidth + 'px" height="' + rteHeight + 'px" frameborder="0"></iframe>');

  // init extra layer objects
  if (typeof rteColorPickerObj != 'object') rteColorPickerObj = new rteColorPicker();
  if (typeof rteLinkPopupObj != 'object') rteLinkPopupObj = new rteLinkPopup();

  this.enableDesignMode(rte);
  rteInstance[rte] = this.setRteInstance(rte);

  // add a function to update original textareas on submit
  var rteForm = this.objTextarea.form;
  tinyRTE.addEventListener(rteForm, 'submit', rtePrepareSubmit, true);
  tinyRTE.addEventListener(this.iFrameObj,'focus',rteSetCurrentEditor, true);
};


// cache some objects
// FIXME!! rewrite this later for lower memory usage
tinyRTE.prototype.setRteInstance = function(rteId) {
  this.contentObj = tinyRTE.getContentWindow('iFrame_' + rteId);
  this.iFrameObj  = tinyRTE.getIframeObject('iFrame_' + rteId);
  this.srcSwitch  = document.getElementById("srcSwitch_" + rteId);
  this.toolbar1   = document.getElementById("Buttons1_" + rteId);
  if (this.isFullEditor) this.toolbar2   = document.getElementById("Buttons2_" + rteId);
  return this;
};

// some functions to shorten and customezing toolbar drawing
function rteDrwExeBtn(cmd) {
  rteDrwBtn(cmd, "rteExecCmd('" + currentRTE + "','" + cmd + "')");
};

function rteDrwBtn(cmd, function_call) {
  document.write('<td><img class="rteImage" src="' + tinyRTE.imagesPath + 'rte_' + cmd + '.gif' + '" width="20" height="20" '
                 + 'alt="' + tinyRTE.I18N[cmd] + '" title="' + tinyRTE.I18N[cmd] + '" onClick="' + function_call + '"></td>');
};

function rteDrwSeperator() {
  document.write('<td><img class="rteVertSep" src="' + tinyRTE.imagesPath + 'seperator.gif" alt=""></td>');
};

function rteDrwExtraBtn(cmd, function_call) {
  document.write('<td><img id="'+ cmd + '_' + currentRTE + '" class="rteImage" src="' + tinyRTE.imagesPath
                 + 'rte_'+ cmd + '.gif' + '" width="20" height="20" alt="' + tinyRTE.I18N[cmd]
                 + '" title="' + tinyRTE.I18N[cmd] + '" onClick="' + function_call + '"></td>');
};


function rteDrwCombo(id) {
  document.write('<select id="' + id +'_'+ currentRTE + '" class="rteComboBox" onchange="rteExecSelect(\'' + currentRTE + '\', this.id);">');
  for (var listText in tinyRTE.cfg.combobox[id]) {
      document.write('<option value="' + tinyRTE.cfg.combobox[id][listText] + '">' + listText + '</options>');
  }
  document.write('</select>');
};

function rteDrwPopUpCombo(id, prefix) {
  document.write('<select id="rte_' + prefix + id + '" class="rteComboBox">');
  for (var listText in tinyRTE.cfg.combobox[id]) {
      document.write('<option value="' + tinyRTE.cfg.combobox[id][listText] + '">' + listText + '</options>');
  }
  document.write('</select>');
};


function about() {
  alert(tinyRTE.I18N.about_info);
};

tinyRTE.prototype.getIframeHTML = function() {
  var bodyTag;
  var htmlContent = this.setHtml();

  var frameHtml = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"'; // for correct css interpretation
  frameHtml += '"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
  frameHtml += '<html>\n';
  frameHtml += '<head>\n'; // disable caching issues
  frameHtml += '<meta http-equiv="Pragma" content="no-cache" />\n';
  frameHtml += '<meta http-equiv="Cache-Control" content="no-cache, must-revalidate" />\n';
  frameHtml += '<meta http-equiv="Expires" content="-1" />\n';
  //to reference your stylesheet
  if (this.cssStyleSheet.length > 0) {
    frameHtml += '<style type="text/css">@import "' + this.cssStyleSheet + '";</style>\n';
    bodyTag = '<body style="margin:5px;">\n';
  } else {
    bodyTag = '<body style="background-color:#FFF;margin:5px;padding:3px">\n';
  }
  frameHtml += "</head>\n";
  frameHtml += bodyTag + htmlContent + "\n";
  frameHtml += "</body></html>\n";
  return frameHtml;
};


function rtePrepareSubmit() {

  for (var rteId in rteInstance) {
       rteUpdateTextarea(rteId);
  }
  // FIXME!! add little errorhandling
  return true;
};


function rteUpdateTextarea(rteId) {
   var rteObj = rteInstance[rteId];
   if (rteObj.editMode == 'wysiwyg') rteObj.objTextarea.value = rteObj.getHtml();
};


function toggleHTMLSrc(rteId) {

 var htmlSrc;
 var rteObj = rteInstance[rteId];
 var contentObj = rteObj.contentObj;
 var iFrameObj = document.getElementById('iFrame_' + rteId);

 if (rteObj.editMode == 'wysiwyg') {
    rteObj.editMode = 'text';
    rteObj.srcSwitch.className = 'rteSourceSwitchLowered';
    rteObj.srcSwitch.firstChild.nodeValue = 'HTML mode';
    rteObj.toolbar1.style.visibility = "hidden";
    if (rteObj.isFullEditor) rteObj.toolbar2.style.visibility = "hidden";
    rteObj.objTextarea.value = rteObj.getHtml();
    rteObj.switchDesignMode('off');
    iFrameObj.style.display = "none";
    rteObj.objTextarea.style.display = "block";
    rteObj.objTextarea.focus();

  } else {
    rteObj.editMode = 'wysiwyg';
    rteObj.switchDesignMode('on');
    rteObj.srcSwitch.className = 'rteSourceSwitch';
    rteObj.srcSwitch.firstChild.nodeValue = 'View Source';
    rteObj.toolbar1.style.visibility = "visible";
    if (rteObj.isFullEditor) rteObj.toolbar2.style.visibility = "visible";
    contentObj.body.innerHTML = rteObj.setHtml();
    rteObj.objTextarea.style.display = "none";
    iFrameObj.style.display = "block";
    rteObj.switchDesignMode('on'); // refresh one more for mozilla
    iFrameObj.contentWindow.focus();
  }
  currentRTE = rteId;
  rteInstance[rteId] = rteObj;
};


function rteExecSelect(rte, selectname) {

  var rteObj = rteInstance[rte];
  var listObj = document.getElementById(selectname);

  var idx = listObj.selectedIndex;
  // First one is always a label
  if (idx != 0) {
    var selected = listObj.options[idx].value;
    var cmd = selectname.replace('_' + rte, '');
    if (cmd != 'fontstyles') {
        rteObj.executeCmd(cmd, selected);
    } else {
       if (selected == 'strikethrough' || selected == 'subscript' || selected == 'superscript') {
          rteExecCmd(rte, selected, null);
       } else {
          surroundHTML(rte,'<' + selected + '>','</' + selected + '>');
       }
    }
    listObj.selectedIndex = 0;
  }
};


function rteAddImage(rte) {
  var rteObj = rteInstance[rte];

  var imagePath = prompt(tinyRTE.I18N.promptImage, 'http://');
  if ((imagePath != null) && (imagePath != "")) {
      rteObj.executeCmd('insertimage', imagePath);
  }
};


function rteExecExtCmd(rte, command, cmdParams) {

  var rteObj = rteInstance[rte];
  var range = rteObj.getEditorRange();
  currentRTE = rte;
  currentCommand = command;
  if (tinyRTE.haveAllObj) cachedRange = range.duplicate(); // cache for IE -> loose cursorpos

  if (command == "createlink") {
     if (!rteObj.emptyRangeCheck(range, 'empty_link_range')) return;
     tinyRTE.togglePopup(rteLinkPopupObj);
  } else if ((command == "forecolor") || (command == "hilitecolor")) {
     if (!rteObj.emptyRangeCheck(range, 'empty_font_range')) return;
     tinyRTE.togglePopup(rteColorPickerObj);
  }
};

tinyRTE.getAbsolutPosition = function(elementId) {

  var elmObj = document.getElementById(elementId);
  var y = elmObj.offsetLeft;
  var x = elmObj.offsetTop;

  var thereIsParent = elmObj.offsetParent;

  while (thereIsParent)  {
      elmObj = thereIsParent;
      x += elmObj.offsetLeft;
      y += elmObj.offsetTop;
      thereIsParent = elmObj.offsetParent;
  }

  var res = { left: x, top:y };
  return res;
};


function rteDrwPopUpBtn(mode, objId) {
  var function_call = mode == 'ok' ? "rteExecPopup('"+ objId + "')" : "tinyRTE.togglePopup("+objId+"Obj)";
  rteWrite('<div class="rteImage" onClick="' + function_call + '" style="display:inline;padding:1px 8px 1px 8px;">' + tinyRTE.I18N[mode] +'</div>&nbsp;');
};


function rteExecPopup(objId) {
  if (objId == 'rteLinkPopup')  rteInsertLink();
};

function rteInsertLink() {

  var linkUrl = document.getElementById("rte_link").value;

  if (linkUrl > '') {
     tinyRTE.togglePopup(rteLinkPopupObj);
     var listObj1 = document.getElementById('rte_linktarget');
     var target = listObj1.options[listObj1.selectedIndex].value;
     var listObj2 = document.getElementById('rte_linkprotocol');
     var protocol = listObj2.options[listObj2.selectedIndex].value;
     var newLink =  rteBuildLinkString(protocol, linkUrl, target,'');
     if (tinyRTE.cfg.linkIcon > '') newLink += tinyRTE.cfg.linkIcon + ' ';
     surroundHTML(currentRTE,newLink,'</a>');
  }
};

function rteBuildLinkString(protocol, linkUrl, target, title) {
  target = typeof target != 'undefined' && target > '' ? ' target="' + target + '" ' : '';
  title  = typeof title != 'undefined' && title > '' ? title = ' title="' + title + '"' : '';
  var newLink = '<a href="' + protocol + linkUrl +'"'+ target + title + '>';
  return newLink;
};


function rteLinkPopup() {

  rteWrite('<div id="rteLinkPopup">');
  rteWrite('<table cellpadding="2" cellspacing="0" border="0">');
  rteWrite('<caption>Insert new Link</caption><tr><td>');
  rteWrite('Protocol<br />');
  rteDrwPopUpCombo('linkprotocol','');
  rteWrite('</td><td>URL or emailadress<br /><input type="text" id="rte_link" value="" /></td></tr>');
  rteWrite('<tr><td align="right">Target:</td><td>');
  rteDrwPopUpCombo('linktarget','');
  rteWrite('</td></tr><tr><td colspan="2">');
  rteDrwPopUpBtn('ok','rteLinkPopup');
  rteDrwPopUpBtn('cancel','rteLinkPopup');
  rteWrite('</td></tr></table></div>');
  this.divPopup = document.getElementById("rteLinkPopup");
  this.visibility = false;
  this.setFocus = function() {document.getElementById('rte_link').focus(); };
};


tinyRTE.togglePopup = function(popUpObj) {
  var buttonId = currentCommand + '_' + currentRTE;
  var objPos = tinyRTE.getAbsolutPosition(buttonId);
  popUpObj.divPopup.style.left = objPos.left;
  popUpObj.divPopup.style.top =  objPos.top + 25 + "px";
  popUpObj.divPopup.style.visibility = popUpObj.visibility ? 'hidden' : 'visible';
  popUpObj.divPopup.style.display    = popUpObj.visibility ? 'none' : 'block';
  popUpObj.visibility = popUpObj.visibility ? false : true;
  if (popUpObj.visibility)
      popUpObj.divPopup.style.left = (objPos.left - popUpObj.divPopup.offsetWidth + 20) + "px"; // FIXME!! not always correct
  if (popUpObj.visibility) popUpObj.setFocus();
};


// fast Layer Colorpicker
// ==================================================
function rteColorPicker() {

  rteWrite('<div id="colorpicker">');
  rteWrite('<table border="0"><tr><td><div id="show_col"></div></td>');
  rteWrite('<td><input type="text" id="hexvalue" /></td></tr></table>');
  rteWrite('<table border="0" cellspacing="0" cellpadding="0"><tr>');
  this.cpDrawColorPalette(tinyRTE.cfg.palette);
  rteWrite('</tr></table></div>');
  this.divPopup = document.getElementById("colorpicker");
  this.cpInitColorPalette();
  this.visibility = false;
  this.setFocus = function() { };
};


rteColorPicker.prototype.cpDrawColorPalette = function(palette) {

  var colors;
  for (var i=0; i < palette.length;i++){
      if (i > 0) document.write('</tr><tr>');
      colors = palette[i];
      for (var a=0; a < colors.length; a++) {
           document.write('<td id="#'+ colors[a] +'" style="background-color:#'+ colors[a] +';">'
                        + '<div class="cpColorDiv">&nbsp;</div></td>');
      }
  }
};

// eventhandler for colorpicker
rteColorPicker.prototype.cpInitColorPalette = function() {
   var tmpId;
   var x = rteGetElementByTagName('td');
	for (var i=0; i< x.length; i++) {
	    if (typeof x[i].id == 'string') {
	       if (x[i].id.indexOf('#') == 0) {
        		  x[i].onmouseover = rteColorPicker.cpOver;
        		  x[i].onmouseout  = rteColorPicker.cpOut;
        		  x[i].onclick     = rteColorPicker.cpClick;
	       }
        }
	}
};


rteColorPicker.cpOver = function() {
	this.style.border='1px solid #000';
	cpUpdatePreview(this.id);
};

rteColorPicker.cpOut = function() {
	this.style.border='1px solid #FFF';
};

rteColorPicker.cpClick = function() {
   this.style.border='1px solid #FFF';
   cpUpdatePreview(this.id);
 	rteSetColor(this.id);
};

function cpUpdatePreview(color) {
   document.getElementById('show_col').style.backgroundColor = color;
   document.getElementById('hexvalue').value = color;
};

String.prototype.trim = function() {
	return this.replace(/(^\s+|\s+$)/g, '');
};

// for easier HTMLstr compare
// remove linbreaks, spaces quots and makes lowercase
String.prototype.prepareCompare = function() {
  var str = this.toLowerCase();
  str = str.replace(/"/gi,'');
  str = str.replace(/'/gi,'');
  str = str.replace(/\s+/g,'');
  return str;
};

// was a ugly hard work ;-)
String.prototype.convertFontToSpan = function() {

  var htmlStr = this.replace(/<font([^>]*?)>(.*?)<\/font>/ig,
            function(str, attributes, text) {
                 attributes = attributes.replace(/\sstyle="(.*?)"/i,'$1');
                 attributes = attributes.replace(/\sface="(.*?)"/i,' font-family:$1;');
                 attributes = attributes.replace(/\scolor="(.*?)"/i,' color:$1;');
                 attributes = attributes.replace(/\ssize="([0-9+])"/ig,
                       function (str, size) {
                           size = convertToPoints(size);
                           return ' font-size:'+ size +';';
                       });
                 return '<span style="'+ attributes.trim() + '">' + text + '</span>';
            });

  function convertToPoints(font_size) {
      font_size = parseInt(font_size);
      switch (font_size) {
        case 1: return '8pt';
        case 2: return '10pt';
        case 3: return '12pt';
        case 4: return '14pt';
        case 5: return '18pt';
        case 6: return '24pt';
        case 7: return '36pt';
      }
      return '10pt';
  }

  return htmlStr;
};

