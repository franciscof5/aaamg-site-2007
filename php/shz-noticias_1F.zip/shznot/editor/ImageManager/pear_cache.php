<?php

   $CLEAN_CACHE = false;

   if (USE_CACHE) {

       $CACHE_THIS_REQUEST = true;

       if (empty($_GET) && empty($_POST)) $CACHE_THIS_REQUEST = true;

       if ($CACHE_THIS_REQUEST) {
           require_once (dirname(__FILE__).'/Classes/Lite.php');
           $CACHE_ID = $_SERVER['PHP_SELF'];
           foreach ($_GET as $key => $value) {
               $CACHE_ID .= $key.'_'.$value;
           }
       }


       if ($CACHE_THIS_REQUEST) {
            // Set a few options
            $options = array(
                'cacheDir' => dirname($_SERVER["PATH_TRANSLATED"]).'/cache/',
                'lifeTime' => 600,
                'readControl' => false,
                'fileNameProtection' => true
            );

            $cache_lite = new Cache_Lite($options);

            // is there something to clear
            if (@isset($_FILES['upload']) || @isset($_POST['remote_url']) || @isset($_GET['delf']) || @isset($_GET['deld']) || @isset($_GET['newDir'])) {
                $cache_lite->clean();
            }

            if ($data = $cache_lite->get($CACHE_ID, basename($_SERVER['PHP_SELF']))) {
                echo $data;
                die();
            }
       }

       ob_start();
   }



   function writeCache() {
   global $cache_lite, $CACHE_ID;

     if (is_object($cache_lite)) {
         $output = ob_get_contents();
         ob_end_flush();
         $res = $cache_lite->save($output, $CACHE_ID, basename($_SERVER['PHP_SELF']));
     }

   }





?>