<?
$econfig = "yes";
/**
 * Image Manager configuration file.
 * @author Author: Wei Zhuo, Alfmiti
 * @version $Id: config.inc.php,v 1.2 2004/08/21 17:48:00 Alfmiti Exp $
 * @package ImageManager
 */

/*
 * for faster loading - output can be cached
 * cache directory must have write access and chmod 0777
 * 0 = Diasable | 1 = Enable Cache
 */

define("USE_CACHE", 0);
require_once('pear_cache.php');

// SOME Parameter if your Server is running in safe_mode
// ========================================================================
define('FTP_HOST', 'localhost'); // normaly is localhost ok
define('FTP_USER', 'your FTP username');
define('FTP_PASSWORD', 'your FTP password');
define('FTP_HOMEROOT','your root'); // without trailing slash !! -> could be something like /home/www/your unsername
// ========================================================================


/*
 Possible values: 'GD', 'IM', or 'NetPBM'

 The image manipulation library to use, either GD or ImageMagick or NetPBM.
 If you have safe mode ON, or don't have the binaries to other packages,
 your choice is 'GD' only. Other packages require Safe Mode to be off.
*/
define('IMAGE_CLASS', 'GD');


/*
 After defining which library to use, if it is NetPBM or IM, you need to
 specify where the binary for the selected library are. And of course
 your server and PHP must be able to execute them (i.e. safe mode is OFF).
 GD does not require the following definition.
*/
define('IMAGE_TRANSFORM_LIB_PATH', '');


/* ==============  OPTIONAL SETTINGS ============== */

/*
  The prefix for thumbnail files, something like .thumb will do. The
  thumbnails files will be named as "prefix_imagefile.ext", that is,
  prefix + orginal filename.
*/
$IMConfig['thumbnail_prefix'] = '.';

/*
  Thumbnail can also be stored in a directory, this directory
  will be created by PHP. If PHP is in safe mode, this parameter
  is ignored, you can not create directories.

  If you do not want to store thumbnails in a directory, set this
  to false or empty string '';
*/
$IMConfig['thumbnail_dir'] = '.thumbs';

/*
  Possible values: true, false

 TRUE -  Allow the user to create new sub-directories in the
         $IMConfig['base_dir'].

 FALSE - No directory creation.

 NOTE: If $IMConfig['safe_mode'] = true, this parameter
       is ignored, you can not create directories
*/
$IMConfig['allow_new_dir'] = true;

/*
 The default thumbnail if the thumbnails can not be created, either
 due to error or bad image file.
*/
$IMConfig['default_thumbnail'] = 'img/default.gif';


/*
  Thumbnail dimensions.
*/
$IMConfig['thumbnail_width'] = 96;
$IMConfig['thumbnail_height'] = 96;

/*
  Image Editor temporary filename prefix.
*/
$IMConfig['tmp_prefix'] = '.editor_';

/*
 *  DON'T CHANGE ANYTHING BELOW THIS LINE
 *  most of the params are autodedected or stay only for compatibily reasons intact
 */

// Dont change this !!! only for compatibily with the script
// in future version this will removed while we can dedect safe_mode
$IMConfig['safe_mode'] = false;

// Not needed while we have also a fileview
$IMConfig['validate_images'] = true;

// Currently not checked - dialogbox must rewriten
$IMConfig['allow_upload'] = true;


/*
 The URL to the above path, the web browser needs to be able to see it.
 It can be protected via .htaccess on apache or directory permissions on IIS,
 check you web server documentation for futher information on directory protection
 If this directory needs to be publicly accessiable, remove scripting capabilities
 for this directory (i.e. disable PHP, Perl, CGI). We only want to store assets
 in this directory and its subdirectories.
*/

// some changes to work fine with nucleus
include('../../config.php');

$IMConfig['base_dir'] = getenv("DOCUMENT_ROOT").$caminho.'editor/img/';

$pos_nuclues_dir = strpos($_SERVER['REQUEST_URI'],'editor');
//$IMConfig['base_url'] = substr($_SERVER['REQUEST_URI'],0, $pos_nuclues_dir).'ImageManager/img/';

$IMConfig['base_url'] = 'http://'.$esite.'/editor/img/';
//echo $pos_nuclues_dir;



?>
