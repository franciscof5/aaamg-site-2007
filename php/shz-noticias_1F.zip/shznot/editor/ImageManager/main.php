<?php
/***********************************************************************
** Title.........:    Insert File Dialog, File Manager
** Version.......:    1.01
** Authors.......:    Al Rashid <alrashid@klokan.sk>
**                    Xiang Wei ZHUO <wei@zhuo.org>
** Filename......:    main.php
** URL...........:    http://alrashid.klokan.sk/insFile/
** Last changed..:    7 Jan 2004
***********************************************************************/
session_start();
// if (empty($_REQUEST['dialogname'])) die('Dialog Name missing!');
// $MY_NAME = $_REQUEST['dialogname'];
$MY_NAME = 'mediamanager';
if (!(isset($_SESSION[$MY_NAME])) || !(is_array($_SESSION[$MY_NAME]))) die ('Session not set!');
if (!isset($_SESSION[$MY_NAME])) die ('Document Root not set!');
$MY_DOCUMENT_ROOT = $_SESSION[$MY_NAME]['DocumentRoot'];
(isset($_SESSION[$MY_NAME]['BaseUrl'])) 		? $MY_BASE_URL 			= $_SESSION[$MY_NAME]['BaseUrl'] 			: $MY_BASE_URL 			= '';
(isset($_SESSION[$MY_NAME]['AllowExtensions'])) ? $MY_ALLOW_EXTENSIONS	= $_SESSION[$MY_NAME]['AllowExtensions'] 	: $MY_ALLOW_EXTENSIONS 	= null;
(isset($_SESSION[$MY_NAME]['DenyExtensions'])) 	? $MY_DENY_EXTENSIONS	= $_SESSION[$MY_NAME]['DenyExtensions']  	: $MY_DENY_EXTENSIONS	= array('php', 'php3', 'php4', 'phtml', 'shtml', 'cgi');
(isset($_SESSION[$MY_NAME]['ListExtensions'])) 	? $MY_LIST_EXTENSIONS	= $_SESSION[$MY_NAME]['ListExtensions']  	: $MY_LIST_EXTENSIONS	= null;
(isset($_SESSION[$MY_NAME]['AllowDeleteFile'])) ? $MY_ALLOW_DELETE_FILE = $_SESSION[$MY_NAME]['AllowDeleteFile'] 	: $MY_ALLOW_DELETE_FILE = true;
(isset($_SESSION[$MY_NAME]['AllowUploadFile'])) ? $MY_ALLOW_UPLOAD_FILE = $_SESSION[$MY_NAME]['AllowUploadFile']    : $MY_ALLOW_UPLOAD_FILE = true;
(isset($_SESSION[$MY_NAME]['UrlToOpenFile'])) 	? $MY_URL_TO_OPEN_FILE	= $_SESSION[$MY_NAME]['UrlToOpenFile']	 	: $MY_URL_TO_OPEN_FILE 	= false;
(isset($_SESSION[$MY_NAME]['MaxFileSize'])) 	? $MY_MAX_FILE_SIZE 	= $_SESSION[$MY_NAME]['MaxFileSize']		: $MY_MAX_FILE_SIZE 	= 0;
(isset($_SESSION[$MY_NAME]['AllowDeleteFolder'])) ? $MY_ALLOW_DELETE_FOLDER = $_SESSION[$MY_NAME]['AllowDeleteFolder'] : $MY_ALLOW_DELETE_FOLDER 	= true;
(isset($_SESSION[$MY_NAME]['AllowCreateFolder'])) ? $MY_ALLOW_CREATE_FOLDER = $_SESSION[$MY_NAME]['AllowCreateFolder'] : $MY_ALLOW_CREATE_FOLDER 	= true;
(isset($_SESSION[$MY_NAME]['Lang'])) 			? $MY_LANG 				= $_SESSION[$MY_NAME]['Lang']	  			: $MY_LANG 				= 'en';
(isset($_SESSION[$MY_NAME]['DateTimeFormat']))	? $MY_DATETIME_FORMAT	= $_SESSION[$MY_NAME]['DateTimeFormat']	  	: $MY_DATETIME_FORMAT	= "d.m.Y H:i";
$lang_file = 'lang/lang-'.$MY_LANG.'.php';
if (is_file('lang/lang-'.$MY_LANG.'.php')) {
	require($lang_file);
} else {
	require('lang/lang-en.php');
}
$MY_PATH = '/';
$MY_UP_PATH = '/';


