<?
/**
 * The main GUI for the ImageManager.
 * @author Author: Wei Zhuo
 * @version $Id: manager.php,v 1.1.1.1 2004/08/20 20:03:58 Alfmiti Exp $
 * @package ImageManager
 */
    include "idiomas/pt_br.php";
	require_once('config.inc.php');
	require_once('Classes/ImageManager.php');

	$manager = new ImageManager($IMConfig);
	$dirs = $manager->getDirs();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
	<title><?php echo$l_insere_img;?></title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <link href="assets/manager.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="assets/popup.js"></script>
<script type="text/javascript" src="assets/dialog.js"></script>
<script type="text/javascript">
/*<![CDATA[*/
	window.resizeTo(580, 575);

	if(window.opener)
		var I18N = window.opener.ImageManager.I18N;

	var thumbdir = "<? echo $IMConfig['thumbnail_dir']; ?>";
	var base_url = "<? echo $manager->getBaseURL(); ?>";
/*]]>*/
</script>
<script type="text/javascript" src="assets/manager.js"></script>
</head>
<body>
<div class="title"><?php echo$l_insere_img;?></div>
<form action="images.php" id="uploadForm" method="post" enctype="multipart/form-data">
<input type="hidden" id="orginal_width" />
<input type="hidden" id="orginal_height" />
<fieldset>
<div class="dirs">
	<label for="dirPath"><?php echo$l_diretorio;?></label>
	<select name="dir" class="dirWidth" id="dirPath" onchange="updateDir(this)" style="width:350px">
	<option value="/">/</option>
<? foreach($dirs as $relative=>$fullpath) { ?>
		<option value="<? echo rawurlencode($relative); ?>"><? echo $relative; ?></option>
<? } ?>
	</select>
	<a href="#" onclick="javascript: goUpDir();" title="<?php echo$l_subirn;?>"><img src="img/btnFolderUp.gif" height="15" width="15" alt="<?php echo$l_subirn;?>" /></a>
<? if($IMConfig['safe_mode'] == false && $IMConfig['allow_new_dir']) { ?>
	<a href="#" onclick="newFolder();" title="<?php echo$l_nova_pasta;?>"><img src="img/btnFolderNew.gif" height="15" width="15" alt="<?php echo$l_nova_pasta;?>" /></a>
<? } ?>
   <a href="#" onclick="switchView('images')" title="<?php echo$l_miniaturas;?>"><img src="img/btn_thumbview.gif" height="15" width="15" alt="<?php echo$l_miniaturas;?>" /></a>
	 <a href="#" onclick="switchView('fileview');" title="<?php echo$l_listad;?>"><img src="img/btn_detailview.gif" height="15" width="15" alt="<?php echo$l_listad;?>" /></a>
	<div id="messages" style="display: none;"><span id="message"></span><img SRC="img/dots.gif" width="22" height="12" alt="..." /></div>
	<iframe src="fileview.php" name="imgManager" id="imgManager" class="imageFrame" scrolling="auto" title="Image Selection" frameborder="0"></iframe>
   <b><?php formata($l_modo_corrente);?>:</b>
<input type="radio" id="inline_mode" name="iframe_mode" value="inline" onChange="toggleMode(this)" checked="checked"/>
<label for="inline_mode" style="cursor:pointer;"><?php formata($l_inserir_arq_int);?></label>
<input type="radio" id="link_mode" name="iframe_mode" value="link" onChange="toggleMode(this)" />
<label for="link_mode" style="cursor:pointer;"><?php formata($l_inserir_arq_ext);?></label>
<hr />
   <table cellspacing="0" cellpadding="2" border="0" align="left">
     <tr><td></td>
       <td><?php formata($l_env_img_pc);?><input type="file" name="upload" id="upload" size="40" /></td>

     </tr>
     <tr>
       <td><?php formata($l_env_img_net);?> </td>
       <td><input type="text" name="remote_url" id="remote_url" size="65"/></td>
       <td><button type="submit" name="submit" onclick="doUpload();"/><?php echo$l_env_img;?></button></td>
     </tr>
   </table>
</div>
</fieldset>
<!-- image properties -->
<fieldset id="inline_prop" class="fieldsetHigh"><?php formata($l_insere_img);?>
	<table class="inputTable" border="0" align="left">
		<tr>
			<td align="right"><label for="f_url"><?formata($l_inserir_arq);?></label></td>
			<td><input type="text" id="f_url" class="largelWidth" value="" /></td>
			<td align="right"><label for="f_width"><?formata($l_largura_img);?></label></td>
			<td><input type="text" id="f_width" class="smallWidth" value="" onchange="javascript:checkConstrains('width');"/></td>
			<td rowspan="2" align="right"><img src="img/locked.gif" id="imgLock" width="25" height="32" alt="<?echo$l_titulo_img;?>" /></td>
			<td align="right"><label for="f_vert"><?formata($l_espacov_img);?></label></td>
			<td><input type="text" id="f_vert" class="smallWidth" value="" /></td>
		</tr>
		<tr>
			<td align="right"><label for="f_alt"><?formata($l_titulo_img);?></label></td>
			<td><input type="text" id="f_alt" class="largelWidth" value="" /></td>
			<td align="right"><label for="f_height"><?formata($l_altura_img);?></label></td>
			<td><input type="text" id="f_height" class="smallWidth" value="" onchange="javascript:checkConstrains('height');"/></td>
			<td align="right"><label for="f_horiz"><?formata($l_espacoh_img);?></label></td>
			<td><input type="text" id="f_horiz" class="smallWidth" value="" /></td>
		</tr>
		<tr>
			<td align="right"><label for="f_borderwidth"><?formata($l_borda_img);?></label>
			<td><input type="text" id="f_borderwidth" class="smallWidth" style="width:20px" value="" /> <?formata($l_pixel);?> &nbsp;
			    <label for="f_bordercolor"><?formata($l_borda_cor_img);?> </label>
			    <input type="text" id="f_bordercolor" class="smallWidth" style="width:60px;" value="" />
			    <button type="button" id="cpBtn" class="buttons" onclick="return mmCP.togglePopup();"><?echo$l_listacores;?></button>
			</td>
			<td colspan="3">
			  <input type="checkbox" id="constrain_prop" checked="checked" onclick="javascript:toggleConstrains(this);" />
			  <label for="constrain_prop"><?formata($l_proporcional_img);?> </label>
			</td>
			<td align="right"><label for="f_align"><?formata($l_alinha_img);?></label></td>
			<td><select size="1" id="f_align"  title="Positioning of this image">
				  <option value="" selected="selected"><?echo$l_alinha_nao_img;?></option>
				  <option value="left"><?echo$l_alinha_esquerda_img;?></option>
				  <option value="right"><?echo$l_alinha_direita_img;?></option>
				  <option value="top"><?echo$l_alinha_top_img;?></option>
				  <option value="middle"><?echo$l_alinha_middle_img;?></option>
				  <option value="base"><?echo$l_alinha_base_img;?></option>
				  <option value="bottom"><?echo$l_alinha_bottom_img;?></option>
				</select>
			</td>
      </tr>
	</table>
</fieldset>
<fieldset id="link_prop" class="fieldsetLow"><legend><?formata($l_link_img);?></legend>
	<table class="inputTable" border="0" align="left">
		<tr>
   <td align="left"><?formata($l_link_url);?></td>
			<td><input type="text" id="f_link_url" size='40' value=""></td>
			       	<td align="left"><label for="f_link_alt"><?formata($l_link_titulo);?></label></td>
			<td><input type="text" id="f_link_alt" size='15' value=""></td>
			<td align="left"><label for="f_target"><?formata($l_link_abrir);?></label></td>
			<td><select size="1" id="f_link_target"  title="Define target for media">
              <option value=""><?echo$l_link_abrir_msm;?></option>
              <option value="_blank"><?echo$l_link_abrir_nova;?></option>
              <option value="_top"><?echo$l_link_abrir_top;?></option>
              <option value="js"><?echo$l_link_abrir_js;?></option>
            </select>
            <input type="hidden" id="f_link_file" />
            <input type="hidden" id="f_link_width" />
            <input type="hidden" id="f_link_height" />
            <input type="hidden" id="orginal_link_width" />
            <input type="hidden" id="orginal_link_height" />
         </td>
      </tr>
    </table>
</fieldset>

<!--// image properties -->
	<div style="text-align: right;">
	     <button type="button" class="buttons" onclick="return clearInput();"><?echo$l_bot_limp;?></button>&nbsp;&nbsp;
		  <button type="button" class="buttons" onclick="return refresh();"><?echo$l_bot_atu;?></button>&nbsp;&nbsp;
        <button type="button" class="buttons" onclick="return onOK();"><?echo$l_bot_ok;?></button>
        <button type="button" class="buttons" onclick="return onCancel();"><?echo$l_bot_canc;?></button>
    </div>
	<input type="hidden" id="f_file" name="f_file" />
</form>
<script type="text/javascript">
/*<![CDATA[*/
  var mmCP = new rteColorPicker();
/*]]>*/
</script>
</body>
</html>
<?php writeCache(); ?>
