<?
/**
 * Show a list of files
 * @author $Author: Alfmiti $
 * @version $Id: fileview.php,v 1.1.1.1 2004/08/20 20:03:58 Alfmiti Exp $
 * @package ImageManager
 */

require_once('config.inc.php');
require_once('Classes/ImageManager.php');

//default path is /
$relative = '/';
$IMConfig['validate_images'] = false;
$manager = new ImageManager($IMConfig);

//process any file uploads
$manager->processRemote();
$manager->processUploads();

$manager->deleteFiles();

$refreshDir = false;
//process any directory functions
if($manager->deleteDirs() || $manager->processNewDir())
	$refreshDir = true;

//check for any sub-directory request
//check that the requested sub-directory exists
//and valid
if(isset($_REQUEST['dir']))
{
	$path = rawurldecode($_REQUEST['dir']);
	if($manager->validRelativePath($path))
		$relative = $path;
}


$manager = new ImageManager($IMConfig);


//get the list of files and directories
$list = $manager->getFiles($relative);


/* ================= OUTPUT/DRAW FUNCTIONS ======================= */

/**
 * Draw the files in an table.
 */

function drawParentDir($list, &$manager) {
	global $relative;

	$rel_path = rawurlencode($file['relative']);
	$folder_link = '<a href="fileview.php?dir='.$rel_path.'" onclick="updateDir(\''.$rel_path.'\')" title="Up">';
   $tbl_files = '<tr>'.
   '<td>'.$folder_link.'<img src="img/ext/folder_small.gif" width="16" height="16" border=0 alt="'.$dir['entry'].'" /></a></td>'.
   '<td>'.$folder_link.'<img src="img/dots.gif" width="22" height="12" border="0"></a></td>'.
   '<td colspan="3">&nbsp;</td></tr>';
   echo $tbl_files;
}

// $t_files .= '<a href="'.$MY_URL_TO_OPEN_FILE.$relativePath.'" target="_new"><img src="images/edit_active.gif" width="15" height="15" border="0"></a>';

function drawFiles($list, &$manager)
{
	global $relative; //echo '<pre>';print_r($list);

	foreach($list as $entry => $file)
	{
	   $ext = substr(strrchr($entry, '.'), 1);
	   $rel_path = rawurlencode($file['relative']);
	   $file_size = Files::formatSize($file['stat']['size']);
	   
         $edit_link = '<img src="img/blank.png" height="15" width="15" alt="blank"/>';
      

      $img_width  = @isset($file['image'][0]) ? $file['image'][0] : 0;
      $img_height = @isset($file['image'][1]) ? $file['image'][1] : 0;

	   $tbl_files = '<tr>'.
      '<td><img src="img/ext/'.parse_icon($ext).'" width="16" height="16" border=0 alt="&nbsp;" /></td>'.
      '<td><div style="width:200px; overflow:hidden;"><a href="javascript:selectImage(\''.$file['relative'].'\',\''.$entry.'\','.$file['image'][0].','.$file['image'][1].');" title="'.$entry.' - '.$file_size.'">'.
           $entry.'</a></div></td>'.
      '<td>'.$file_size.'</td>'.
      '<td>'.parse_time($file['stat']['mtime']).'</td>'.
      '<td>'.
         '<a href="fileview.php?dir='.$relative.'&amp;delf='.$rel_path.'" title="Lixo" onclick="return confirmDeleteFile(\''.$entry.'\');"><img src="img/edit_trash.gif" height="15" width="15" alt="Lixo"/></a>'.
         $edit_link.'<a href="javascript:previewMedia(\''.$file['url'].'\','.$img_width.','.$img_height.');"><img src="img/edit_active.gif" width="15" height="15" border="0" hspace="3" alt="Ver"/></a>'.
      '</td></tr>';
      echo $tbl_files;
   }

}//function drawFiles


/**
 * Draw the directory.
 */
function drawDirs($list, &$manager)
{
	global $relative;

	foreach($list as $path => $dir)	{

	   $folder_link = '<a href="fileview.php?dir='.rawurlencode($path).'" onclick="updateDir(\''.$path.'\')" title="Open Directory">';
      $tbl_files = '<tr>'.
      '<td>'.$folder_link.'<img src="img/ext/folder_small.gif" width="16" height="16" border=0 alt="'.$dir['entry'].'" /></a></td>'.
      '<td><div style="width:200px; overflow:hidden;">'.$folder_link.$dir['entry'].'</a>'.
      '<td colspan="2">&nbsp;</td>'.
      '<td>'.
         '<a href="fileview.php?dir='.$relative.'&amp;deld='.rawurlencode($path).'" title="Lixo" onclick="return confirmDeleteDir(\''.$dir['entry'].'\','.$dir['count'].');"><img src="img/edit_trash.gif" height="15" width="15" alt="Lixo"/></a>'.
      '</td></tr>';
      echo $tbl_files;
   }

}//function drawDirs


/**
 * No directories and no files.
 */
function drawNoResults()
{
?>
  <tr>
    <td colspan="4" class="noResult">ARQUIVOS N�O ENCONTRADOS</td>
  </tr>
<?
}

/**
 * No directories and no files.
 */
function drawErrorBase(&$manager)
{
?>
<table width="100%">
  <tr>
    <td class="error">Invalid base directory: <? echo $manager->config['base_dir']; ?></td>
  </tr>
</table>
<?
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
	<title>Lista de imagens</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="assets/imagelist.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="assets/dialog.js"></script>
<script type="text/javascript">
/*<![CDATA[*/

	if(window.top)
		var I18N = window.top.I18N;

	function hideMessage()
	{
		var topDoc = window.top.document;
		var messages = topDoc.getElementById('messages');
		if(messages)
			messages.style.display = "none";
	}

	function init()
	{
		hideMessage();
		var topDoc = window.top.document;
<?php
    if (@isset($_FILES['upload']) || @isset($_POST['remote_url'])) {
?>
     	topDoc.getElementById('remote_url').value = '';
		topDoc.getElementById('upload').value = '';
<?php
    }

	//we need to refesh the drop directory list
	//save the current dir, delete all select options
	//add the new list, re-select the saved dir.
	if($refreshDir)
	{
		$dirs = $manager->getDirs();
?>
		var selection = topDoc.getElementById('dirPath');
		var currentDir = selection.options[selection.selectedIndex].text;

		while(selection.length > 0)
		{	selection.remove(0); }

		selection.options[selection.length] = new Option("/","<? echo rawurlencode('/'); ?>");
		<? foreach($dirs as $relative=>$fullpath) { ?>
		selection.options[selection.length] = new Option("<? echo $relative; ?>","<? echo rawurlencode($relative); ?>");
		<? } ?>

		for(var i = 0; i < selection.length; i++)
		{
			var thisDir = selection.options[i].text;
			if(thisDir == currentDir)
			{
				selection.selectedIndex = i;
				break;
			}
		}
<? } ?>
	}

/*]]>*/
</script>
<script type="text/javascript" src="assets/images.js"></script>
</head>
<body>
  <table id="filetable" cellspacing="0" width="100%">
	<thead>
		<tr>
			<td width="15px">T.</td>
			<td width="200px">Nome</td>
			<td width="130px">Tamanho</td>
			<td width="100px">Data modif.</td>
			<td width="55px"> &nbsp;</td>
		</tr>
	</thead>
	<tbody>
<? if ($manager->isValidBase() == false) { drawErrorBase($manager); }
	elseif(count($list[0]) > 0 || count($list[1]) > 0) { ?>
<?php
	drawParentDir($list[0], $manager);
	drawDirs($list[0], $manager);
	drawFiles($list[1], $manager);
?>
<? } else {
    drawParentDir($list[0], $manager);
    drawNoResults(); }
?>
	</tbody>
</table>
</body>
</html>
<?php

writeCache();

// Filemanger Helperfunctions

function parse_size($size) {
	if($size < 1024)
		return $size.' bytes';
	else if($size >= 1024 && $size < 1024*1024) {
		return sprintf('%01.2f',$size/1024.0).' KB';
	} else {
		return sprintf('%01.2f',$size/(1024.0*1024)).' MB';
	}
}

function parse_time($timestamp) {
	return date("d.m.Y H:i",$timestamp);
}

function parse_icon($ext) {
	switch (strtolower($ext)) {
		case 'doc':  return 'doc_small.gif';
		case 'xls':  return 'xls_small.gif';
		case 'ppt':  return 'ppt_small.gif';
		case 'pdf':  return 'pdf_small.gif';
		case 'rar':  return 'rar_small.gif';
		case 'zip':  return 'zip_small.gif';
		case 'gz':   return 'gz_small.gif';
		case 'txt':  return 'txt_small.gif';
		case 'xml':  return 'xml_small.gif';
		case 'htm':
		case 'html':
		  return 'html_small.gif';
		case 'jpg':
		case 'jpeg':
		case 'gif':
		case 'png':
		   return 'img_small.gif';
  		default:
		    return 'def_small.gif';
	}
}

