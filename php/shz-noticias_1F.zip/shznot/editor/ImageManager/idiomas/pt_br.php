<?php
//Formata��o
function formata($ftexto){
$font = "<font size=1>$ftexto</font>";
echo $font;
}

//Titulos e destaques
$l_insere_img = "Inserir imagens";
$l_env_img = "Enviar";

//Gerenciador de imagens
$l_diretorio = "Diretorio";

//Alt para imagens do gerenciador de imagens
$l_subirn = "Subir nivel";
$l_nova_pasta = "Nova pasta";
$l_miniaturas = "Miniaturas";
$l_listad = "Lista Detalhada";
$l_modo_corrente = "Modo Corrente";
$l_inserir_arq_int = "Inserir arquivo interno";
$l_inserir_arq_ext = "Inserir arquivo externo";
$l_env_img_pc = "Imagem do seu PC";
$l_env_img_net = "URL";

//Campo para inserir imagens
$l_inserir_arq = "Arquivo";
$l_titulo_img = "Titulo";
$l_altura_img = "Altura";
$l_largura_img = "Largura";
$l_proporcional_img = "T. Proporcional";
$l_espacov_img = "Espaco V.";
$l_espacoh_img = "Espaco H.";
$l_borda_img = "Borda";
$l_borda_cor_img = "Cor borda";
$l_listacores = "Cores";
$l_alinha_img = "Alinhar";
$l_alinha_nao_img = "Nao";
$l_alinha_direita_img = "Direita";
$l_alinha_esquerda_img = "Esquerda";
$l_alinha_top_img = "Top";
$l_alinha_middle_img = "Middle";
$l_alinha_base_img = "Base";
$l_alinha_bottom_img = "Bottom";
$l_pixel = "px";

//Campo de URL para imagem
$l_link_img = "Link para imagem";
$l_link_url = "URL";
$l_link_abrir = "Em";
$l_link_abrir_msm = "Mesma janela";
$l_link_abrir_nova = "Nova Janela";
$l_link_abrir_top = "Topmost window";
$l_link_abrir_js = "PopUp JavaScript";
$l_link_titulo = "Titulo";

//Bot�es
$l_bot_limp = "Limpar";
$l_bot_atu = "Atualizar";
$l_bot_ok = "OK";
$l_bot_canc = "Cancelar";
?>
