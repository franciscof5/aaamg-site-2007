// htmlArea v3.0 - Copyright (c) 2002, 2003 interactivetools.com, inc.
// This copyright notice MUST stay intact for use (see license.txt).
//
// Portions (c) dynarch.com, 2003
//
// A free WYSIWYG editor replacement for <textarea> fields.
// For full source code and docs, visit http://www.interactivetools.com/
//
// Version 3.0 developed by Mihai Bazon.
//   http://dynarch.com/mishoo
//
// $Id: popup.js,v 1.1.1.1 2004/08/20 20:03:58 Alfmiti Exp $

// Slightly modified for the ImageManager, window resizing is done only
// by each window's script. Added translation for a few other HTML elements.

function getAbsolutePos(el) {
	var r = { x: el.offsetLeft, y: el.offsetTop };
	if (el.offsetParent) {
		var tmp = getAbsolutePos(el.offsetParent);
		r.x += tmp.x;
		r.y += tmp.y;
	}
	return r;
};

function comboSelectValue(c, val) {
	var ops = c.getElementsByTagName("option");
	for (var i = ops.length; --i >= 0;) {
		var op = ops[i];
		op.selected = (op.value == val);
	}
	c.value = val;
};

function __dlg_onclose() {
	if(opener.Dialog._return) {
		opener.Dialog._return(null);
		opener.Dialog._finishReturn();
	}
};

function __dlg_init(bottom) {
	var body = document.body;
	var body_height = 0;
	var pos = 0;
	var x; var y;
	if (typeof bottom == "undefined") {
		var div = document.createElement("div");
		body.appendChild(div);
		pos = getAbsolutePos(div);
		body_height = pos.y;
	} else {
		pos = getAbsolutePos(bottom);
		body_height = pos.y + bottom.offsetHeight;
	}
	if(opener && opener.Dialog && opener.Dialog._arguments)
		window.dialogArguments = opener.Dialog._arguments;
	if (typeof document.all == 'undefined') {
		window.addEventListener("unload", __dlg_onclose, true);
		// center on parent
		x = opener.screenX + (opener.outerWidth - window.outerWidth) / 2;
		y = opener.screenY + (opener.outerHeight - window.outerHeight) / 2;

		window.moveTo(x, y);
	} else {

		var ch = body.clientHeight;
		var cw = body.clientWidth;
		var W = body.offsetWidth;
		var H = 2 * body_height - ch;
		if(ch <= 0) H = body_height;
		x = (screen.availWidth - W) / 2;
		y = (screen.availHeight - H) / 2;
		if(Dialog.is_ie)
			window.moveTo(x, y);
		else //opera
			window.moveTo(x, y - H/4);
	}
	document.body.onkeypress = __dlg_close_on_esc;
};

// deactivated alfmiti
function __dlg_translate(i18n) {

};

// closes the dialog and passes the return info upper.
function __dlg_close(val) {
	opener.Dialog._return(val);
	opener.Dialog._finishReturn();
	window.close();
};

function __dlg_close_on_esc(ev) {
	ev || (ev = window.event);
	if (ev.keyCode == 27) {
		window.close();
		return false;
	}
	return true;
};

function Dialog(){};
Dialog.agt = navigator.userAgent.toLowerCase();
Dialog.is_ie	   = ((Dialog.agt.indexOf("msie") != -1) && (Dialog.agt.indexOf("opera") == -1));
