/**
 * Functions for the ImageManager, used by manager.php only
 * @author $Author: Alfmiti $
 * @version $Id: manager.js,v 1.1.1.1 2004/08/20 20:03:58 Alfmiti Exp $
 * @package ImageManager
 */

	var mediaFields = ["f_url", "f_alt", "f_align", "f_horiz", "f_vert", "f_height", "f_width","f_file","f_link_url",
		                "f_link_alt", "f_link_height", "f_link_width","f_link_file","f_link_target",
		                "f_borderwidth","f_bordercolor"
		               ];

   var mediaMode = 'inline';
   var currentIframeMode = 'fileview';//images

	//Translation
	function i18n(str) {
		if(I18N)
		  return (I18N[str] || str);
		else
			return str;
	};


	//set the alignment options
	function setAlign(align)
	{
		var selection = document.getElementById('f_align');
		for(var i = 0; i < selection.length; i++)
		{
			if(selection.options[i].value == align)
			{
				selection.selectedIndex = i;
				break;
			}
		}
	}

	//initialise the form
	function init()
	{
		__dlg_init();

		if(I18N)
			__dlg_translate(I18N);

		var uploadForm = document.getElementById('uploadForm');
		if(uploadForm) uploadForm.target = 'imgManager';

      if (typeof window.dialogArguments != 'undefined') {
    		var param = window.dialogArguments;
    		if (param) {
    			document.getElementById("f_url").value = param["f_url"];
    			document.getElementById("f_alt").value = param["f_alt"];
    			document.getElementById("f_border").value = param["f_border"];
    			document.getElementById("f_vert").value = param["f_vert"];
    			document.getElementById("f_horiz").value = param["f_horiz"];
    			document.getElementById("f_width").value = param["f_width"];
    			document.getElementById("f_height").value = param["f_height"];
    			setAlign(param["f_align"]);
    		}
    	}

		document.getElementById('inline_prop').className = 'fieldsetHigh';
		document.getElementById("f_url").focus();
	}


	function onCancel()
	{
		__dlg_close(null);
		return false;
	};

	function onOK()
	{
		// pass data back to the calling window
		var param = new Object();
		for (var i in mediaFields)
		{
			var id = mediaFields[i];
			var el = document.getElementById(id);
			if (id == "f_url" || id == "f_link_url" && el.value > '')
				param[id] = makeURL(base_url,el.value);
			else
				param[id] = el.value;
		}
		__dlg_close(param);
		return false;
	};

	//similar to the Files::makeFile() in Files.php
	function makeURL(pathA, pathB)
	{
		if(pathA.substring(pathA.length-1) != '/')
			pathA += '/';

		if(pathB.charAt(0) == '/');
			pathB = pathB.substring(1);

		return pathA+pathB;
	}


	function updateDir(selection)
	{
		var newDir = selection.options[selection.selectedIndex].value;
		changeDir(newDir);
	}

	function goUpDir()
	{
		var selection = document.getElementById('dirPath');
		var currentDir = selection.options[selection.selectedIndex].text;
		if(currentDir.length < 2)
			return false;
		var dirs = currentDir.split('/');

		var search = '';

		for(var i = 0; i < dirs.length - 2; i++) {
			search += dirs[i]+'/';
		}

		for(i = 0; i < selection.length; i++)	{

			var thisDir = selection.options[i].text;
			if(thisDir == search) {
				selection.selectedIndex = i;
				var newDir = selection.options[i].value;
				changeDir(newDir);
				break;
			}
		}

		return true;
	}

	function changeDir(newDir)
	{
		if(typeof imgManager != 'undefined')
			imgManager.changeDir(newDir,currentIframeMode);
	}

	function toggleConstrains(constrains)
	{
		var lockImage = document.getElementById('imgLock');

		if(document.getElementById('constrain_prop').checked) {
			lockImage.src = "img/locked.gif";
			checkConstrains('width');
		} else {
			lockImage.src = "img/unlocked.gif";
		}
	}

	function toggleMode(obj)
	{
		if (obj.value == 'inline') {
          document.getElementById('inline_prop').className = 'fieldsetHigh';
		    document.getElementById('link_prop').className   = 'fieldsetLow';
		    mediaMode = 'inline';
		} else {
		    document.getElementById('link_prop').className = 'fieldsetHigh';
		    document.getElementById('inline_prop').className = 'fieldsetLow';
		    mediaMode = 'link';
		}
	}

	function checkConstrains(changed)
	{
		//alert(document.form1.constrain_prop);
		var constrains = document.getElementById('constrain_prop');

		if(constrains.checked) {

			var orginal_width = parseInt(document.getElementById('orginal_width').value);
			var orginal_height = parseInt(document.getElementById('orginal_height').value);

			var widthObj = document.getElementById('f_width');
			var heightObj = document.getElementById('f_height');

			var width = parseInt(widthObj.value);
			var height = parseInt(heightObj.value);

			if(orginal_width > 0 && orginal_height > 0) {
				if(changed == 'width' && width > 0) {
					heightObj.value = parseInt((width/orginal_width)*orginal_height);
				}

				if(changed == 'height' && height > 0) {
					widthObj.value = parseInt((height/orginal_height)*orginal_width);
				}
			}
		}
	}

	function showMessage(newMessage)
	{
		var message = document.getElementById('message');
		var messages = document.getElementById('messages');
		if(message.firstChild)
			message.removeChild(message.firstChild);

		message.appendChild(document.createTextNode(i18n(newMessage)));

		messages.style.display = "block";
	}

	function addEvent(obj, evType, fn)
	{
		if (obj.addEventListener) { obj.addEventListener(evType, fn, true); return true; }
		else if (obj.attachEvent) {  var r = obj.attachEvent("on"+evType, fn);  return r;  }
		else {  return false; }
	}

	function doUpload()
	{
		if (document.getElementById('upload').value > '') showMessage('Uploading');
		else showMessage('Get remotefile');
	}


	function refresh()
	{
		var selection = document.getElementById('dirPath');
		updateDir(selection);
	}


	function newFolder()
	{
		var selection = document.getElementById('dirPath');
		var dir = selection.options[selection.selectedIndex].value;

      var folder = prompt('New foldername');
		if (folder && folder != '' && typeof imgManager != 'undefined')
			imgManager.newFolder(dir, encodeURI(folder));
	}


	function switchView(mode) {
	  currentIframeMode = mode;
	  document.getElementById('uploadForm').action = mode + '.php';
	  document.getElementById('imgManager').src = mode + '.php';
	}

	function clearInput() {

	   for (var i in mediaFields)
		{
			var id = mediaFields[i];
			document.getElementById(id).value = '';
		}
	}


// fast Layer Colorpicker
// ==================================================
function rteColorPicker() {

  var palette = [
   [ 'FFFFFF','FFCCCC','FCE6C9','FCFFF0','ADFF2F','F0FFF0','E0FFFF','F0FFFF','E6E6FA','FFF0F5' ],
   [ 'CCCCCC','FF6103','FFDAB9','FFFFCC','7CFC00','BDFCC9','AFEEEE','CCF5FF','CCCCFF','FFCCFF' ],
   [ 'C0C0C0','FF0000','FF9900','FFFF00','32CD32','33FF33','00FFFF','87CEFA','9999FF','FF99FF' ],
	[ '999999','D41A1F','ED9121','FFD700','61B329','33CC00','40E0D0','00BFFF','7B68EE','CC66CC' ],
	[ '666666','D43D1A','E38217','FFCC33','009900','009900','00CED1','1E90FF','6A5ACD','CC33CC' ],
	[ '333333','B0171F','CC6600','CC9833','308014','006600','03A89E','0000FF','333399','91219E' ],
	[ '000000','990033','964514','B8860B','006600','003300','5F9EA0','0000CD','8F5E99','5C246E' ]
   ];

  document.write('<div id="colorpicker">');
  document.write('<table border="0"><tr><td><div id="show_col"></div></td>');
  document.write('<td><input type="text" id="hexvalue" /></td></tr></table>');
  document.write('<table border="0" cellspacing="0" cellpadding="0"><tr>');
  this.cpDrawColorPalette(palette);
  document.write('</tr></table></div>');
  this.divPopup = document.getElementById("colorpicker");
  this.cpInitColorPalette();
  this.visibility = false;
};


rteColorPicker.prototype.cpDrawColorPalette = function(palette) {

  var colors;
  for (var i=0; i < palette.length;i++){
      if (i > 0) document.write('</tr><tr>');
      colors = palette[i];
      for (var a=0; a < colors.length; a++) {
           document.write('<td id="#'+ colors[a] +'" style="background-color:#'+ colors[a] +';">'
                        + '<div class="cpColorDiv">&nbsp;</div></td>');
      }
  }
};

// eventhandler for colorpicker
rteColorPicker.prototype.cpInitColorPalette = function() {
   var tmpId;
   var x = typeof document.all != 'undefined' ? document.all.tags('td') : document.getElementsByTagName('td');
	for (var i=0; i< x.length; i++) {
	    if (typeof x[i].id == 'string') {
	       if (x[i].id.indexOf('#') == 0) {
        		  x[i].onmouseover = rteColorPicker.cpOver;
        		  x[i].onmouseout  = rteColorPicker.cpOut;
        		  x[i].onclick     = rteColorPicker.cpClick;
	       }
        }
	}
};


rteColorPicker.cpOver = function() {
	this.style.border='1px solid #000';
	cpUpdatePreview(this.id);
};

rteColorPicker.cpOut = function() {
	this.style.border='1px solid #FFF';
};

rteColorPicker.cpClick = function() {
   this.style.border='1px solid #FFF';
 	document.getElementById('f_bordercolor').value = this.id;
 	mmCP.togglePopup();
};

function cpUpdatePreview(color) {
   document.getElementById('show_col').style.backgroundColor = color;
   document.getElementById('hexvalue').value = color;
};

rteColorPicker.prototype.togglePopup = function() {
  this.divPopup.style.visibility = this.visibility ? 'hidden' : 'visible';
  this.divPopup.style.display    = this.visibility ? 'none' : 'inline';
  this.visibility = this.visibility ? false : true;
};


addEvent(window, 'load', init);
