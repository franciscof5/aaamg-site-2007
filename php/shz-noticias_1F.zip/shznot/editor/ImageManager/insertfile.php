<?php
/***********************************************************************
** Title.........:    Insert File Dialog, File Manager
** Version.......:    1.01
** Authors.......:    Al Rashid <alrashid@klokan.sk>
**                    Xiang Wei ZHUO <wei@zhuo.org>
** URL...........:    http://alrashid.klokan.sk/insFile/
** Filename......:    files.php
** Last changed..:    7 Jan 2004
***********************************************************************/

class insertfile
{   
	var $_name;
	var $_url;
    var $_options = array();
    var $_value = array();
    var $_RecID = 0;

    var $_js = '';
    function insertfile($elementName, $elementLabel=null, $url='insertfile', $documentRoot, $baseUrl)
    {
		$_SESSION[$elementName]['DocumentRoot'] = $documentRoot;
		$_SESSION[$elementName]['BaseUrl'] = $baseUrl;
		$this->_name = $elementName;
		if ('/' != substr($url,-1,1)) $url = $url.'/';
		$this->_url = $url;
		$this->_label = $elementLabel;
		

    } //end constructor

  function setOptions($options)
    {
		if (is_array($options)) {
			foreach ($options as $key => $value) {
				$_SESSION[$this->_name][$key] = $value;
			}
		}
	}
     
    function setValue($values)
    {
		if (is_array($values)) {
			foreach ($values as $arr) {
				if (is_array($arr)) {
						$this->_value[$this->_RecID]['url'] = $arr['url'];
						$this->_value[$this->_RecID]['caption'] = $arr['caption'];
						$this->_value[$this->_RecID]['comment'] = $arr['comment'];
						$this->_RecID++;
				}
			}
		}

	} // end func setValue

    function clearValue()
    {
		$this->_value = array();
		
	} // end func clearValue

    function toHtml()
    {
	$html = "\n";
	    if (!defined('INSERTFILE_EXISTS')) {

$html .='
<script type="text/javascript" src="'.$this->_url.'js/dialog.js"></script>
<script type="text/javascript" src="'.$this->_url.'js/insertfile.js"></script>
<script type="text/javascript">
	function insertFile(name) {
		Dialog("'.$this->_url.'filedialog.php?dialogname="+name, function(param) {
			if (!param) {	// user must have pressed Cancel
				return false;
			} else	{
				addRecord(name, param["f_url"],param["f_caption"],param["f_comment"]);
			}
		}, null);
	}
</script>';

			define('INSERTFILE_EXISTS', true);
        } // already defined

$html .= '
<script type="text/javascript">
	RecID[\''.$this->_name.'\']='.$this->_RecID.';
</script>';

$html .= '
<table id="table_'.$this->_name.'" >
	<thead>
		<tr>
			<th colspan="4">'.$this->_label.'</th>
		</tr>
		<tr>
			<th>Action</th>
			<th>URL</th>
			<th>Caption</th>
			<th>Comment</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<th colspan="4" align="left"><input type=button name="Add" value="Add" onClick="insertFile(\''.$this->_name.'\')"></th>
		</tr>
	</tfoot>
	<tbody id="tbody_'.$this->_name.'">
		<tr style="display:none"><td colspan="4"></td></tr>';

		foreach ($this->_value as $key => $value) {
			$html .= "\n".'<tr id="'.$this->_name.'_'.$key.'">';
			$html .= "\n\t".'<td><input type="button" id="delete-'.$this->_name.'_'.$key.'" value="x" onclick="RemoveRecord2(this.id)"></td>';
			$html .= "\n\t".'<td><input type="text" name="'.$this->_name.'['.$key.'][url]" size="30" value="'.$value['url'].'"></td>';
			$html .= "\n\t".'<td><input type="text" name="'.$this->_name.'['.$key.'][caption]" size="30" value="'.$value['caption'].'"></td>';
			$html .= "\n\t".'<td><textarea cols="30" rows="4" name="'.$this->_name.'['.$key.'][comment]">'.$value['comment'].'</textarea></td>';
			$html .= "\n".'</tr>';
		}

$html .= '
	</tbody>
</table>
';

        return $html;
    } // end func toHtml
}
?>
