<?

// Incuindo o arquivo de configura��o
include("config.php");

//Script de autentica��o de usu�rios
include "lg/se.php";

if ($nivelusuario != "3"){
print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
 		Exit();
	}

echo "<form action='admin.php?viewby=alterar_db&id=".$_GET['id']."' method='post'>";

// Conectando ao banco de dados.
@$conexao = mysql_connect($dbserver, $dbuser, $dbpass);

// Selecionando a base de dados.
@$db = mysql_select_db("$dbname");

// Selecionando na tablela os dados necessarios.
@$sql = "SELECT * FROM $dbtb WHERE id='".$_GET['id']."'";

// Executando $sql e verificando se tudo ocorreu certo.
@$resultado = mysql_query($sql)

// Menssagen de erro.
or die ("<font color=$colortex size=$sizetex2><B>N�o foi poss�vel realizar a consulta ao banco de dados</B></font><font size=$sizetex><BR><BR><a href=http://$esite/admin.php?viewby=alterar>VOLTAR</a></font>");

// Pegando os dados.
$linha=mysql_fetch_array($resultado);
$id = $linha["id"];
$fonte = $linha["fonte"];
$endfonte = $linha["endfonte"];
$email = $linha["email"];
$data = $linha["data"];
$hora = $linha["hora"];
$titulo = $linha["titulo"];
$subtitulo = $linha["subtitulo"];
$texto = $linha["texto"];
$ver = $linha["ver"];

$novadata = substr($data,8,2) . "/" .substr($data,5,2) . "/" . substr($data,0,4);
$novahora = substr($hora,0,2) . "h" .substr($hora,3,2) . "min";

// Formulario de altera��o dos dados com os dados antigos como defaut.
echo "<font face=$face size=$sizetex2 color='$colortex'><b>ALTERAR...</b></font><br>";
echo "<br>";
echo "<table border=0 cellpadding=1 cellspacing=1>";

echo "<tr><td><font face=$face size=$sizetex color='$colortex'>C�digo da Not�cia: </font></td><td><input name='id_novo' type='text' value='$id' size=20></td></tr>";

echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Grupo:</font></td>
<td><SELECT NAME='grupo_novo' SIZE='1'>";
// Selecionando os dados da tabela em ordem decrescente
$sql = "SELECT * FROM $dbtbg ORDER BY nome";
// Executando $sql e verificando se tudo ocorreu certo.
$resultado = mysql_query($sql);
//Realizando um loop para exibi��o de todos os dados 
while ($linha=mysql_fetch_array($resultado)) {
echo "<OPTION VALUE='".$linha['id']."' ";
if ($linha['grupo'] == $linha2['id']) {
echo "SELECTED";
}

echo ">".$linha['nome'];
}
echo "</SELECT></td></tr>";

echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Data: </font></td><td><font size=$sizetex>$novadata</font></td></tr>";
echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Hora: </font></td><td><font size=$sizetex>$novahora</font></td></tr>";
echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Fonte:</font></td><td><input name='fonte_novo' type='text' value='$fonte' size=30> </td></tr>";
echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Site fonte:</font></td><td><input name='endfonte_novo' type='text' value='$endfonte' size=30> </td></tr>";
echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Email: <i>(Exemplo: david@shz.com.br)</i></font></td><td><input name='email_novo' type='text'
value='$email' size=30><br></font></td></tr>";
echo "<tr><td><font face=$face size=$sizetex color='$colortex'>T�tulo do Texto:</font></td><td><input name='titulo_novo' type='text' value='$titulo' size=30></td></tr>";

echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Subt�tulo do Texto:</font></td><td>
<textarea id='body' name='subtitulo_novo' rows=5 cols=30>$subtitulo</textarea>";
?>
<script type="text/javascript">

         var editor1 = new tinyRTE('body', rteCSSfile,true);
         editor1.replaceTextarea(400,300);

        </script>
<?php
echo "</td></tr><tr><td><font face=$face size=$sizetex color='$colortex'>Texto:</font></td><td>
<textarea id='body1' name='texto_novo' rows=10 cols=30>$texto</textarea>";
?>
<script type="text/javascript">

         var editor1 = new tinyRTE('body1', rteCSSfile,true);
         editor1.replaceTextarea(400,300);

        </script>
<?php
echo "</td></tr><tr><td><font face=$face size=$sizetex color='$colortex'>Disponibilizar? (on ou off): </font></td><td>
<SELECT NAME='ver_novo' SIZE='2'>
<OPTION VALUE='on'";
if ($ver == 'on'){echo "SELECTED";}
 echo ">SIM
<OPTION VALUE='off'";
if ($ver == 'off'){echo "SELECTED";}
echo ">N�O</SELECT>

</td></tr>";
echo "<tr><td></td><td align='right'><input type='submit' value='ALTERAR'></td></tr>";
echo "</form></table>";
echo "<br><Br>";

echo "<CENTER><font face=$face size=$sizetex1 color='$colortex'><a href=javascript:history.back()><b>VOLTAR</b></a></font></center>";
?>
