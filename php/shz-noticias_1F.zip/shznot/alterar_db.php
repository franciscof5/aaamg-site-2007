<?

// Incuindo o arquivo de configura��o
include("config.php");

//Script de autentica��o de usu�rios
include "lg/se.php";

if ($nivelusuario != "3"){
print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
 		Exit();
	}

// Muda de 1 para 2 o valor do arualiza
$atualiza_novo = 2;

// Conectando com o banco de dados.
@$conexao = mysql_connect($dbserver, $dbuser, $dbpass);

// Selecionando a base de dados.
@$db = mysql_select_db($dbname);


$_POST['subtitulo_novo1'] = str_replace("\\\"", "\"", $_POST['subtitulo_novo']);
$_POST['texto_novo1'] = str_replace("\\\"", "\"", $_POST['texto_novo']);

// Atualizando os dados.
$sql = "UPDATE $dbtb SET id='".$_POST['id_novo']."',fonte='".$_POST['fonte_novo']."',endfonte='".$_POST['endfonte_novo']."'
,email='".$_POST['email_novo']."',titulo='".$_POST['titulo_novo']."',subtitulo='".$_POST['subtitulo_novo1']."'
,texto='".$_POST['texto_novo1']."',ver='".$_POST['ver_novo']."',atualiza='$atualiza_novo' WHERE id='".$_GET['id']."'";

// Executando $sql e verificando se tudo ocorreu certo.
@$resultado = mysql_query($sql)

// Menssagen de erro.
or die ("<font face=$face size=$sizetex color='$colortex'><B>N�o foi poss�vel atualizar banco de dados</B></font><BR><BR>
<CENTER><font face=$face size=$sizetex1 color='$colortex'><a href=http://$esite/admin.php?viewby=alterar>VOLTAR</a></font></CENTER>");

// Menssagem de exito.
echo "<font face=$face size=$sizetex color='$colortex'><B>Not�cia alterada com sucesso!</B></font> <br><br>
<center><font face=$face size=$sizetex1 color='$colortex'><a href=http://$esite/admin.php?viewby=alterar><B>VOLTAR</b></a></font></center>";

?>
</html>
