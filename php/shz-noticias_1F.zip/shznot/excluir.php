<?

// Incuindo o arquivo de configura��o
include("config.php");

//Incluindo arquivo de autentica��o
include "lg/se.php";

//Arquico com estilo de link
include "stl.php";

if ($nivelusuario != "3"){
print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
 		Exit();
	}

?>
<html>
<?
//A variavel $tituloshz define o titulo do site.
//Essa variavel pode ser alterada no config.php
?>
<title><? echo $tituloshz; ?></title>
<body bgcolor="<? echo $colorbg; ?>" onload="setTimeout ('window.location.reload(true)',900000)">

<?php
//Arquico com estilo de link
include "stl.php";

// Conectando com o banco de dados.
@$conexao = mysql_connect($dbserver, $dbuser, $dbpass);

// Selecionando a base de dados.
@$db = mysql_select_db($dbname);

// Deletando os dados selecionados
@$sql = "DELETE FROM $dbtb WHERE id='".$_GET['id']."'";

// Executando $sql e verificando se tudo correu certo.
@$resultado = mysql_query($sql)

// Menssagen de erro.
or die ("<font face=$face size=$sizetex color='$colortex'>N�o foi poss�vel realizar a exclus�o dos dados.</font>
<a href=http://$esite/admin.php><font size=$sizetex><B>Voltar!</B></font>");

// Menssagem de exito.
echo "<font face=$face size=$sizetex color='$colortex'>A not�cia foi exclu�da com �xito!</font><br><br>
<center><font face=$face size=$sizetex1 color='$colortex'><a href=?viewby=alterar><B>VOLTAR</B></a></font></center>";

?>
