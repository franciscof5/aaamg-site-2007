<!-- 
+++++++++++++++++++++++++++
++ Menu SHZ, come�a aqui ++
+++++++++++++++++++++++++++
-->


<table width="170" border="0" cellpadding="0" cellspacing="0" valign="top">
<?php
@include "config.php";
@include "shznot/config.php";
// Conectando com o banco de dados.
@$conexao = mysql_connect($dbserver, $dbuser, $dbpass);

// Selecionando a base de dados.
@$db = mysql_select_db("$dbname");
?>

<!-- 
==========================================
== AQUI COME�A A GERAR BOT�ES DE GRUPOS ==
==========================================
-->
<?php
@$sql = "SELECT * FROM $dbtbg ORDER BY nome";
@$resultado = mysql_query($sql)
or die ("<font color=$colortex size=$sizetex2>N? foi poss?el realizar a consulta ao banco de dados</font>");
// Organizando os dados.
while ($linha=mysql_fetch_array($resultado)) {
$ideven = $linha["id"];
$nomebarra = strtolower($linha["nome"]);
$nomemenu = ucwords($nomebarra);
$nomebarra = strtoupper($linha["nome"]);
$nomemenu = str_replace("_", " ", $nomemenu);
//$nomemenu = strtoupper($nomee);

?>

<!-- COM TABELA -->
<!-- LINHA DA TABELA COM 2 COLUNAS (PARA ESPA�AMENTO) -->
<tr><td width="10"></td>
<td width="170" align="left" valign="top" background=''>

<a href= '?grupo=<?echo$ideven;?>' title="<?echo $nomemenu;?>" target="_top" class="menu"> <?php if($_GET['idc'] == $ideven){echo "<B>";}echo "<font size=2>".$nomemenu;?></B></font></a>
</td></tr><?php }
?>

<!-- 
============================================
== AQUI TERMINA DE GERAR BOT�ES DE GRUPOS ==
============================================
-->


<!-- Menu SHZ, termina aqui -->
</table>
