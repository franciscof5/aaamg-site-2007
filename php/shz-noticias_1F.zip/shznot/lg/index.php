<?
session_start();
@session_destroy();
include "../config.php";
?>
<title><? echo$tituloshz; ?></title>
<?echo"
<CENTER><font color=$colortex size='$sizetex2'><b>$tituloshz - ENTRADA</b></font>
<form method='post' action='md5.php'>
<table><tr><td>
<font color=$colortex size='$sizetex'>NOME:</font></td><td>
<input type=text name='nomec'></td></tr>
<tr><td>
<font color=$colortex size='$sizetex'>SENHA:</font></td> <td>
<input type=PASSWORD name='senhac'></td></tr>
<tr><td>    </td>  <td>
<input type=submit value='Entrar'>
<input type=reset value='Limpar'>
</form></td></tr></table></CENTER>";
?>
