<?

$nomec = $_SESSION['nomec'];
$senhac = $_SESSION['senhac'];

// Incuindo o arquivo de configura��o
include "config.php";

if (empty($nomec)) {
//login ou senha errada? Retorna pra index
    header("Location: http://".$esite."/lg/index.php?erro=1");

}



// Conectando com o banco de dados.
$conexao = mysql_connect($dbserver, $dbuser, $dbpass)

or die ("<font color=$colortex size=$sizetex2>A connex�o com o Banco de Dados falhou!</font>");

// Selecionando a base de dados.
$db = mysql_select_db("$dbname");

$confere = "SELECT * FROM $dbtbu WHERE nome = '$nomec'";

$respostac = mysql_query($confere);
$dadosc=mysql_fetch_array($respostac);

$nivelusuario = $dadosc[nivel];
if ($senhac!=$dadosc[senha]) {
//login ou senha errada? Retorna pra index
    header("Location: http://".$esite."/lg/index.php?erro=1");

}


?>
