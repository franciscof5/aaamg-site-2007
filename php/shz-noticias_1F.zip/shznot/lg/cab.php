<html>
<title><? echo $tituloshz; ?></title>
<?
include("stl.php");
?>
<body bgcolor="<? echo $colorbg; ?>" onload="setTimeout ('window.location.reload(true)',900000)">
