<?
session_start();

       $nomec = $_POST['nomec'];
       $senhac = md5($_POST['senhac']);
$nomec = strtolower($nomec);

     function connect_db()
     {
              global $database,$dbid, $conid, $tabela, $tituloshz;

              include "../config.php";
              $database = $dbname;
              $tabela = $dbtbu;
              $conid = mysql_connect($dbserver, $dbuser, $dbpass);
              $dbid = mysql_select_db($database,$conid);
    }

    function php_login($nomec, $senhac)
    {        global $database, $conid, $tabela;




             if(!$result = mysql_query("SELECT * FROM $tabela WHERE nome = \"$nomec\"", $conid))
             die("<B>-[Database Error]-</B><BR><hr>Imposs�vel acessar tabela de $tabela .");

             $rst = mysql_fetch_array($result);


             $login = $rst[nome];
             $pass = $rst[senha];

             if ($login != "")
             {  if ($pass == $senhac)
                {  $canlog = true;

                }
                else
                {  $cablog = false;}
             }

             mysql_close($conid);

             return $canlog;
     }

     connect_db();

if (!php_login($nomec, $senhac)) {
 global $pass, $login;
//login ou senha errada? Retorna pra index
    header("Location: index.php?erro=1");

}

else {  global $nomec, $senhac;
        //dando valor para as session.


    // registrando a session

    session_register("nomec");
    session_register("senhac");

    // tenho que redirecion�-la para outra p�gina para poder usar a session...
    header("Location: ../admin.php");

}

?>
