<?
// Incuindo o arquivo de configura��o
include("config.php");

//Incluindo arquivo de autentica��o
include "lg/se.php";

//Arquico com estilo de link
include "stl.php";

if ($nivelusuario == "1"){
$ver = "off";
	}
?>
<html>
<?
//A variavel $tituloshz define o titulo do site.
//Essa variavel pode ser alterada no config.php
?>
<title><? echo $tituloshz; ?></title>
<body bgcolor="<? echo $colorbg; ?>" onload="setTimeout ('window.location.reload(true)',900000)">

<?php
$_POST['subtitulo1'] = str_replace("\\\"", "\"", $_POST['subtitulo']);
$_POST['texto1'] = str_replace("\\\"", "\"", $_POST['texto']);


@$sql = "INSERT INTO $dbtb (fonte, endfonte, email, data, hora, titulo, subtitulo, texto, atualiza, ver, grupo) VALUES ('".$_POST['fonte']."', '".$_POST['endfonte']."',
'".$_POST['email']."', '".$_POST['data']."', '".$_POST['hora']."', '".$_POST['titulo']."', '".$_POST['subtitulo1']."', '".$_POST['texto1']."', '".$_POST['atualiza']."', '".$_POST['ver']."', '".$_POST['grupo']."')";

//Agora � hora de contatar o mysql

// Conectando com o banco de dados.
@$conexao = mysql_connect($dbserver, $dbuser, $dbpass)

// Menssagen de erro.
or die ("<font color=$colortex size=$sizetex2>Configura��o de Banco de Dados Errada!</font>
<a href=http://$esite/admin.php><font size=$sizetex><B>Voltar!</B></font>");

// Selecionando a base de dados.
@$db = mysql_select_db($dbname)

// Menssagen de erro.
or die ("<font face=$face size=$sizetex color='$colortex'>Banco de Dados Inexistente!</font>
<a href=http://$esite/admin.php><font face=$face size=$sizetex1 color='$colortex'><B>Voltar!</B></font>");

//Inserindo os dados
@$sql = mysql_query($sql)

// Menssagen de erro.
or die ("<font face=$face size=$sizetex color='$colortex'>Houve erro na grava��o dos dados, por favor, clique em voltar e verifique os campos obrigat�rios!</font>
<a href=http://$esite/admin.php><font face=$face size=$sizetex1 color='$colortex'><B>Voltar!</B></font>");


// Menssagem de exito.
echo "<font face=$face size=$sizetex color='$colortex'><b>Cadastro efetuado com sucesso!</b></font><br>
<center><font face=$face size=$sizetex1 color='$colortex'><a href=http://$esite/admin.php><B>VOLTAR</B></font></a></center>";


?>
