<?

// Incuindo o arquivo de configura��o
include("config.php");

//Script de autentica��o de usu�rios
include "lg/se.php";

if ($nivelusuario != "3"){
print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
 		Exit();
	}

?>
<html>
<?
//A variavel $tituloshz define o titulo do site.
//Essa variavel pode ser alterada no config.php
?>
<title><? echo $tituloshz; ?></title>
<body bgcolor="<? echo $colorbg; ?>" onload="setTimeout ('window.location.reload(true)',900000)">

<?php
// Executando $sql e verificando se tudo ocorreu certo.
include "stl.php";
// Muda de 1 para 2 o valor do arualiza
$atualiza_novo = 2;

// Conectando com o banco de dados.
@$conexao = mysql_connect($dbserver, $dbuser, $dbpass);

// Selecionando a base de dados.
@$db = mysql_select_db($dbname);


// Atualizando os dados.
@$sql = "UPDATE $dbtb SET ver='".$_GET['ver']."' WHERE id='".$_GET['id']."'";

// Executando $sql e verificando se tudo ocorreu certo.
@$resultado = mysql_query($sql)

// Menssagen de erro.
or die ("<font face=$face size=$sizetex color='$colortex'><B>N�o foi poss�vel atualizar banco de dados</B></font><BR><BR>
<CENTER><font face=$face size=$sizetex1 color='$colortex'><a href=http://$esite/admin.php?viewby=alterar>VOLTAR</a></font></CENTER>");

// Menssagem de exito.
echo "<font face=$face size=$sizetex color='$colortex'><B>Not�cia publicada com sucesso!</B></font> <br><br>
<center><font face=$face size=$sizetex1 color='$colortex'><a href=http://$esite/admin.php?viewby=publica><B>VOLTAR</b></a></font></center>";

?>
</html>
