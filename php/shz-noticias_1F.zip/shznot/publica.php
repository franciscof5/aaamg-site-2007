<?php

// Incuindo o arquivo de configura��o
include "config.php";

//Incluindo arquivo de autentica��o
include "lg/se.php";

include "stl.php";

if ($nivelusuario != "3"){
print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
 		Exit();
	}

?>
<html>
<?
//A variavel $tituloshz define o titulo do site.
//Essa variavel pode ser alterada no config.php
?>
<title><? echo $tituloshz; ?></title>
<body bgcolor="<? echo $colorbg; ?>" onload="setTimeout ('window.location.reload(true)',900000)">

<?



// Conectando com o banco de dados.
$conexao = mysql_connect($dbserver, $dbuser, $dbpass);

// Selecionando a base de dados.
$db = mysql_select_db("$dbname");

// Selecionando os dados da tabela em ordem decrescente
$sql = "SELECT * FROM $dbtb WHERE ver != 'on' ORDER BY id DESC";

// Executando $sql e verificando se tudo ocorreu certo.
$resultado = mysql_query($sql);

/*
Aqui vai a primeira parte do segredo da pagina��o, vc deve colocar a sua QUERY neste local
colocando as condi��es para a busca
*/
$pagina = empty($HTTP_GET_VARS['pagina'])? 1 : $HTTP_GET_VARS['pagina']; // qual p�gina estamos visualizando?
$registros_por_pagina = "10";
$pagina_anterior = $pagina - 1;
$pagina_posterior = $pagina + 1;
$registro_inicio = ($registros_por_pagina * $pagina) - $registros_por_pagina;
/*
   Vamos calcular a p�gina anterior e posterior que estamos
   Em seguida devemos calcular qual o ponto nos registros retornados na QUERY, acima,
   atualmente devemos RECOME�AR a ler.

*/






$total_de_registros = mysql_num_rows($resultado);

if ($total_de_registros <= $registros_por_pagina) {
    $total_de_paginas = 1;
}elseif (($total_de_registros % $registros_por_pagina) == 0) {
    $total_de_paginas = ($total_de_registros / $registros_por_pagina);
}else{
    $total_de_paginas = ($total_de_registros / $registros_por_pagina) + 1;
}
/*
   Neste peda�o se faz o c�lculo de n�mero de p�ginas que ser� preciso
   dividir o resultado
*/


$total_de_paginas = (int) $total_de_paginas;
/*
   Caso o n�mero seja quebrado, transformar em n�mero inteiro
*/

if (($pagina > $total_de_paginas) || ($pagina < 0))
{
    echo 'n�mero da p�gina inv�lido';
    exit;
}


$sql = $sql . " LIMIT $registro_inicio, $registros_por_pagina";

$resultado = mysql_query($sql);
$total_de_registros_da_pagina = mysql_num_rows($resultado);
if ($total_de_registros_da_pagina == 0)
{
    echo 'sem registros nesta p�gina';
    exit;
}
else
{

// Tabela de para exibi��o dos dados selecionados.
echo "<table width=640 border=1 cellpadding=1 cellspacing=1>";
echo "<tr>";
//echo "<td width=15><font color=$colortex size='$sizetex'><B>ID:</B></font></td>";
echo "<td width=35><font color=$colortex size='$sizetex'><B>Fonte:</B></font></td>";
echo "<td width=50><font color=$colortex size='$sizetex'><B>Email:</B></font></td>";
echo "<td width=30><font color=$colortex size='$sizetex'><B>Data:</B></font></td>";
echo "<td width=30><font color=$colortex size='$sizetex'><B>Hora:</B></font></td>";
echo "<td width=100><font color=$colortex size='$sizetex'><B>T�tulo:</B></font></td>";
echo "<td width=15><font color=$colortex size='$sizetex'><B>Excluir:</B></font></td>";
echo "<td width=20><font color=$colortex size='$sizetex'><B>Publicar:</B></font></td>";;
echo "</tr>";

//Realizando um loop para exibi��o de todos os dados 
while ($linha=mysql_fetch_array($resultado)) {
$id = $linha["id"];
$fonte = $linha["fonte"];
$endfonte = $linha["endfonte"];
$email = $linha["email"];
$data = $linha["data"];
$hora = $linha["hora"];
$titulo = $linha["titulo"];
$ver = $linha["ver"];
$novadata = substr($data,8,2) . "/" .substr($data,5,2) . "/" . substr($data,0,4);
$novahora = substr($hora,0,2) . "h" .substr($hora,3,2) . "min";

//Tabela com cores alternadas
if ($colorcount % 2) { $color = $colorbg; } else { $color = $colortb; }
echo "<tr align=top bgcolor=\"$color\">";
//echo "<td width=15><font color=$colortex size='$sizetex1'>$id</font><br></td>";
echo "<td width=35><font color=$colortex size='$sizetex1'>$fonte</font><br></td>";
echo "<td width=50><font color=$colortex size='$sizetex1'>$email</font><br></td>";
echo "<td width=30><font color=$colortex size='$sizetex1'>$novadata</font><br></td>";
echo "<td width=30><font color=$colortex size='$sizetex1'>$novahora</font><br></td>";
echo "<td width=100><font color=$colortex size='$sizetex1'>$titulo</font><br></td>";
echo "<td width=15><font color=$colortex size='$sizetex1'><a href='admin.php?viewby=excluir2&id=$id&refepublica=1'>Excluir<font color=red>-X</font></a></font></td>";
echo "<td width=20><font color=$colortex size='$sizetex1'><a href='admin.php?viewby=publicar&id=$id&ver=on'>Publicar<font color=blue>:)</font></a></font></td>";
echo "</tr>";
$colorcount++;
}
echo "</table>";  }

$link_de_navegacao = '';
/* link "anterior" */
if($pagina_anterior)
{
    $link_de_navegacao .= " <a href='admin.php?viewby=alterar&idnome=$idnome&pagina=$pagina_anterior'>Anterior</a> ";
}
for($i = 1; $i <= $total_de_paginas; $i++)
{
    if($i != $pagina)
    {
        /* link individual para as outras p�ginas */
        $link_de_navegacao .= " <a href='admin.php?viewby=alterar&idnome=$idnome&pagina=$i'>$i</a> ";
    }else{
        $link_de_navegacao .= " <b>[$i]</b> ";
    }
}
/* link "proximo" */
if($pagina != $total_de_paginas)
{
    $link_de_navegacao .= "<a href='admin.php?viewby=alterar&idnome=$idnome&pagina=$pagina_posterior'>Pr�ximo</a>";
}

echo "<p>" . $link_de_navegacao;
?>
</html>
