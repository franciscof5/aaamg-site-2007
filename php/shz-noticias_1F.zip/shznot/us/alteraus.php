<?
if ($nivelusuario != "3"){
print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
 		Exit();
	}
//Tirando o valor da variavel $esite
$esite="";
// Incuindo o arquivo de configura��o
@include("config.php");

//Testando valor da variavel $esite, se estiver
//sem valor vai para tela de entrada
if (empty($esite)){
//Incluindo arquivo de autentica��o
@include "../lg/se.php";
}
//Incluindo arquivo de autentica��o
@include "lg/se.php";

// Conectando com o banco de dados.
$conexao = mysql_connect($dbserver, $dbuser, $dbpass);

// Selecionando a base de dados.
$db = mysql_select_db("$dbname");

// Selecionando os dados da tabela em ordem decrescente
$sql = "SELECT * FROM $dbtbu ORDER BY id DESC";

// Verificando se tudo ocorreu certo.
$resultado = mysql_query($sql)

// Menssagen de erro.
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");


/*
Aqui vai a primeira parte do segredo da pagina��o, vc deve colocar a sua QUERY neste local
colocando as condi��es para a busca
*/
$pagina = empty($HTTP_GET_VARS['pagina'])? 1 : $HTTP_GET_VARS['pagina']; // qual p�gina estamos visualizando?
$registros_por_pagina = "10";
$pagina_anterior = $pagina - 1;
$pagina_posterior = $pagina + 1;
$registro_inicio = ($registros_por_pagina * $pagina) - $registros_por_pagina;
/*
   Vamos calcular a p�gina anterior e posterior que estamos
   Em seguida devemos calcular qual o ponto nos registros retornados na QUERY, acima,
   atualmente devemos RECOME�AR a ler.

*/






$total_de_registros = mysql_num_rows($resultado);

if ($total_de_registros <= $registros_por_pagina) {
    $total_de_paginas = 1;
}elseif (($total_de_registros % $registros_por_pagina) == 0) {
    $total_de_paginas = ($total_de_registros / $registros_por_pagina);
}else{
    $total_de_paginas = ($total_de_registros / $registros_por_pagina) + 1;
}
/*
   Neste peda�o se faz o c�lculo de n�mero de p�ginas que ser� preciso
   dividir o resultado
*/


$total_de_paginas = (int) $total_de_paginas;
/*
   Caso o n�mero seja quebrado, transformar em n�mero inteiro
*/

if (($pagina > $total_de_paginas) || ($pagina < 0))
{
    echo 'n�mero da p�gina inv�lido';
    exit;
}


$sql = $sql . " LIMIT $registro_inicio, $registros_por_pagina";

$resultado = mysql_query($sql);
$total_de_registros_da_pagina = mysql_num_rows($resultado);
if ($total_de_registros_da_pagina == 0)
{
    echo 'sem registros nesta p�gina';
    exit;
}
else
{


echo "<font face=$face size=$sizetex2 color='$colortex'><B>Lista de usuarios</B></font><BR>";
// Tabela de para exibi��o dos dados selecionados.
echo "<table width=640 border=1 cellpadding=1 cellspacing=1>";
echo "<tr>";
//echo "<td width=15><B>ID:</B></td>";
echo "<td width=95><B><font face=$face size=$sizetex color='$colortex'>Nome:</B></td>";
echo "<td width=90><B><font face=$face size=$sizetex color='$colortex'>Email:</B></td>";
echo "<td width=30><B><font face=$face size=$sizetex color='$colortex'>Data:</B></td>";
echo "<td width=30><B><font face=$face size=$sizetex color='$colortex'>Hora:</B></td>";
echo "<td width=30><B><font face=$face size=$sizetex color='$colortex'>Nivel:</B></td>";
echo "<td width=10><B><font face=$face size=$sizetex color='$colortex'>Excluir?</B></td>";
echo "<td width=30><B><font face=$face size=$sizetex color='$colortex'>Alterar</B></td>";
echo "</tr>";

//Realizando um loop para exibi��o de todos os dados 
while ($linha=mysql_fetch_array($resultado)) {
$id = $linha["id"];
$nome = strtoupper($linha["nome"]);
$email = $linha["email"];
$data = $linha["data"];
$hora = $linha["hora"];
$senha = $linha["senha"];
$nivel = $linha["nivel"];
$novadata = substr($data,8,2) . "/" .substr($data,5,2) . "/" . substr($data,0,4);
$novahora = substr($hora,0,2) . "h" .substr($hora,3,2) . "min";

//Tabela com cores alternadas
if ($colorcount % 2) { $color = $colorbg; } else { $color = $colortb; }
echo "<tr align=top bgcolor=\"$color\">";
//echo "<td width=15>$id<br></td>";
echo "<td width=95><font face=$face size=$sizetex1 color='$colortex'>$nome</font><br></td>";
echo "<td width=90><font face=$face size=$sizetex1 color='$colortex'>$email</font><br></td>";
echo "<td width=30><font face=$face size=$sizetex1 color='$colortex'>$novadata</font><br></td>";
echo "<td width=30><font face=$face size=$sizetex1 color='$colortex'>$novahora</font><br></td>";
echo "<td width=30><font face=$face size=$sizetex1 color='$colortex'>$nivel</font><br></td>";
echo "<td width=10><a href='admin.php?viewby=excluirus&id=$id'><font face=$face size=$sizetex1 color='$colortex'>Excluir <font color=red>X</font></font></a><br></td>";
echo "<td width=50><a href='admin.php?viewby=alterarus&id=$id'><font face=$face size=$sizetex1 color='$colortex'>Alterar</font></a></td>";
echo "</tr>";
$colorcount++;
}

echo "</table>";}

$link_de_navegacao = '';
/* link "anterior" */
if($pagina_anterior)
{
    $link_de_navegacao .= " <a href='admin.php?viewby=usuarios&idnome=$idnome&pagina=$pagina_anterior'>Anterior</a> ";
}
for($i = 1; $i <= $total_de_paginas; $i++)
{
    if($i != $pagina)
    {
        /* link individual para as outras p�ginas */
        $link_de_navegacao .= " <a href='admin.php?viewby=usuarios&idnome=$idnome&pagina=$i'>$i</a> ";
    }else{
        $link_de_navegacao .= " <b>[$i]</b> ";
    }
}
/* link "proximo" */
if($pagina != $total_de_paginas)
{
    $link_de_navegacao .= "<a href='admin.php?viewby=usuarios&idnome=$idnome&pagina=$pagina_posterior'>Pr�ximo</a>";
}

echo "<p>" . $link_de_navegacao;



?>
</html>
