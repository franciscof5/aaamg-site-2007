<?
if ($nivelusuario != "3"){
print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
 		Exit();
	}
//Tirando o valor da variavel $esite
$esite="";
// Incuindo o arquivo de configura��o
@include("config.php");

//Testando valor da variavel $esite, se estiver
//sem valor vai para tela de entrada
if (empty($esite)){
//Incluindo arquivo de autentica��o
@include "../lg/se.php";
}
//Incluindo arquivo de autentica��o
@include "lg/se.php";


$senhaca = md5($senhaca);
$sql = "INSERT INTO $dbtbu (nome, email, data, hora, senha, nivel) VALUES ('".$_POST['nomeca']."', '".$_POST['email']."',
'".$_POST['dataca']."', '".$_POST['horaca']."', '".$_POST['senhaca']."', '".$_POST['nivel']."')";

//Agora � hora de contatar o mysql

// Conectando com o banco de dados.
$conexao = mysql_connect($dbserver, $dbuser, $dbpass)

// Menssagen de erro.
or die ("Configura��o de Banco de Dados Errada!");

// Selecionando a base de dados.
$db = mysql_select_db($dbname)

// Menssagen de erro.
or die ("Banco de Dados Inexistente!");

//Inserindo os dados
$sql = mysql_query($sql) 

// Menssagen de erro.
or die ("Houve erro na grava��o dos dados, por favor, clique em voltar e verifique os campos obrigat�rios!");

$nomeca = trim($nomeca);
$nomeca = strtoupper($nomeca);

// Menssagem de exito.
echo "<font face=$face size=$sizetex color='$colortex'>Cadastro de ".$_POST['nomeca']." efetuado com sucesso!<br>
<center><font face=$face size=$sizetex1 color='$colortex'><a href=http://$esite/admin.php?viewby=usuarios><B>VOLTAR</B></a></font><center>";


?>
