<?
if ($nivelusuario != "3"){
print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
 		Exit();
	}
//Tirando o valor da variavel $esite
$esite="";
// Incuindo o arquivo de configura��o
@include("config.php");

//Testando valor da variavel $esite, se estiver
//sem valor vai para tela de entrada
if (empty($esite)){
//Incluindo arquivo de autentica��o
@include "../lg/se.php";
}
//Incluindo arquivo de autentica��o
@include "lg/se.php";


if ($_POST['referenovo'] == 'novo'){

// Conectando com o banco de dados.
$conexaoteste = mysql_connect($dbserver, $dbuser, $dbpass);
// Selecionando a base de dados.
$dbteste = mysql_select_db("$dbname");
// Selecionando os dados da tabela em ordem decrescente
$sqlteste = "SELECT * FROM $dbtbu WHERE nome = '".$_POST['nomeca']."'";
// Verificando se tudo ocorreu certo.
$resultadoteste = mysql_query($sqlteste)
// Menssagen de erro.
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");
$teste=mysql_fetch_array($resultadoteste) ;


if (!empty($teste["nome"])){
 		print "<b>O usuario <I>".$teste["nome"]."</I> j� existe!</b><br><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar";
 		Exit();
	}


if (empty($_POST['nomeca'])){
 		print "<b>Informe um nome de usu�rio!</b><br><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar";
 		Exit();
	}

if (eregi ("[[:punct:]]+$", $_POST['nomeca'])){
 		print "<b>O nome n�o pode conter sinais de pontua��o</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar";
 		Exit();
}

if (empty($_POST['email'])){
 		print "<b>Informe um e-mail para para o usu�rio!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar";
 		Exit();
	}
	
if (!eregi ("^([a-z0-9_]|\\-|\\.)+@(([a-z0-9_]|\\-)+\\.)+[a-z]{2,4}$", $_POST['email'])){
 		print "<b>Informe um e-mail VALIDO para para o usu�rio!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar";
 		Exit();
	}

if (empty($_POST['senhaca'])){
 		print "<b>Informe uma senha para o usu�rio!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar";
 		Exit();
	}

if (empty($_POST['nivel'])){
 		print "<b>Informe um nivel para o usu�rio!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar";
 		Exit();
	}

$_POST['nomeca'] = strtolower($_POST['nomeca']);
include ("inserirus.php");

Exit();
  }
?>
