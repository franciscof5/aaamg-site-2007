<?
if ($nivelusuario != "3"){
print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
 		Exit();
	}

//Tirando o valor da variavel $esite
$esite="";
// Incuindo o arquivo de configura��o
@include("config.php");

//Testando valor da variavel $esite, se estiver
//sem valor vai para tela de entrada
if (empty($esite)){
//Incluindo arquivo de autentica��o
@include "../lg/se.php";
}
//Incluindo arquivo de autentica��o
@include "lg/se.php";


// Conectando com o banco de dados.
$conexao = mysql_connect($dbserver, $dbuser, $dbpass);

// Selecionando a base de dados.
$db = mysql_select_db($dbname);

// Selecionando na tablela os dados necessarios.
$sqla = "SELECT * FROM $dbtbu WHERE id='".$_GET['id']."'";

// Verificando se tudo ocorreu certo.
$resultadoa = mysql_query($sqla)

// Menssagen de erro.
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

// Pegando os dados.
$linha=mysql_fetch_array($resultadoa);
$nome = $linha["nome"];

	if ($nome == "shz"){
print "<font color=$colortex size=$sizetex><b>Esse usuario � indestrutivel!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
 		Exit();
	}
// Deletando os dados selecionados
$sql = "DELETE FROM $dbtbu WHERE id='".$_GET['id']."'";

// Verificando se tudo ocorreu certo.
$resultado = mysql_query($sql)

// Menssagen de erro.
or die ("<font face=$face size=$sizetex1 color='$colortex'>N�o foi poss�vel realizar a exclus�o dos dados.</font>");

// Menssagem de exito.
echo "<font face=$face size=$sizetex color='$colortex'>Cadastro de $nome foi exclu�do com �xito!</font><br>
<center><font face=$face size=$sizetex1 color='$colortex'><a href=http://$esite/admin.php?viewby=usuarios><B>VOLTAR</B></font></a></center>";

?>
