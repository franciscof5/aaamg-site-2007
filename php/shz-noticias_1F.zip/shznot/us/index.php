<?
if ($nivelusuario != "3"){
print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
 		Exit();
	}
//Tirando o valor da variavel $esite
$esite="";
// Incuindo o arquivo de configura��o
@include("config.php");

//Testando valor da variavel $esite, se estiver
//sem valor vai para tela de entrada
if (empty($esite)){
//Incluindo arquivo de autentica��o
@include "../lg/se.php";
}
//Incluindo arquivo de autentica��o
@include "lg/se.php";

@include("cab.php");

 
// Pegando data e hora.
$dataca = date("Y-m-d");
$horaca = date("H:i:s");
//$novadata = substr($data,8,2) . "/" .substr($data,5,2) . "/" . substr($data,0,4);
//$novahora = substr($hora,0,2) . "h" .substr($hora,3,2) . "min";

// Formulario de cadastro de noticias
echo "<font face=$face size=$sizetex2 color='$colortex'><B>Cadastro de usuarios</B></font><BR><BR>";
echo "<table border=0 cellpadding=1 cellspacing=1>";

echo "<form action='admin.php?viewby=validaus' method='post'>";
echo "<tr><td><font face=$face size=$sizefontform color='$colortex'>Nome:</font></td><td><input name='nomeca' type='text' size=50><td></tr>";
echo "<tr><td><font face=$face size=$sizefontform color='$colortex'>E-mail:</font><br></td><td><input name='email' type='text' size=30><td></tr>";
echo "<tr><td><font face=$face size=$sizefontform color='$colortex'>Senha:</font></td><td><input name='senhaca' type='password' size=15><td></tr>";
echo "<tr><td><font face=$face size=$sizefontform color='$colortex'>Nivel:</font></td>";
echo "<tr><td><font face=$face size=$sizefontform color='$colortex'>1 -</font></td><td><input type='RADIO' name='nivel' value='1' CHECKED>
<font face=$face size=$sizefontform color='$colortex'>Pode cadastrar mais a not�cia cadastrada n�o � publicada.</font></td></tr>";
echo "<tr><td><font face=$face size=$sizefontform color=$colortex'>2 -</font></td><td><input type='RADIO' name='nivel' value='2'>
<font face=$face size=$sizefontform color='$colortex'>Pode cadastrar e publicar not�cias, mais n�o pode excluir nem alterar not�cias.</font></td></tr>";
echo "<tr><td><font face=$face size=$sizefontform color='$colortex'>3 -</font></td><td><input type='RADIO' name='nivel' value='3'>
<font face=$face size=$sizefontform color='$colortex'>Pode cadastrar, alterar, excluir e publicar not�cias.</font></td></tr>";
echo "<input name='dataca' type='hidden' value='$dataca'><input name='horaca' type='hidden' value='$horaca'>";
echo "<input name='referenovo' type='hidden' value='novo'>";
echo "<tr><td></td><td align='right'><input type='submit' value='Cadastrar'></td></tr>";
echo "</form>";
echo "<br></table>";
echo "<font face=$face size=$sizefontr color='$colortex'><i>Todos os campos s�o obrigat�rios no cadastro.</font><br><BR><div align='center'><HR></div>";


include "alteraus.php";
?>
</html>
