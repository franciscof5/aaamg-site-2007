<?
//if ($nivelusuario != "3"){
//print "<font color=$colortex size=$sizetex><b>Voc� n�o tem permi��o para acessar essa area!</b><br><br>
//	 	Clique <a href=\"javascript:history.back()\">aqui</a> para Voltar</font>";
// 		Exit();
//	}

//Tirando o valor da variavel $esite
$esite="";
// Incuindo o arquivo de configura��o
@include("config.php");

//Testando valor da variavel $esite, se estiver
//sem valor vai para tela de entrada
if (empty($esite)){
//Incluindo arquivo de autentica��o
@include "../lg/se.php";
}
//Incluindo arquivo de autentica��o
@include "lg/se.php";


// Conectando ao banco de dados.
$conexao = mysql_connect($dbserver, $dbuser, $dbpass);

// Selecionando a base de dados.
$db = mysql_select_db("$dbname");

if ($nivelusuario != "3"){
$_GET['id'] = $dadosc[id];
}

// Selecionando na tablela os dados necessarios.
$sql = "SELECT * FROM $dbtbu WHERE id='".$_GET['id']."'";

// Verificando se tudo ocorreu certo.
$resultado = mysql_query($sql)

// Menssagen de erro.
or die ("N�o foi poss�vel realizar a consulta ao banco de dados");

// Pegando os dados.
$linha=mysql_fetch_array($resultado);
$id = $linha["id"];
$nome = $linha["nome"];
$email = $linha["email"];
$data = $linha["data"];
$hora = $linha["hora"];
$senha = $linha["senha"];
$nivel = $linha["nivel"];

$novadata = substr($data,8,2) . "/" .substr($data,5,2) . "/" . substr($data,0,4);
$novahora = substr($hora,0,2) . "h" .substr($hora,3,2) . "min";

// Formulario de altera��o dos dados com os dados antigos como defaut.
echo "<font face=$face size=$sizetex2 color='$colortex'><B>Alterando cadastro de $nome...</B></font>";
echo "<P><br>";
echo "<font face=$face size=$sizetex color='$colortex'>Data do cadastro:</font> <font face=$face size=$sizetex1 color='$colortex'><I>$novadata</font> <BR></I>";
echo "<font face=$face size=$sizetex color='$colortex'>Hora do cadastro:</font> <font face=$face size=$sizetex1 color='$colortex'><I>$novahora</font></I>";
echo "<table border=0 cellpadding=1 cellspacing=1>";
echo "<form action='admin.php?viewby=alterar_dbus&id=$id' method='post'>";


//echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Nome:</td><td><input name='nome_novo' type='text' value='$nome' size=30> </td></tr>";
echo "<input name='nome_novo' type='hidden' value='$nome'>";

echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Email:</td><td><input name='email_novo' type='text'
value='$email' size=30><br></td></tr>";
echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Senha:</td><td><input name='senha_novo' type='password' value='' size=30></td></tr>";

if ($nivelusuario == "3"){
	if ($nome != "shz"){
echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Nivel:</td>";
echo "<tr><td><font face=$face size=$sizetex1 color='$colortex'>1 -</td><td><input type='RADIO' name='nivel_novo' value='1'";
if ($nivel == "1"){ echo "CHECKED";}

echo ">
<font face=$face size=$sizetex1 color='$colortex'>Pode cadastrar mais a not�cia cadastrada n�o � publicada.</td></tr>";
echo "<tr><td><font face=$face size=$sizetex1 color='$colortex'>2 -</td><td><input type='RADIO' name='nivel_novo' value='2'";
if ($nivel == "2"){ echo "CHECKED";}

echo ">
<font face=$face size=$sizetex1 color='$colortex'>Pode cadastrar e publicar not�cias, mais n�o pode excluir nem alterar not�cias.</td></tr>";
echo "<tr><td><font face=$face size=$sizetex1 color='$colortex'>3 -</td><td><input type='RADIO' name='nivel_novo' value='3'";
if ($nivel == "3"){ echo "CHECKED";}

echo ">
<font face=$face size=$sizetex1 color='$colortex'>Pode cadastrar, alterar, excluir e publicar not�cias.</td></tr>";
}}
echo "<tr><td><input type='submit' value='Alterar'></td></tr>";
echo "</form></table>";
echo "<br>";

if ($nivelusuario == "3"){
echo "<center><a href=http://$esite/admin.php?viewby=usuarios><font face=$face size=$sizetex1 color='$colortex'><B>VOLTAR</B></font></a></center>";
}
?>
