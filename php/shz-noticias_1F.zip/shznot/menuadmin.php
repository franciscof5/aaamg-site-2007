<?
//Arquico com estilo de link
include "stl.php";
// Incuindo o arquivo de configura��o
include "config.php";
?>
<html>
<?
//A variavel $tituloshz define o titulo do site.
//Essa variavel pode ser alterada no config.php
?>
<title><? echo $tituloshz; ?></title>
<body bgcolor="<? echo $colorbg; ?>" onload="setTimeout ('window.location.reload(true)',900000)">

<table align='head' bgcolor='<? echo $colorbg; ?>' cellpadding='0' cellspacing='0' border='0'>
<tr>
<td align='right' bgcolor='<? echo $colorbg; ?>' nowrap>
</a>
</td>
<tr>
<td>
<table bgcolor='<? echo $colorbg; ?>' cellpadding='4' cellspacing='1' border='0'>
<tr>
<td bgcolor='<? echo $colorbg; ?>'><b>
<font size='<? echo $sizetex1; ?>'>
| <a href='<? echo "?viewby=cadastro"; ?>'><font color='<? echo $colortex; ?>'>CADASTRAR</font></a> |
<?
if ($nivelusuario == "3"){
echo "
<a href='?viewby=alterar'><font color='$colortex'>NOT�CIAS</font></a> |
<a href='?viewby=publica'><font color='$colortex'>PUBLICAR</font></a> |
<a href='?viewby=grupos'><font color='$colortex'>GRUPOS</font></a> |
<a href='?viewby=usuarios'><font color='$colortex'>USUARIOS</font></a> |";}

if ($nivelusuario != "3"){
echo "<a href='$PHP_SELF?viewby=usuariosn1'><font color='$colortex'>USUARIOS</font></a> |";
}
?>

 <a href='<? echo "$PHP_SELF?viewby=ver"; ?>'><font color='<? echo $colortex; ?>'>VER</font></a> |
<?/*
if ($nivelusuario == "3"){
echo "
<a href='$PHP_SELF?viewby=back'><font color='$colortex'>BACKUP</font></a> |";} */?>

 <a href='<? echo "lg/index.php"; ?>'><font color='<? echo $colortex; ?>'>SAIR</font></a> |
</font>
</td>
</tr>
<tr>
<td nowrap>
<br>
