<head>
<style type="text/css">
<!--
table {  font-family: <? echo "$face";?>; color: <? echo $colortex ; ?>}
a:visited {  font-family: <? echo "$face";?>; color: <? echo $colortex ; ?>; text-decoration: none}
a:link {  font-family: <? echo "$face";?>; color: <? echo $colortex ; ?>; text-decoration: none}
a:hover {  font-family: <? echo "$face";?>; color: <? echo $colortexl ; ?>; background-color: <? echo $colorbgt ; ?>}
a:active {  font-family: <? echo "$face";?>; color: <? echo $colortexl2 ; ?>; background-color: <? echo $colorbgt2 ; ?>}
.texto {  border: 1px #000000 solid; font-family: <? echo "face";?>; font-size: 9pt}
BODY {
	SCROLLBAR-FACE-COLOR: <? echo $colorbgb ; ?> ; SCROLLBAR-HIGHLIGHT-COLOR: <? echo $colorbf ; ?>; SCROLLBAR-SHADOW-COLOR: <? echo $colorbf ; ?>; SCROLLBAR-3DLIGHT-COLOR: <? echo $colorbgb ; ?>; SCROLLBAR-ARROW-COLOR: <? echo $colorbf ; ?>; SCROLLBAR-TRACK-COLOR: <? echo $colorbgb ; ?>; SCROLLBAR-DARKSHADOW-COLOR: <? echo $colorbf; ?>
}
-->
INPUT {
	FONT-SIZE: <? echo $sizeinput ; ?>; COLOR: <? echo $colortex ; ?>; FONT-FAMILY: <? echo $face ; ?>; BACKGROUND-COLOR: <? echo $colorbgform ; ?>

</style>
</head>
