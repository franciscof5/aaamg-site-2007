#
# Estrutura da tabela `noticias`
#

CREATE TABLE noticias (
  id int(5) NOT NULL auto_increment,
  fonte varchar(30) NOT NULL default '',
  endfonte varchar(30) NOT NULL default '',
  email varchar(80) default NULL,
  data date NOT NULL default '0000-00-00',
  hora time NOT NULL default '00:00:00',
  titulo varchar(100) NOT NULL default '',
  subtitulo text NOT NULL,
  texto text NOT NULL,
  atualiza text NOT NULL,
  ver char(3) default 'on',
  PRIMARY KEY  (id),
  UNIQUE KEY id (id)
) TYPE=MyISAM;

#
# Extraindo dados da tabela `noticias`
#
INSERT INTO noticias VALUES('1','SHZ','www.shz.com.br','shz@shz.com.br','2004-03-07','14:41:17','Parab�ns!','O SHZ-Not�cias est� instalado!','<br>Se voc� est� lendo essa not�cia � porque voc� conseguiu instalar o SHZ-Not�cias.<br>Para duvidas, sugest�es, ou crit�cas envie um e-mail para shz@shz.com.br.<br>Agora entre admin.php e troque a senha do usuario padr�o <B>SHZ</B>.','2','on')

# --------------------------------------------------------

#
# Estrutura da tabela `usuario`
#

CREATE TABLE usuario (
  id int(5) NOT NULL auto_increment,
  nome char(80) default NULL,
  email char(80) default NULL,
  senha char(80) default NULL,
  data date NOT NULL default '0000-00-00',
  hora time NOT NULL default '00:00:00',
  noticia char(70) NOT NULL default '',
  nivel char(3) NOT NULL default '',
  PRIMARY KEY  (id),
  UNIQUE KEY id (id)
) TYPE=MyISAM;

#
# Extraindo dados da tabela `usuario`
#

INSERT INTO usuario VALUES (1, 'shz', 'shz@shz.com.br', 'd41d8cd98f00b204e9800998ecf8427e', '2004-03-07', '14:41:17', '', '3');

