<?
// Incuindo o arquivos de configura��es
include("../config.php");
include "../stl.php";
?>
<html>
<title><? echo $tituloshz; ?></title>
<body bgcolor="<? echo $colorbg; ?>" onload="setTimeout ('window.location.reload(true)',900000)">
  
<?
//Se o campo da senha do banco de dados ficar em branco ele emite um aviso.
if (empty($_POST['dbpassi'])){
echo "<b>Voc� deixou o seu banco de dados sem senha isso � inseguro,
pois qualquer pessoa pode alterar dados cadastrados no mesmo!</b>";
	} 
?>

<?php



	 echo "Testando conex�o...<br>";
	 flush();
	 if(!$db = mysql_connect($_POST['dbserveri'], $_POST['dbuseri'], $_POST['dbpassi']))
	   die("<font color=\"#FF0000\">Erro, falha ao conectar no MySQL ".$_POST['dbpserveri'].". Usando o nome ".$_POST['dbuseri']." e a senha ".$_POST['dbpassi'].".<BR>Volte por favor e confira os dados.");
	 echo "<font color=\"#000000\">DB Conex�o Boa!</FONT><BR>";
	 flush();
	 echo "Selecionar DB ".$_POST['dbnamei']."...";
	 flush();
	 if(!@mysql_select_db($_POST['dbnamei'], $db)) {
	    echo "<font color=\"#FF0000\">Base de dados n�o existente!</font><BR>";
	    flush();
	    echo "Criando base de dados ".$_POST['dbnamei']."...";
	    flush();
	    if(!$r = mysql_query("CREATE DATABASE ".$_POST['dbnamei'], $db))
	      die("<font color=\"#FF0000\">Error, count not select or create database $dbnamei, please create it manually or have your system administrator do it for you and try again.");
	    mysql_select_db($_POST['dbnamei'], $db);
	    echo "<font color=\"#000000\">Database Criada!</font><BR>";
	    flush();
	 }
	 else
	   echo "<font color=\"#000000\">Banco de Dados selecionado!</font><BR>";
	 flush();
	 echo "Criar tabelas e inserindo dados padr�es...<BR>";
	 flush();
	 $tables = array ("tabela Not�cias" => "CREATE TABLE noticias (
							id int(5) NOT NULL auto_increment,
							grupo char(4) NOT NULL ,
							fonte char(30) NOT NULL ,
							endfonte char(30) NOT NULL ,
							email char(80) ,
							data date NOT NULL,
							hora time NOT NULL ,
							titulo char(100) NOT NULL ,
							subtitulo text NOT NULL ,
							texto text NOT NULL ,
							atualiza text NOT NULL ,
							ver char(3) DEFAULT 'on' ,
							PRIMARY KEY (id),
							UNIQUE id (id)
							     )",
"primeira not�cia" =>"INSERT INTO noticias VALUES('1','','SHZ','www.shz.com.br','shz@shz.com.br','2007-03-12','14:41:17','Parab�ns!','O SHZ-Not�cias est� instalado!','<br>Se voc� est� lendo essa not�cia � porque voc� conseguiu instalar o SHZ-Not�cias.<br>Para duvidas, sugest�es, ou crit�cas envie um e-mail para shz@shz.com.br.<br>Agora entre no http://SEU-SITE/shznot/admin.php e troque a senha do usuario padr�o <B>SHZ</B>.','2','on')",

"tabela Grupo" => "CREATE TABLE grupo (
							id int(5) NOT NULL auto_increment,
							nome char(80) ,
							descricao text NOT NULL ,
							data date NOT NULL,
							hora time NOT NULL ,
							nivel char(3) NOT NULL ,
							ver char(3) DEFAULT 'on' ,
							PRIMARY KEY (id),
							UNIQUE id (id)
							     )",

"tabela Usu�rio" => "CREATE TABLE usuario (
							id int(5) NOT NULL auto_increment,
							nome char(80) ,
							email char(80) ,
							senha char(80) ,
							data date NOT NULL,
							hora time NOT NULL ,
							noticia char(70) NOT NULL ,
							nivel char(3) NOT NULL ,
							PRIMARY KEY (id),
							UNIQUE id (id)
							     )",
"usu�rio indestrut�vel" =>"INSERT INTO usuario VALUES('1','shz','shz@shz.com.br','d41d8cd98f00b204e9800998ecf8427e','2004-03-07','14:41:17','','3')"

);
			 
	 echo "<TABLE BORDER=\"0\">\n";
	 while(list($name, $table) = each($tables)) {
	    echo "<TR><TD>Criando $name</TD> ";
	    if(!$r = mysql_query($table, $db))
	      die("<TD><font color=\"#FF0000\">ERRO! a tabela n�o foi criada. Por que: <b>". mysql_error()."</b></TD></TR></TABLE>");
	    echo "<TD><font color=\"#000000\">[OK]</FONT></TD></TR>";
	    flush();
	 }

	 echo "</TABLE>";


	 echo "<font color=\"#000000\">Banco de Dados criado com Sucesso!<br>
<br>
A base de dados foi criada com sucesso!!<br>
Edite o arquivo <font size=4>config.php</font> e coloque os dados corretos, caso j� tenha editado basta entrar em
admin.php para cadastrar, alterar, excluir e ver as not�cias j� cadastradas!
</FONT><BR>";
?>


	

</BODY>
</HTML>
