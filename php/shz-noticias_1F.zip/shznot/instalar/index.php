<?

// Incuindo o arquivo de configura��o
@include("../config.php");
@include "../stl.php";
?>
<html>
<title><? echo $tituloshz; ?></title>
<body bgcolor="<? echo $colorbg; ?>" onload="setTimeout ('window.location.reload(true)',900000)">

<FORM METHOD="POST" ACTION="valida.php">
	<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" ALIGN="CENTER" VALIGN="TOP" WIDTH="95%">
	      <TR>
	      <TD >
	      <TABLE BORDER="1" CELLPADDING="1" CELLSPACING="1" WIDTH="100%">
	            <TR ALIGN="CENTER">
	            <TD COLSPAN="2"><b>Instalador SHZ</b></TD>
	            </TR>
	            <TR ALIGN="LEFT">
	            <TD COLSPAN="2">Esse instalador foi criado com o objetivo de facilitar a instala��o dos scriptZ SHZ!<br>
		    Porem voc� pode utilizar o arquivo noticias.sql!
	            </TD>
	            </TR>
	            <TR ALIGN="LEFT">
                    <TD >Endere�o do servidor de DB:</TD>
	            <TD><INPUT TYPE="TEXT" NAME="dbserveri" SIZE="30" VALUE="<?php echo $dbserver;?>"></TD>
	            </TR>
	            <TR>
                    <TD>Nome do DB:</TD>
	            <TD><INPUT TYPE="TEXT" NAME="dbnamei" SIZE="30" VALUE="<?php echo $dbname;?>"></TD>
	            <TR>
	            <TD>Usuario do DB:</TD>
	            <TD><INPUT TYPE="TEXT" NAME="dbuseri" SIZE="30" VALUE="<?php echo $dbuser;?>"></TD>
	            </TR>
	            <TR>
                    <TD>Senha do DB:</TD>
	            <TD><INPUT TYPE="PASSWORD" NAME="dbpassi" SIZE="30" value="<?php echo $dbpass;?>"></TD>
	            </TR>
	            <TR ALIGN="Right">
	            <TD COLSPAN="2"><INPUT TYPE="HIDDEN" NAME="next" VALUE="database"><INPUT TYPE="SUBMIT" VALUE="Next >"></TD>
	            </TR>
	      </TABLE>
	</TD>
	</TR>
      </TABLE>

</BODY>
</HTML>
