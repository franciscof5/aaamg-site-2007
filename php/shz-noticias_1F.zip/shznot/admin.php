<?php
session_start();
include "lg/se.php";
?>
<html>
<head>
<script type="text/javascript" src="editor/ImageManager/assets/dialog.js"></script>
<script language="session_start();

JavaScript" type="text/javascript">
 var myRTEconfig = { editor_lang : 'en',
                      editor_url  : 'editor/',
                      isFullEditor: true
                    };
 var rteCSSfile = 'france.css';
</script>
<script language="JavaScript" type="text/javascript" src="editor/tinyRTE_setup.js"></script>
<?php
// Incuindo o arquivo de configura��o
include("config.php");

?>


<title><?php echo $tituloshz; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilo_agasys.css" rel="stylesheet" type="text/css">
</head>

<body bgcolor="<?php echo $colorbg; ?>">

<?php
include "comeco.php";
//Arquico com estilo de link
include "stl.php";

//Parte integrante deste
include("menuadmin.php");



// Ver Cadastro

if($_GET['viewby'] == "" or $_GET['viewby'] == "cadastro") {

include("cadastro.php");

	}


// Ver Alterar

if($_GET['viewby'] == "alterar") {

include("altera.php");

       
}

// Ver Noticias

if($_GET['viewby'] == "ver") {

include("noticias.php");


}

//Ver configura��es de usuarios

if($_GET['viewby'] == "usuarios") {

include("us/index.php");


}

//Ver Backups

if($_GET['viewby'] == "back") {

include("mysql_back.php");

}

//Inclui noticia


if($_GET['viewby'] == "valida") {

include("valida.php");
}

//Ver exclui

if($_GET['viewby'] == "exnot") {

include("exnot.php");
}

//Excluir

if($_GET['viewby'] == "excluir2") {

include("excluir.php");
}

//Tela altera

if($_GET['viewby'] == "alterar2") {

include("alterar.php");
}

//Altera  db

if($_GET['viewby'] == "alterar_db") {

include("alterar_db.php");
}


//GRUPOS
if($_GET['viewby'] == "grupos") {
include("cadastro_g.php");
}





//AREA DE USUARIOS


//Inclui cadastro de usuarios

if($_GET['viewby'] == "validaus") {

include("us/validaus.php");
}

//Exclui cadastro de usuarios

if($_GET['viewby'] == "excluirus") {

include("us/excluirus.php");
}

//Ver altera cadastro de usuarios

if($_GET['viewby'] == "alterarus") {

include("us/alterarus.php");
}

//Tela de usuarios para usuarios de niveis 1 e 2

if($_GET['viewby'] == "usuariosn1") {

include("us/alterarus.php");
}

//Altera cadastro de usuarios

if($_GET['viewby'] == "alterar_dbus") {

include("us/alterar_dbus.php");
}

//Altera cadastro de usuarios

if($_GET['viewby'] == "sair") {

include("lg/index.php");
}

//Noticias que est�o em off

if($_GET['viewby'] == "publica") {

include("publica.php");
}

//Publica noticia

if($_GET['viewby'] == "publicar") {

include("publicar.php");
}

?>
</html>
