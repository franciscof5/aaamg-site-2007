<?php
include "lg/se.php";
?>
<html>
<?
//A variavel $tituloshz define o titulo do site.
//Essa variavel pode ser alterada no config.php
?>
<title><? echo $tituloshz; ?></title>
<body bgcolor="<? echo $colorbg; ?>" onload="setTimeout ('window.location.reload(true)',900000)">

<?php
echo "<form action='admin.php?viewby=valida' method='post'>";


// Pegando data e hora.
$data = date("Y-m-d");
$hora = date("H:i:s");
//Formatando data e hora para formatos Brasileiros.
$novadata = substr($data,8,2) . "/" .substr($data,5,2) . "/" . substr($data,0,4);
$novahora = substr($hora,0,2) . "h" .substr($hora,3,2) . "min";

// Formulario de cadastro de noticias

echo "<font face=$face size=$sizetex2 color='$colortex'><b>CADASTRO...</b></font><BR>
<table border=0 cellpadding=1 cellspacing=1>";

echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Grupo:</font></td>
<td><SELECT NAME='grupo' SIZE='1'>
<OPTION VALUE='' SELECTED> - ";
// Selecionando os dados da tabela em ordem decrescente
$sql = "SELECT * FROM $dbtbg ORDER BY nome";
// Executando $sql e verificando se tudo ocorreu certo.
$resultado = mysql_query($sql);
//Realizando um loop para exibi��o de todos os dados 
while ($linha=mysql_fetch_array($resultado)) {
echo "<OPTION VALUE='".$linha['id']."'>".$linha['nome'];
}
echo "</SELECT></td></tr>";


echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Fonte:</font></td><td><input name='fonte' type='text' size=30></td></tr>";
echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Site fonte: <br><i>Sem http:// (Ex. www.shz.com.br)</i></font></td><td><input name='endfonte' type='text' size=30></td></tr>";
echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Email: <br><i>(Exemplo: david@shz.com.br)</i></td><td><input name='email' type='text' value=$dadosc[email] size=30><td></tr>";
echo "<tr><td><font face=$face size=$sizetex color='$colortex'>T�tulo do Texto:</font></td><td><input name='titulo' type='text' size=30><td></tr>";

echo "<tr><td><font face=$face size=$sizetex color='$colortex'>Subt�tulo do Texto:</font></td><td>
<textarea id='body' name='subtitulo' rows=5 cols=30></textarea>";
?>
<script type="text/javascript">

         var editor1 = new tinyRTE('body', rteCSSfile,true);
         editor1.replaceTextarea(400,300);

        </script>
<?php
echo "</td></tr><tr><td><font face=$face size=$sizetex color='$colortex'>Texto:<br></font></td><td>
<textarea id='body1' name='texto' rows=10 cols=30></textarea>";
?>
<script type="text/javascript">

         var editor1 = new tinyRTE('body1', rteCSSfile,true);
         editor1.replaceTextarea(400,300);

        </script>
<?php
echo "</td></tr><tr><td><font face=$face size=$sizetex color='$colortex'>Exibir?</td>";
if ($nivelusuario == "1"){
echo "<td><input name='ver' type='hidden' value='off'><font face=$face size=$sizetex color='$colortex'><B>N�O</B></font></td></tr> ";
	}else{
echo "<td><SELECT NAME='ver' SIZE='1'>
<OPTION VALUE='on' SELECTED>SIM
<OPTION VALUE='off'>N�O</SELECT></td></tr>";
}
echo "<tr><td><font face=$face size=$sizetex color='$colortex'><I>Se selecionar a op��o N�O a not�cia ser� <BR>cadastrada mas n�o ser� exibida. </font>
</td></tr>";
echo "<input name='data' type='hidden' value='$data'><input name='hora' type='hidden' value='$hora'>";
echo "<tr><td></td><td align='right'><input type='submit' value='CADASTRAR'></td></tr>";
echo "</form>";
echo "<br></table>";
echo "<font face=$face size=$sizetex1 color='$colortex'><i>Todos os campos s�o obrigat�rios no cadastro.<br>";
echo "<b>Observa��o</b>: Ser� inserido no seu cadastro a data atual, bem como a hora atual do cadastro<br>";
echo "Data: $novadata - Hora: $novahora<br></font>";

?>
</html>
