<?php

$horaco = date("H");

if ($horaco >= 0 && $horaco < 6){

echo "<font size=$sizetex color=$colortex><b>, BOA MADRUGADA.</b></font>";

}
elseif ($horaco >= 6 && $horaco < 12){

echo "<font size=$sizetex color=$colortex><b>, BOM DIA.</b></font>";

}
elseif ($horaco >= 12 && $horaco < 18){

echo "<font size=$sizetex color=$colortex>, BOA TARDE.</font>";

}else{

echo "<font size=$sizetex color=$colortex><b>, BOA NOITE.</b></font>";
}
?>
