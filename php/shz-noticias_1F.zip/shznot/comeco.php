<?php

include "lg/se.php";

include "data.php";

include "cmt.php";

echo "<font size=$sizetex color=$colortex><br>Ol� <b>". strtoupper($dadosc[nome]). "</b> - Nivel <B>$nivelusuario</B> de 3</font>" ;
?>
